"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [22], {
        39806: function(t, e, i) {
            i.d(e, {
                S: function() {
                    return c
                }
            });
            var n = i(33303),
                r = i(37229),
                s = i(29908),
                o = i(22476);

            function a(t, e) {
                return t * Math.sqrt(1 - e * e)
            }
            let l = ["duration", "bounce"],
                u = ["stiffness", "damping", "mass"];

            function h(t, e) {
                return e.some(e => void 0 !== t[e])
            }

            function c({
                keyframes: t,
                restDelta: e,
                restSpeed: i,
                ...c
            }) {
                let d;
                let p = t[0],
                    f = t[t.length - 1],
                    m = {
                        done: !1,
                        value: p
                    },
                    {
                        stiffness: v,
                        damping: g,
                        mass: y,
                        duration: x,
                        velocity: P,
                        isResolvedFromDuration: w
                    } = function(t) {
                        let e = {
                            velocity: 0,
                            stiffness: 100,
                            damping: 10,
                            mass: 1,
                            isResolvedFromDuration: !1,
                            ...t
                        };
                        if (!h(t, u) && h(t, l)) {
                            let i = function({
                                duration: t = 800,
                                bounce: e = .25,
                                velocity: i = 0,
                                mass: r = 1
                            }) {
                                let l, u;
                                (0, s.K)(t <= (0, n.w)(10), "Spring duration must be 10 seconds or less");
                                let h = 1 - e;
                                h = (0, o.u)(.05, 1, h), t = (0, o.u)(.01, 10, (0, n.X)(t)), h < 1 ? (l = e => {
                                    let n = e * h,
                                        r = n * t;
                                    return .001 - (n - i) / a(e, h) * Math.exp(-r)
                                }, u = e => {
                                    let n = e * h * t,
                                        r = Math.pow(h, 2) * Math.pow(e, 2) * t,
                                        s = a(Math.pow(e, 2), h);
                                    return (n * i + i - r) * Math.exp(-n) * (-l(e) + .001 > 0 ? -1 : 1) / s
                                }) : (l = e => -.001 + Math.exp(-e * t) * ((e - i) * t + 1), u = e => t * t * (i - e) * Math.exp(-e * t));
                                let c = function(t, e, i) {
                                    let n = i;
                                    for (let i = 1; i < 12; i++) n -= t(n) / e(n);
                                    return n
                                }(l, u, 5 / t);
                                if (t = (0, n.w)(t), isNaN(c)) return {
                                    stiffness: 100,
                                    damping: 10,
                                    duration: t
                                }; {
                                    let e = Math.pow(c, 2) * r;
                                    return {
                                        stiffness: e,
                                        damping: 2 * h * Math.sqrt(r * e),
                                        duration: t
                                    }
                                }
                            }(t);
                            (e = { ...e,
                                ...i,
                                mass: 1
                            }).isResolvedFromDuration = !0
                        }
                        return e
                    }({ ...c,
                        velocity: -(0, n.X)(c.velocity || 0)
                    }),
                    b = P || 0,
                    T = g / (2 * Math.sqrt(v * y)),
                    S = f - p,
                    A = (0, n.X)(Math.sqrt(v / y)),
                    V = 5 > Math.abs(S);
                if (i || (i = V ? .01 : 2), e || (e = V ? .005 : .5), T < 1) {
                    let t = a(A, T);
                    d = e => f - Math.exp(-T * A * e) * ((b + T * A * S) / t * Math.sin(t * e) + S * Math.cos(t * e))
                } else if (1 === T) d = t => f - Math.exp(-A * t) * (S + (b + A * S) * t);
                else {
                    let t = A * Math.sqrt(T * T - 1);
                    d = e => {
                        let i = Math.exp(-T * A * e),
                            n = Math.min(t * e, 300);
                        return f - i * ((b + T * A * S) * Math.sinh(n) + t * S * Math.cosh(n)) / t
                    }
                }
                return {
                    calculatedDuration: w && x || null,
                    next: t => {
                        let n = d(t);
                        if (w) m.done = t >= x;
                        else {
                            let s = b;
                            0 !== t && (s = T < 1 ? (0, r.P)(d, t, n) : 0);
                            let o = Math.abs(s) <= i,
                                a = Math.abs(f - n) <= e;
                            m.done = o && a
                        }
                        return m.value = m.done ? f : n, m
                    }
                }
            }
        },
        19323: function(t, e, i) {
            i.d(e, {
                E: function() {
                    return n
                },
                i: function() {
                    return r
                }
            });
            let n = 2e4;

            function r(t) {
                let e = 0,
                    i = t.next(e);
                for (; !i.done && e < n;) e += 50, i = t.next(e);
                return e >= n ? 1 / 0 : e
            }
        },
        37229: function(t, e, i) {
            i.d(e, {
                P: function() {
                    return r
                }
            });
            var n = i(92181);

            function r(t, e, i) {
                let r = Math.max(e - 5, 0);
                return (0, n.R)(i - t(r), e - r)
            }
        },
        49622: function(t, e, i) {
            i.d(e, {
                v: function() {
                    return td
                }
            });
            var n = i(33303),
                r = i(60618);
            let s = {
                    type: "spring",
                    stiffness: 500,
                    damping: 25,
                    restSpeed: 10
                },
                o = t => ({
                    type: "spring",
                    stiffness: 550,
                    damping: 0 === t ? 2 * Math.sqrt(550) : 30,
                    restSpeed: 10
                }),
                a = {
                    type: "keyframes",
                    duration: .8
                },
                l = {
                    type: "keyframes",
                    ease: [.25, .1, .35, 1],
                    duration: .3
                },
                u = (t, {
                    keyframes: e
                }) => e.length > 2 ? a : r.G.has(t) ? t.startsWith("scale") ? o(e[1]) : s : l;
            var h = i(95566),
                c = i(36832);
            let d = {
                    current: !1
                },
                p = t => null !== t;

            function f(t, {
                repeat: e,
                repeatType: i = "loop"
            }, n) {
                let r = t.filter(p),
                    s = e && "loop" !== i && e % 2 == 1 ? 0 : r.length - 1;
                return s && void 0 !== n ? n : r[s]
            }
            var m = i(14205),
                v = i(33791),
                g = i(20928),
                y = i(66190),
                x = i(3393),
                P = i(54178),
                w = i(29908),
                b = i(92263);
            let T = (t, e) => "zIndex" !== e && !!("number" == typeof t || Array.isArray(t) || "string" == typeof t && (b.P.test(t) || "0" === t) && !t.startsWith("url("));
            class S {
                constructor({
                    autoplay: t = !0,
                    delay: e = 0,
                    type: i = "keyframes",
                    repeat: n = 0,
                    repeatDelay: r = 0,
                    repeatType: s = "loop",
                    ...o
                }) {
                    this.isStopped = !1, this.hasAttemptedResolve = !1, this.options = {
                        autoplay: t,
                        delay: e,
                        type: i,
                        repeat: n,
                        repeatDelay: r,
                        repeatType: s,
                        ...o
                    }, this.updateFinishedPromise()
                }
                get resolved() {
                    return this._resolved || this.hasAttemptedResolve || (0, P.m)(), this._resolved
                }
                onKeyframesResolved(t, e) {
                    this.hasAttemptedResolve = !0;
                    let {
                        name: i,
                        type: n,
                        velocity: r,
                        delay: s,
                        onComplete: o,
                        onUpdate: a,
                        isGenerator: l
                    } = this.options;
                    if (!l && ! function(t, e, i, n) {
                            let r = t[0];
                            if (null === r) return !1;
                            let s = t[t.length - 1],
                                o = T(r, e),
                                a = T(s, e);
                            return (0, w.K)(o === a, `You are trying to animate ${e} from "${r}" to "${s}". ${r} is not an animatable value - to enable this animation set ${r} to a value animatable to ${s} via the \`style\` property.`), !!o && !!a && (function(t) {
                                let e = t[0];
                                if (1 === t.length) return !0;
                                for (let i = 0; i < t.length; i++)
                                    if (t[i] !== e) return !0
                            }(t) || "spring" === i && n)
                        }(t, i, n, r)) {
                        if (d.current || !s) {
                            null == a || a(f(t, this.options, e)), null == o || o(), this.resolveFinishedPromise();
                            return
                        }
                        this.options.duration = 0
                    }
                    let u = this.initPlayback(t, e);
                    !1 !== u && (this._resolved = {
                        keyframes: t,
                        finalKeyframe: e,
                        ...u
                    }, this.onPostResolved())
                }
                onPostResolved() {}
                then(t, e) {
                    return this.currentFinishedPromise.then(t, e)
                }
                updateFinishedPromise() {
                    this.currentFinishedPromise = new Promise(t => {
                        this.resolveFinishedPromise = t
                    })
                }
            }
            var A = i(39806),
                V = i(37229);

            function E({
                keyframes: t,
                velocity: e = 0,
                power: i = .8,
                timeConstant: n = 325,
                bounceDamping: r = 10,
                bounceStiffness: s = 500,
                modifyTarget: o,
                min: a,
                max: l,
                restDelta: u = .5,
                restSpeed: h
            }) {
                let c, d;
                let p = t[0],
                    f = {
                        done: !1,
                        value: p
                    },
                    m = t => void 0 !== a && t < a || void 0 !== l && t > l,
                    v = t => void 0 === a ? l : void 0 === l ? a : Math.abs(a - t) < Math.abs(l - t) ? a : l,
                    g = i * e,
                    y = p + g,
                    x = void 0 === o ? y : o(y);
                x !== y && (g = x - p);
                let P = t => -g * Math.exp(-t / n),
                    w = t => x + P(t),
                    b = t => {
                        let e = P(t),
                            i = w(t);
                        f.done = Math.abs(e) <= u, f.value = f.done ? x : i
                    },
                    T = t => {
                        m(f.value) && (c = t, d = (0, A.S)({
                            keyframes: [f.value, v(f.value)],
                            velocity: (0, V.P)(w, t, f.value),
                            damping: r,
                            stiffness: s,
                            restDelta: u,
                            restSpeed: h
                        }))
                    };
                return T(0), {
                    calculatedDuration: null,
                    next: t => {
                        let e = !1;
                        return (d || void 0 !== c || (e = !0, b(t), T(t)), void 0 !== c && t >= c) ? d.next(t - c) : (e || b(t), f)
                    }
                }
            }
            var C = i(39569),
                D = i(10113),
                M = i(47544),
                R = i(22476),
                k = i(19280),
                j = i(16384),
                L = i(5312);

            function F(t, e, i) {
                return (i < 0 && (i += 1), i > 1 && (i -= 1), i < 1 / 6) ? t + (e - t) * 6 * i : i < .5 ? e : i < 2 / 3 ? t + (e - t) * (2 / 3 - i) * 6 : t
            }
            var O = i(34184),
                B = i(46352),
                $ = i(99808);
            let I = (t, e, i) => {
                    let n = t * t,
                        r = i * (e * e - n) + n;
                    return r < 0 ? 0 : Math.sqrt(r)
                },
                U = [O.$, B.m, $.J],
                W = t => U.find(e => e.test(t));

            function N(t) {
                let e = W(t);
                (0, w.k)(!!e, `'${t}' is not an animatable color. Use the equivalent color code instead.`);
                let i = e.parse(t);
                return e === $.J && (i = function({
                    hue: t,
                    saturation: e,
                    lightness: i,
                    alpha: n
                }) {
                    t /= 360, i /= 100;
                    let r = 0,
                        s = 0,
                        o = 0;
                    if (e /= 100) {
                        let n = i < .5 ? i * (1 + e) : i + e - i * e,
                            a = 2 * i - n;
                        r = F(a, n, t + 1 / 3), s = F(a, n, t), o = F(a, n, t - 1 / 3)
                    } else r = s = o = i;
                    return {
                        red: Math.round(255 * r),
                        green: Math.round(255 * s),
                        blue: Math.round(255 * o),
                        alpha: n
                    }
                }(i)), i
            }
            let X = (t, e) => {
                let i = N(t),
                    n = N(e),
                    r = { ...i
                    };
                return t => (r.red = I(i.red, n.red, t), r.green = I(i.green, n.green, t), r.blue = I(i.blue, n.blue, t), r.alpha = (0, L.t)(i.alpha, n.alpha, t), B.m.transform(r))
            };
            var z = i(22809),
                Y = i(57126);

            function H(t, e) {
                return i => i > 0 ? e : t
            }

            function K(t, e) {
                return i => (0, L.t)(t, e, i)
            }

            function Z(t) {
                return "number" == typeof t ? K : "string" == typeof t ? (0, Y.t)(t) ? H : z.$.test(t) ? X : q : Array.isArray(t) ? G : "object" == typeof t ? z.$.test(t) ? X : _ : H
            }

            function G(t, e) {
                let i = [...t],
                    n = i.length,
                    r = t.map((t, i) => Z(t)(t, e[i]));
                return t => {
                    for (let e = 0; e < n; e++) i[e] = r[e](t);
                    return i
                }
            }

            function _(t, e) {
                let i = { ...t,
                        ...e
                    },
                    n = {};
                for (let r in i) void 0 !== t[r] && void 0 !== e[r] && (n[r] = Z(t[r])(t[r], e[r]));
                return t => {
                    for (let e in n) i[e] = n[e](t);
                    return i
                }
            }
            let q = (t, e) => {
                let i = b.P.createTransformer(e),
                    n = (0, b.V)(t),
                    r = (0, b.V)(e);
                return n.indexes.var.length === r.indexes.var.length && n.indexes.color.length === r.indexes.color.length && n.indexes.number.length >= r.indexes.number.length ? (0, k.z)(G(function(t, e) {
                    var i;
                    let n = [],
                        r = {
                            color: 0,
                            var: 0,
                            number: 0
                        };
                    for (let s = 0; s < e.values.length; s++) {
                        let o = e.types[s],
                            a = t.indexes[o][r[o]],
                            l = null !== (i = t.values[a]) && void 0 !== i ? i : 0;
                        n[s] = l, r[o]++
                    }
                    return n
                }(n, r), r.values), i) : ((0, w.K)(!0, `Complex values '${t}' and '${e}' too different to mix. Ensure all colors are of the same type, and that each contains the same quantity of number and color values. Falling back to instant transition.`), H(t, e))
            };

            function J(t, e, i) {
                return "number" == typeof t && "number" == typeof e && "number" == typeof i ? (0, L.t)(t, e, i) : Z(t)(t, e)
            }
            var Q = i(55865);

            function tt({
                duration: t = 300,
                keyframes: e,
                times: i,
                ease: n = "easeInOut"
            }) {
                let r = (0, D.N)(n) ? n.map(M.R) : (0, M.R)(n),
                    s = {
                        done: !1,
                        value: e[0]
                    },
                    o = function(t, e, {
                        clamp: i = !0,
                        ease: n,
                        mixer: r
                    } = {}) {
                        let s = t.length;
                        if ((0, w.k)(s === e.length, "Both input and output ranges must be the same length"), 1 === s) return () => e[0];
                        if (2 === s && t[0] === t[1]) return () => e[1];
                        t[0] > t[s - 1] && (t = [...t].reverse(), e = [...e].reverse());
                        let o = function(t, e, i) {
                                let n = [],
                                    r = i || J,
                                    s = t.length - 1;
                                for (let i = 0; i < s; i++) {
                                    let s = r(t[i], t[i + 1]);
                                    if (e) {
                                        let t = Array.isArray(e) ? e[i] || x.Z : e;
                                        s = (0, k.z)(t, s)
                                    }
                                    n.push(s)
                                }
                                return n
                            }(e, n, r),
                            a = o.length,
                            l = e => {
                                let i = 0;
                                if (a > 1)
                                    for (; i < t.length - 2 && !(e < t[i + 1]); i++);
                                let n = (0, j.Y)(t[i], t[i + 1], e);
                                return o[i](n)
                            };
                        return i ? e => l((0, R.u)(t[0], t[s - 1], e)) : l
                    }((i && i.length === e.length ? i : (0, Q.Y)(e)).map(e => e * t), e, {
                        ease: Array.isArray(r) ? r : e.map(() => r || C.mZ).splice(0, e.length - 1)
                    });
                return {
                    calculatedDuration: t,
                    next: e => (s.value = o(e), s.done = e >= t, s)
                }
            }
            var te = i(19323);
            let ti = t => {
                    let e = ({
                        timestamp: e
                    }) => t(e);
                    return {
                        start: () => m.Wi.update(e, !0),
                        stop: () => (0, m.Pn)(e),
                        now: () => m.frameData.isProcessing ? m.frameData.timestamp : v.X.now()
                    }
                },
                tn = {
                    decay: E,
                    inertia: E,
                    tween: tt,
                    keyframes: tt,
                    spring: A.S
                },
                tr = t => t / 100;
            class ts extends S {
                constructor({
                    KeyframeResolver: t = P.e,
                    ...e
                }) {
                    super(e), this.holdTime = null, this.startTime = null, this.cancelTime = null, this.currentTime = 0, this.playbackSpeed = 1, this.pendingPlayState = "running", this.state = "idle";
                    let {
                        name: i,
                        motionValue: n,
                        keyframes: r
                    } = this.options, s = (t, e) => this.onKeyframesResolved(t, e);
                    i && n && n.owner ? this.resolver = n.owner.resolveKeyframes(r, s, i, n) : this.resolver = new t(r, s, i, n), this.resolver.scheduleResolve()
                }
                initPlayback(t) {
                    let e, i;
                    let {
                        type: n = "keyframes",
                        repeat: r = 0,
                        repeatDelay: s = 0,
                        repeatType: o,
                        velocity: a = 0
                    } = this.options, l = tn[n] || tt;
                    l !== tt && "number" != typeof t[0] && (e = (0, k.z)(tr, J(t[0], t[1])), t = [0, 100]);
                    let u = l({ ...this.options,
                        keyframes: t
                    });
                    "mirror" === o && (i = l({ ...this.options,
                        keyframes: [...t].reverse(),
                        velocity: -a
                    })), null === u.calculatedDuration && (u.calculatedDuration = (0, te.i)(u));
                    let {
                        calculatedDuration: h
                    } = u, c = h + s;
                    return {
                        generator: u,
                        mirroredGenerator: i,
                        mapPercentToKeyframes: e,
                        calculatedDuration: h,
                        resolvedDuration: c,
                        totalDuration: c * (r + 1) - s
                    }
                }
                onPostResolved() {
                    let {
                        autoplay: t = !0
                    } = this.options;
                    this.play(), "paused" !== this.pendingPlayState && t ? this.state = this.pendingPlayState : this.pause()
                }
                tick(t, e = !1) {
                    let {
                        resolved: i
                    } = this;
                    if (!i) {
                        let {
                            keyframes: t
                        } = this.options;
                        return {
                            done: !0,
                            value: t[t.length - 1]
                        }
                    }
                    let {
                        finalKeyframe: n,
                        generator: r,
                        mirroredGenerator: s,
                        mapPercentToKeyframes: o,
                        keyframes: a,
                        calculatedDuration: l,
                        totalDuration: u,
                        resolvedDuration: h
                    } = i;
                    if (null === this.startTime) return r.next(0);
                    let {
                        delay: c,
                        repeat: d,
                        repeatType: p,
                        repeatDelay: m,
                        onUpdate: v
                    } = this.options;
                    this.speed > 0 ? this.startTime = Math.min(this.startTime, t) : this.speed < 0 && (this.startTime = Math.min(t - u / this.speed, this.startTime)), e ? this.currentTime = t : null !== this.holdTime ? this.currentTime = this.holdTime : this.currentTime = Math.round(t - this.startTime) * this.speed;
                    let g = this.currentTime - c * (this.speed >= 0 ? 1 : -1),
                        y = this.speed >= 0 ? g < 0 : g > u;
                    this.currentTime = Math.max(g, 0), "finished" === this.state && null === this.holdTime && (this.currentTime = u);
                    let x = this.currentTime,
                        P = r;
                    if (d) {
                        let t = Math.min(this.currentTime, u) / h,
                            e = Math.floor(t),
                            i = t % 1;
                        !i && t >= 1 && (i = 1), 1 === i && e--, (e = Math.min(e, d + 1)) % 2 && ("reverse" === p ? (i = 1 - i, m && (i -= m / h)) : "mirror" === p && (P = s)), x = (0, R.u)(0, 1, i) * h
                    }
                    let w = y ? {
                        done: !1,
                        value: a[0]
                    } : P.next(x);
                    o && (w.value = o(w.value));
                    let {
                        done: b
                    } = w;
                    y || null === l || (b = this.speed >= 0 ? this.currentTime >= u : this.currentTime <= 0);
                    let T = null === this.holdTime && ("finished" === this.state || "running" === this.state && b);
                    return T && void 0 !== n && (w.value = f(a, this.options, n)), v && v(w.value), T && this.finish(), w
                }
                get duration() {
                    let {
                        resolved: t
                    } = this;
                    return t ? (0, n.X)(t.calculatedDuration) : 0
                }
                get time() {
                    return (0, n.X)(this.currentTime)
                }
                set time(t) {
                    t = (0, n.w)(t), this.currentTime = t, null !== this.holdTime || 0 === this.speed ? this.holdTime = t : this.driver && (this.startTime = this.driver.now() - t / this.speed)
                }
                get speed() {
                    return this.playbackSpeed
                }
                set speed(t) {
                    let e = this.playbackSpeed !== t;
                    this.playbackSpeed = t, e && (this.time = (0, n.X)(this.currentTime))
                }
                play() {
                    if (this.resolver.isScheduled || this.resolver.resume(), !this._resolved) {
                        this.pendingPlayState = "running";
                        return
                    }
                    if (this.isStopped) return;
                    let {
                        driver: t = ti,
                        onPlay: e
                    } = this.options;
                    this.driver || (this.driver = t(t => this.tick(t))), e && e();
                    let i = this.driver.now();
                    null !== this.holdTime ? this.startTime = i - this.holdTime : this.startTime && "finished" !== this.state || (this.startTime = i), "finished" === this.state && this.updateFinishedPromise(), this.cancelTime = this.startTime, this.holdTime = null, this.state = "running", this.driver.start()
                }
                pause() {
                    var t;
                    if (!this._resolved) {
                        this.pendingPlayState = "paused";
                        return
                    }
                    this.state = "paused", this.holdTime = null !== (t = this.currentTime) && void 0 !== t ? t : 0
                }
                stop() {
                    if (this.resolver.cancel(), this.isStopped = !0, "idle" === this.state) return;
                    this.teardown();
                    let {
                        onStop: t
                    } = this.options;
                    t && t()
                }
                complete() {
                    "running" !== this.state && this.play(), this.pendingPlayState = this.state = "finished", this.holdTime = null
                }
                finish() {
                    this.teardown(), this.state = "finished";
                    let {
                        onComplete: t
                    } = this.options;
                    t && t()
                }
                cancel() {
                    null !== this.cancelTime && this.tick(this.cancelTime), this.teardown(), this.updateFinishedPromise()
                }
                teardown() {
                    this.state = "idle", this.stopDriver(), this.resolveFinishedPromise(), this.updateFinishedPromise(), this.startTime = this.cancelTime = null, this.resolver.cancel()
                }
                stopDriver() {
                    this.driver && (this.driver.stop(), this.driver = void 0)
                }
                sample(t) {
                    return this.startTime = 0, this.tick(t, !0)
                }
            }
            let to = t => Array.isArray(t) && "number" == typeof t[0],
                ta = ([t, e, i, n]) => `cubic-bezier(${t}, ${e}, ${i}, ${n})`,
                tl = {
                    linear: "linear",
                    ease: "ease",
                    easeIn: "ease-in",
                    easeOut: "ease-out",
                    easeInOut: "ease-in-out",
                    circIn: ta([0, .65, .55, 1]),
                    circOut: ta([.55, 0, 1, .45]),
                    backIn: ta([.31, .01, .66, -.59]),
                    backOut: ta([.33, 1.53, .69, .99])
                },
                tu = (0, y.X)(() => Object.hasOwnProperty.call(Element.prototype, "animate")),
                th = new Set(["opacity", "clipPath", "filter", "transform"]);
            class tc extends S {
                constructor(t) {
                    super(t);
                    let {
                        name: e,
                        motionValue: i,
                        keyframes: n
                    } = this.options;
                    this.resolver = new g.s(n, (t, e) => this.onKeyframesResolved(t, e), e, i), this.resolver.scheduleResolve()
                }
                initPlayback(t, e) {
                    var i, n;
                    let {
                        duration: r = 300,
                        times: s,
                        ease: o,
                        type: a,
                        motionValue: l,
                        name: u
                    } = this.options;
                    if (!(null === (i = l.owner) || void 0 === i ? void 0 : i.current)) return !1;
                    if ("spring" === (n = this.options).type || "backgroundColor" === n.name || ! function t(e) {
                            return !!(!e || "string" == typeof e && tl[e] || to(e) || Array.isArray(e) && e.every(t))
                        }(n.ease)) {
                        let {
                            onComplete: e,
                            onUpdate: i,
                            motionValue: n,
                            ...l
                        } = this.options, u = function(t, e) {
                            let i = new ts({ ...e,
                                    keyframes: t,
                                    repeat: 0,
                                    delay: 0,
                                    isGenerator: !0
                                }),
                                n = {
                                    done: !1,
                                    value: t[0]
                                },
                                r = [],
                                s = 0;
                            for (; !n.done && s < 2e4;) r.push((n = i.sample(s)).value), s += 10;
                            return {
                                times: void 0,
                                keyframes: r,
                                duration: s - 10,
                                ease: "linear"
                            }
                        }(t, l);
                        1 === (t = u.keyframes).length && (t[1] = t[0]), r = u.duration, s = u.times, o = u.ease, a = "keyframes"
                    }
                    let h = function(t, e, i, {
                        delay: n = 0,
                        duration: r = 300,
                        repeat: s = 0,
                        repeatType: o = "loop",
                        ease: a,
                        times: l
                    } = {}) {
                        let u = {
                            [e]: i
                        };
                        l && (u.offset = l);
                        let h = function t(e) {
                            if (e) return to(e) ? ta(e) : Array.isArray(e) ? e.map(t) : tl[e]
                        }(a);
                        return Array.isArray(h) && (u.easing = h), t.animate(u, {
                            delay: n,
                            duration: r,
                            easing: Array.isArray(h) ? "linear" : h,
                            fill: "both",
                            iterations: s + 1,
                            direction: "reverse" === o ? "alternate" : "normal"
                        })
                    }(l.owner.current, u, t, { ...this.options,
                        duration: r,
                        times: s,
                        ease: o
                    });
                    return h.startTime = v.X.now(), this.pendingTimeline ? (h.timeline = this.pendingTimeline, this.pendingTimeline = void 0) : h.onfinish = () => {
                        let {
                            onComplete: i
                        } = this.options;
                        l.set(f(t, this.options, e)), i && i(), this.cancel(), this.resolveFinishedPromise()
                    }, {
                        animation: h,
                        duration: r,
                        times: s,
                        type: a,
                        ease: o,
                        keyframes: t
                    }
                }
                get duration() {
                    let {
                        resolved: t
                    } = this;
                    if (!t) return 0;
                    let {
                        duration: e
                    } = t;
                    return (0, n.X)(e)
                }
                get time() {
                    let {
                        resolved: t
                    } = this;
                    if (!t) return 0;
                    let {
                        animation: e
                    } = t;
                    return (0, n.X)(e.currentTime || 0)
                }
                set time(t) {
                    let {
                        resolved: e
                    } = this;
                    if (!e) return;
                    let {
                        animation: i
                    } = e;
                    i.currentTime = (0, n.w)(t)
                }
                get speed() {
                    let {
                        resolved: t
                    } = this;
                    if (!t) return 1;
                    let {
                        animation: e
                    } = t;
                    return e.playbackRate
                }
                set speed(t) {
                    let {
                        resolved: e
                    } = this;
                    if (!e) return;
                    let {
                        animation: i
                    } = e;
                    i.playbackRate = t
                }
                get state() {
                    let {
                        resolved: t
                    } = this;
                    if (!t) return "idle";
                    let {
                        animation: e
                    } = t;
                    return e.playState
                }
                attachTimeline(t) {
                    if (this._resolved) {
                        let {
                            resolved: e
                        } = this;
                        if (!e) return x.Z;
                        let {
                            animation: i
                        } = e;
                        i.timeline = t, i.onfinish = null
                    } else this.pendingTimeline = t;
                    return x.Z
                }
                play() {
                    if (this.isStopped) return;
                    let {
                        resolved: t
                    } = this;
                    if (!t) return;
                    let {
                        animation: e
                    } = t;
                    "finished" === e.playState && this.updateFinishedPromise(), e.play()
                }
                pause() {
                    let {
                        resolved: t
                    } = this;
                    if (!t) return;
                    let {
                        animation: e
                    } = t;
                    e.pause()
                }
                stop() {
                    if (this.resolver.cancel(), this.isStopped = !0, "idle" === this.state) return;
                    let {
                        resolved: t
                    } = this;
                    if (!t) return;
                    let {
                        animation: e,
                        keyframes: i,
                        duration: r,
                        type: s,
                        ease: o,
                        times: a
                    } = t;
                    if ("idle" !== e.playState && "finished" !== e.playState) {
                        if (this.time) {
                            let {
                                motionValue: t,
                                onUpdate: e,
                                onComplete: l,
                                ...u
                            } = this.options, h = new ts({ ...u,
                                keyframes: i,
                                duration: r,
                                type: s,
                                ease: o,
                                times: a,
                                isGenerator: !0
                            }), c = (0, n.w)(this.time);
                            t.setWithVelocity(h.sample(c - 10).value, h.sample(c).value, 10)
                        }
                        this.cancel()
                    }
                }
                complete() {
                    let {
                        resolved: t
                    } = this;
                    t && t.animation.finish()
                }
                cancel() {
                    let {
                        resolved: t
                    } = this;
                    t && t.animation.cancel()
                }
                static supports(t) {
                    let {
                        motionValue: e,
                        name: i,
                        repeatDelay: n,
                        repeatType: r,
                        damping: s,
                        type: o
                    } = t;
                    return tu() && i && th.has(i) && e && e.owner && e.owner.current instanceof HTMLElement && !e.owner.getProps().onUpdate && !n && "mirror" !== r && 0 !== s && "inertia" !== o
                }
            }
            let td = (t, e, i, r = {}, s, o) => a => {
                let l = (0, h.e)(r, t) || {},
                    p = l.delay || r.delay || 0,
                    {
                        elapsed: v = 0
                    } = r;
                v -= (0, n.w)(p);
                let g = {
                    keyframes: Array.isArray(i) ? i : [null, i],
                    ease: "easeOut",
                    velocity: e.getVelocity(),
                    ...l,
                    delay: -v,
                    onUpdate: t => {
                        e.set(t), l.onUpdate && l.onUpdate(t)
                    },
                    onComplete: () => {
                        a(), l.onComplete && l.onComplete()
                    },
                    name: t,
                    motionValue: e,
                    element: o ? void 0 : s
                };
                (0, h.r)(l) || (g = { ...g,
                    ...u(t, g)
                }), g.duration && (g.duration = (0, n.w)(g.duration)), g.repeatDelay && (g.repeatDelay = (0, n.w)(g.repeatDelay)), void 0 !== g.from && (g.keyframes[0] = g.from);
                let y = !1;
                if (!1 === g.type && (g.duration = 0, 0 === g.delay && (y = !0)), (d.current || c.c.skipAnimations) && (y = !0, g.duration = 0, g.delay = 0), y && !o && void 0 !== e.get()) {
                    let t = f(g.keyframes, l);
                    if (void 0 !== t) {
                        m.Wi.update(() => {
                            g.onUpdate(t), g.onComplete()
                        });
                        return
                    }
                }
                return !o && tc.supports(g) ? new tc(g) : new ts(g)
            }
        },
        52014: function(t, e, i) {
            i.d(e, {
                D: function() {
                    return o
                }
            });
            var n = i(49622),
                r = i(83299),
                s = i(82702);

            function o(t, e, i) {
                let o = (0, s.i)(t) ? t : (0, r.BX)(t);
                return o.start((0, n.v)("", o, e, i)), o.animation
            }
        },
        31258: function(t, e, i) {
            i.d(e, {
                w: function() {
                    return d
                }
            });
            var n = i(60618),
                r = i(69043),
                s = i(49622),
                o = i(62212),
                a = i(30698),
                l = i(83299),
                u = i(1148),
                h = i(95566),
                c = i(14205);

            function d(t, e, {
                delay: i = 0,
                transitionOverride: d,
                type: p
            } = {}) {
                var f;
                let {
                    transition: m = t.getDefaultTransition(),
                    transitionEnd: v,
                    ...g
                } = e, y = t.getValue("willChange");
                d && (m = d);
                let x = [],
                    P = p && t.animationState && t.animationState.getState()[p];
                for (let e in g) {
                    let a = t.getValue(e, null !== (f = t.latestValues[e]) && void 0 !== f ? f : null),
                        l = g[e];
                    if (void 0 === l || P && function({
                            protectedKeys: t,
                            needsAnimating: e
                        }, i) {
                            let n = t.hasOwnProperty(i) && !0 !== e[i];
                            return e[i] = !1, n
                        }(P, e)) continue;
                    let u = {
                            delay: i,
                            elapsed: 0,
                            ...(0, h.e)(m || {}, e)
                        },
                        c = !1;
                    if (window.HandoffAppearAnimations) {
                        let i = t.getProps()[r.M];
                        if (i) {
                            let t = window.HandoffAppearAnimations(i, e);
                            null !== t && (u.elapsed = t, c = !0)
                        }
                    }
                    a.start((0, s.v)(e, a, l, t.shouldReduceMotion && n.G.has(e) ? {
                        type: !1
                    } : u, t, c));
                    let d = a.animation;
                    d && ((0, o.L)(y) && (y.add(e), d.then(() => y.remove(e))), x.push(d))
                }
                return v && Promise.all(x).then(() => {
                    c.Wi.update(() => {
                        v && function(t, e) {
                            let {
                                transitionEnd: i = {},
                                transition: n = {},
                                ...r
                            } = (0, u.x)(t, e) || {};
                            for (let e in r = { ...r,
                                    ...i
                                }) {
                                let i = (0, a.Y)(r[e]);
                                t.hasValue(e) ? t.getValue(e).set(i) : t.addValue(e, (0, l.BX)(i))
                            }
                        }(t, v)
                    })
                }), x
            }
        },
        69043: function(t, e, i) {
            i.d(e, {
                M: function() {
                    return n
                }
            });
            let n = "data-" + (0, i(65998).D)("framerAppearId")
        },
        54633: function(t, e, i) {
            i.d(e, {
                H: function() {
                    return n
                }
            });

            function n(t) {
                return null !== t && "object" == typeof t && "function" == typeof t.start
            }
        },
        60561: function(t, e, i) {
            i.d(e, {
                C: function() {
                    return n
                }
            });
            let n = t => Array.isArray(t)
        },
        95566: function(t, e, i) {
            function n({
                when: t,
                delay: e,
                delayChildren: i,
                staggerChildren: n,
                staggerDirection: r,
                repeat: s,
                repeatType: o,
                repeatDelay: a,
                from: l,
                elapsed: u,
                ...h
            }) {
                return !!Object.keys(h).length
            }

            function r(t, e) {
                return t[e] || t.default || t
            }
            i.d(e, {
                e: function() {
                    return r
                },
                r: function() {
                    return n
                }
            })
        },
        93449: function(t, e, i) {
            i.d(e, {
                _: function() {
                    return n
                }
            });
            let n = (0, i(2265).createContext)({
                transformPagePoint: t => t,
                isStatic: !1,
                reducedMotion: "never"
            })
        },
        84354: function(t, e, i) {
            i.d(e, {
                Bn: function() {
                    return o
                },
                X7: function() {
                    return a
                },
                Z7: function() {
                    return s
                }
            });
            var n = i(47932),
                r = i(18841);
            let s = t => 1 - Math.sin(Math.acos(t)),
                o = (0, r.M)(s),
                a = (0, n.o)(s)
        },
        64718: function(t, e, i) {
            i.d(e, {
                _: function() {
                    return s
                }
            });
            var n = i(3393);
            let r = (t, e, i) => (((1 - 3 * i + 3 * e) * t + (3 * i - 6 * e)) * t + 3 * e) * t;

            function s(t, e, i, s) {
                if (t === e && i === s) return n.Z;
                let o = e => (function(t, e, i, n, s) {
                    let o, a;
                    let l = 0;
                    do(o = r(a = e + (i - e) / 2, n, s) - t) > 0 ? i = a : e = a; while (Math.abs(o) > 1e-7 && ++l < 12);
                    return a
                })(e, 0, 1, t, i);
                return t => 0 === t || 1 === t ? t : r(o(t), e, s)
            }
        },
        39569: function(t, e, i) {
            i.d(e, {
                Vv: function() {
                    return s
                },
                YQ: function() {
                    return r
                },
                mZ: function() {
                    return o
                }
            });
            var n = i(64718);
            let r = (0, n._)(.42, 0, 1, 1),
                s = (0, n._)(0, 0, .58, 1),
                o = (0, n._)(.42, 0, .58, 1)
        },
        47932: function(t, e, i) {
            i.d(e, {
                o: function() {
                    return n
                }
            });
            let n = t => e => e <= .5 ? t(2 * e) / 2 : (2 - t(2 * (1 - e))) / 2
        },
        18841: function(t, e, i) {
            i.d(e, {
                M: function() {
                    return n
                }
            });
            let n = t => e => 1 - t(1 - e)
        },
        10113: function(t, e, i) {
            i.d(e, {
                N: function() {
                    return n
                }
            });
            let n = t => Array.isArray(t) && "number" != typeof t[0]
        },
        47544: function(t, e, i) {
            i.d(e, {
                R: function() {
                    return f
                }
            });
            var n = i(29908),
                r = i(64718),
                s = i(3393),
                o = i(39569),
                a = i(84354),
                l = i(47932),
                u = i(18841);
            let h = (0, r._)(.33, 1.53, .69, .99),
                c = (0, u.M)(h),
                d = (0, l.o)(c),
                p = {
                    linear: s.Z,
                    easeIn: o.YQ,
                    easeInOut: o.mZ,
                    easeOut: o.Vv,
                    circIn: a.Z7,
                    circInOut: a.X7,
                    circOut: a.Bn,
                    backIn: c,
                    backInOut: d,
                    backOut: h,
                    anticipate: t => (t *= 2) < 1 ? .5 * c(t) : .5 * (2 - Math.pow(2, -10 * (t - 1)))
                },
                f = t => {
                    if (Array.isArray(t)) {
                        (0, n.k)(4 === t.length, "Cubic bezier arrays must contain four numerical values.");
                        let [e, i, s, o] = t;
                        return (0, r._)(e, i, s, o)
                    }
                    return "string" == typeof t ? ((0, n.k)(void 0 !== p[t], `Invalid easing type '${t}'`), p[t]) : t
                }
        },
        67839: function(t, e, i) {
            i.d(e, {
                Z: function() {
                    return o
                }
            });
            var n = i(36832);
            class r {
                constructor() {
                    this.order = [], this.scheduled = new Set
                }
                add(t) {
                    if (!this.scheduled.has(t)) return this.scheduled.add(t), this.order.push(t), !0
                }
                remove(t) {
                    let e = this.order.indexOf(t); - 1 !== e && (this.order.splice(e, 1), this.scheduled.delete(t))
                }
                clear() {
                    this.order.length = 0, this.scheduled.clear()
                }
            }
            let s = ["read", "resolveKeyframes", "update", "preRender", "render", "postRender"];

            function o(t, e) {
                let i = !1,
                    o = !0,
                    a = {
                        delta: 0,
                        timestamp: 0,
                        isProcessing: !1
                    },
                    l = s.reduce((t, e) => (t[e] = function(t) {
                        let e = new r,
                            i = new r,
                            n = 0,
                            s = !1,
                            o = !1,
                            a = new WeakSet,
                            l = {
                                schedule: (t, r = !1, o = !1) => {
                                    let l = o && s,
                                        u = l ? e : i;
                                    return r && a.add(t), u.add(t) && l && s && (n = e.order.length), t
                                },
                                cancel: t => {
                                    i.remove(t), a.delete(t)
                                },
                                process: r => {
                                    if (s) {
                                        o = !0;
                                        return
                                    }
                                    if (s = !0, [e, i] = [i, e], i.clear(), n = e.order.length)
                                        for (let i = 0; i < n; i++) {
                                            let n = e.order[i];
                                            a.has(n) && (l.schedule(n), t()), n(r)
                                        }
                                    s = !1, o && (o = !1, l.process(r))
                                }
                            };
                        return l
                    }(() => i = !0), t), {}),
                    u = t => {
                        l[t].process(a)
                    },
                    h = () => {
                        let r = n.c.useManualTiming ? a.timestamp : performance.now();
                        i = !1, a.delta = o ? 1e3 / 60 : Math.max(Math.min(r - a.timestamp, 40), 1), a.timestamp = r, a.isProcessing = !0, s.forEach(u), a.isProcessing = !1, i && e && (o = !1, t(h))
                    },
                    c = () => {
                        i = !0, o = !0, a.isProcessing || t(h)
                    };
                return {
                    schedule: s.reduce((t, e) => {
                        let n = l[e];
                        return t[e] = (t, e = !1, r = !1) => (i || c(), n.schedule(t, e, r)), t
                    }, {}),
                    cancel: t => s.forEach(e => l[e].cancel(t)),
                    state: a,
                    steps: l
                }
            }
        },
        14205: function(t, e, i) {
            i.d(e, {
                Pn: function() {
                    return s
                },
                S6: function() {
                    return a
                },
                Wi: function() {
                    return r
                },
                frameData: function() {
                    return o
                }
            });
            var n = i(3393);
            let {
                schedule: r,
                cancel: s,
                state: o,
                steps: a
            } = (0, i(67839).Z)("undefined" != typeof requestAnimationFrame ? requestAnimationFrame : n.Z, !0)
        },
        33791: function(t, e, i) {
            let n;
            i.d(e, {
                X: function() {
                    return a
                }
            });
            var r = i(36832),
                s = i(14205);

            function o() {
                n = void 0
            }
            let a = {
                now: () => (void 0 === n && a.set(s.frameData.isProcessing || r.c.useManualTiming ? s.frameData.timestamp : performance.now()), n),
                set: t => {
                    n = t, queueMicrotask(o)
                }
            }
        },
        25223: function(t, e, i) {
            i.d(e, {
                A: function() {
                    return r
                }
            });
            let n = {
                    animation: ["animate", "variants", "whileHover", "whileTap", "exit", "whileInView", "whileFocus", "whileDrag"],
                    exit: ["exit"],
                    drag: ["drag", "dragControls"],
                    focus: ["whileFocus"],
                    hover: ["whileHover", "onHoverStart", "onHoverEnd"],
                    tap: ["whileTap", "onTap", "onTapStart", "onTapCancel"],
                    pan: ["onPan", "onPanStart", "onPanSessionStart", "onPanEnd"],
                    inView: ["whileInView", "onViewportEnter", "onViewportLeave"],
                    layout: ["layout", "layoutId"]
                },
                r = {};
            for (let t in n) r[t] = {
                isEnabled: e => n[t].some(t => !!e[t])
            }
        },
        5403: function(t, e, i) {
            i.d(e, {
                j: function() {
                    return s
                }
            });
            var n = i(67381),
                r = i(60618);

            function s(t, {
                layout: e,
                layoutId: i
            }) {
                return r.G.has(t) || t.startsWith("origin") || (e || void 0 !== i) && (!!n.P[t] || "opacity" === t)
            }
        },
        49068: function(t, e, i) {
            function n({
                top: t,
                left: e,
                right: i,
                bottom: n
            }) {
                return {
                    x: {
                        min: e,
                        max: i
                    },
                    y: {
                        min: t,
                        max: n
                    }
                }
            }

            function r({
                x: t,
                y: e
            }) {
                return {
                    top: e.min,
                    right: t.max,
                    bottom: e.max,
                    left: t.min
                }
            }

            function s(t, e) {
                if (!e) return t;
                let i = e({
                        x: t.left,
                        y: t.top
                    }),
                    n = e({
                        x: t.right,
                        y: t.bottom
                    });
                return {
                    top: i.y,
                    left: i.x,
                    bottom: n.y,
                    right: n.x
                }
            }
            i.d(e, {
                d7: function() {
                    return s
                },
                i8: function() {
                    return n
                },
                z2: function() {
                    return r
                }
            })
        },
        25015: function(t, e, i) {
            i.d(e, {
                D2: function() {
                    return m
                },
                YY: function() {
                    return u
                },
                am: function() {
                    return c
                },
                o2: function() {
                    return l
                },
                q2: function() {
                    return s
                }
            });
            var n = i(5312),
                r = i(44352);

            function s(t, e, i) {
                return i + e * (t - i)
            }

            function o(t, e, i, n, r) {
                return void 0 !== r && (t = n + r * (t - n)), n + i * (t - n) + e
            }

            function a(t, e = 0, i = 1, n, r) {
                t.min = o(t.min, e, i, n, r), t.max = o(t.max, e, i, n, r)
            }

            function l(t, {
                x: e,
                y: i
            }) {
                a(t.x, e.translate, e.scale, e.originPoint), a(t.y, i.translate, i.scale, i.originPoint)
            }

            function u(t, e, i, n = !1) {
                let s, o;
                let a = i.length;
                if (a) {
                    e.x = e.y = 1;
                    for (let u = 0; u < a; u++) {
                        o = (s = i[u]).projectionDelta;
                        let a = s.instance;
                        (!a || !a.style || "contents" !== a.style.display) && (n && s.options.layoutScroll && s.scroll && s !== s.root && m(t, {
                            x: -s.scroll.offset.x,
                            y: -s.scroll.offset.y
                        }), o && (e.x *= o.x.scale, e.y *= o.y.scale, l(t, o)), n && (0, r.ud)(s.latestValues) && m(t, s.latestValues))
                    }
                    e.x = h(e.x), e.y = h(e.y)
                }
            }

            function h(t) {
                return Number.isInteger(t) ? t : t > 1.0000000000001 || t < .999999999999 ? t : 1
            }

            function c(t, e) {
                t.min = t.min + e, t.max = t.max + e
            }

            function d(t, e, [i, r, s]) {
                let o = void 0 !== e[s] ? e[s] : .5,
                    l = (0, n.t)(t.min, t.max, o);
                a(t, e[i], e[r], l, e.scale)
            }
            let p = ["x", "scaleX", "originX"],
                f = ["y", "scaleY", "originY"];

            function m(t, e) {
                d(t.x, e, p), d(t.y, e, f)
            }
        },
        24884: function(t, e, i) {
            i.d(e, {
                dO: function() {
                    return o
                },
                wc: function() {
                    return r
                }
            });
            let n = () => ({
                    translate: 0,
                    scale: 1,
                    origin: 0,
                    originPoint: 0
                }),
                r = () => ({
                    x: n(),
                    y: n()
                }),
                s = () => ({
                    min: 0,
                    max: 0
                }),
                o = () => ({
                    x: s(),
                    y: s()
                })
        },
        67381: function(t, e, i) {
            i.d(e, {
                B: function() {
                    return r
                },
                P: function() {
                    return n
                }
            });
            let n = {};

            function r(t) {
                Object.assign(n, t)
            }
        },
        44352: function(t, e, i) {
            function n(t) {
                return void 0 === t || 1 === t
            }

            function r({
                scale: t,
                scaleX: e,
                scaleY: i
            }) {
                return !n(t) || !n(e) || !n(i)
            }

            function s(t) {
                return r(t) || o(t) || t.z || t.rotate || t.rotateX || t.rotateY || t.skewX || t.skewY
            }

            function o(t) {
                var e, i;
                return (e = t.x) && "0%" !== e || (i = t.y) && "0%" !== i
            }
            i.d(e, {
                D_: function() {
                    return o
                },
                Lj: function() {
                    return r
                },
                ud: function() {
                    return s
                }
            })
        },
        30411: function(t, e, i) {
            i.d(e, {
                J: function() {
                    return s
                },
                z: function() {
                    return o
                }
            });
            var n = i(49068),
                r = i(25015);

            function s(t, e) {
                return (0, n.i8)((0, n.d7)(t.getBoundingClientRect(), e))
            }

            function o(t, e, i) {
                let n = s(t, i),
                    {
                        scroll: o
                    } = e;
                return o && ((0, r.am)(n.x, o.offset.x), (0, r.am)(n.y, o.offset.y)), n
            }
        },
        20928: function(t, e, i) {
            i.d(e, {
                s: function() {
                    return d
                }
            });
            var n = i(96894),
                r = i(29908),
                s = i(34829),
                o = i(57126);
            let a = /^var\(--(?:([\w-]+)|([\w-]+), ?([a-zA-Z\d ()%#.,-]+))\)/u;
            var l = i(22756),
                u = i(61921),
                h = i(54178),
                c = i(23462);
            class d extends h.e {
                constructor(t, e, i, n) {
                    super(t, e, i, n, null == n ? void 0 : n.owner, !0)
                }
                readKeyframes() {
                    let {
                        unresolvedKeyframes: t,
                        element: e,
                        name: i
                    } = this;
                    if (!e.current) return;
                    super.readKeyframes();
                    for (let i = 0; i < t.length; i++) {
                        let n = t[i];
                        if ("string" == typeof n && (0, o.t)(n)) {
                            let l = function t(e, i, n = 1) {
                                (0, r.k)(n <= 4, `Max CSS variable fallback depth detected in property "${e}". This may indicate a circular fallback dependency.`);
                                let [l, u] = function(t) {
                                    let e = a.exec(t);
                                    if (!e) return [, ];
                                    let [, i, n, r] = e;
                                    return [`--${null!=i?i:n}`, r]
                                }(e);
                                if (!l) return;
                                let h = window.getComputedStyle(i).getPropertyValue(l);
                                if (h) {
                                    let t = h.trim();
                                    return (0, s.P)(t) ? parseFloat(t) : t
                                }
                                return (0, o.t)(u) ? t(u, i, n + 1) : u
                            }(n, e.current);
                            void 0 !== l && (t[i] = l)
                        }
                    }
                    if (!l.z2.has(i) || 2 !== t.length) return this.resolveNoneKeyframes();
                    let [n, h] = t, c = (0, u.C)(n), d = (0, u.C)(h);
                    if (c !== d) {
                        if ((0, l.mP)(c) && (0, l.mP)(d))
                            for (let e = 0; e < t.length; e++) {
                                let i = t[e];
                                "string" == typeof i && (t[e] = parseFloat(i))
                            } else this.needsMeasurement = !0
                    }
                }
                resolveNoneKeyframes() {
                    let {
                        unresolvedKeyframes: t,
                        name: e
                    } = this, i = [];
                    for (let e = 0; e < t.length; e++) {
                        var r;
                        ("number" == typeof(r = t[e]) ? 0 === r : null === r || "none" === r || "0" === r || (0, n.W)(r)) && i.push(e)
                    }
                    i.length && function(t, e, i) {
                        let n, r = 0;
                        for (; r < t.length && !n;) "string" == typeof t[r] && "none" !== t[r] && "0" !== t[r] && (n = t[r]), r++;
                        if (n && i)
                            for (let r of e) t[r] = (0, c.T)(i, n)
                    }(t, i, e)
                }
                measureInitialState() {
                    let {
                        element: t,
                        unresolvedKeyframes: e,
                        name: i
                    } = this;
                    if (!t.current) return;
                    "height" === i && (this.suspendedScrollY = window.pageYOffset), this.measuredOrigin = l.lw[i](t.measureViewportBox(), window.getComputedStyle(t.current)), e[0] = this.measuredOrigin;
                    let n = e[e.length - 1];
                    void 0 !== n && t.getValue(i, n).jump(n, !1)
                }
                measureEndState() {
                    var t;
                    let {
                        element: e,
                        name: i,
                        unresolvedKeyframes: n
                    } = this;
                    if (!e.current) return;
                    let r = e.getValue(i);
                    r && r.jump(this.measuredOrigin, !1);
                    let s = n.length - 1,
                        o = n[s];
                    n[s] = l.lw[i](e.measureViewportBox(), window.getComputedStyle(e.current)), null !== o && (this.finalKeyframe = o), (null === (t = this.removedTransforms) || void 0 === t ? void 0 : t.length) && this.removedTransforms.forEach(([t, i]) => {
                        e.getValue(t).set(i)
                    }), this.resolveNoneKeyframes()
                }
            }
        },
        70176: function(t, e, i) {
            i.d(e, {
                J: function() {
                    return O
                }
            });
            var n = i(24884),
                r = i(98285),
                s = i(61702);
            let o = {
                    current: null
                },
                a = {
                    current: !1
                };
            var l = i(52685),
                u = i(83299),
                h = i(62212),
                c = i(82702),
                d = i(60618),
                p = i(79739),
                f = i(16930),
                m = i(51422),
                v = i(25223),
                g = i(41867),
                y = i(48854),
                x = i(54178),
                P = i(34829),
                w = i(96894),
                b = i(22809),
                T = i(92263),
                S = i(61921),
                A = i(94707);
            let V = [...S.$, b.$, T.P],
                E = t => V.find((0, A.l)(t));
            var C = i(23462),
                D = i(14205);
            let M = Object.keys(v.A),
                R = M.length,
                k = ["AnimationStart", "AnimationComplete", "Update", "BeforeLayoutMeasure", "LayoutMeasure", "LayoutAnimationStart", "LayoutAnimationComplete"],
                j = g.V.length;
            class L {
                constructor({
                    parent: t,
                    props: e,
                    presenceContext: i,
                    reducedMotionConfig: n,
                    blockInitialAnimation: r,
                    visualState: s
                }, o = {}) {
                    this.resolveKeyframes = (t, e, i, n) => new this.KeyframeResolver(t, e, i, n, this), this.current = null, this.children = new Set, this.isVariantNode = !1, this.isControllingVariants = !1, this.shouldReduceMotion = null, this.values = new Map, this.KeyframeResolver = x.e, this.features = {}, this.valueSubscriptions = new Map, this.prevMotionValues = {}, this.events = {}, this.propEventSubscriptions = {}, this.notifyUpdate = () => this.notify("Update", this.latestValues), this.render = () => {
                        this.current && (this.triggerBuild(), this.renderInstance(this.current, this.renderState, this.props.style, this.projection))
                    }, this.scheduleRender = () => D.Wi.render(this.render, !1, !0);
                    let {
                        latestValues: a,
                        renderState: l
                    } = s;
                    this.latestValues = a, this.baseTarget = { ...a
                    }, this.initialValues = e.initial ? { ...a
                    } : {}, this.renderState = l, this.parent = t, this.props = e, this.presenceContext = i, this.depth = t ? t.depth + 1 : 0, this.reducedMotionConfig = n, this.options = o, this.blockInitialAnimation = !!r, this.isControllingVariants = (0, p.G)(e), this.isVariantNode = (0, p.M)(e), this.isVariantNode && (this.variantChildren = new Set), this.manuallyAnimateOnMount = !!(t && t.current);
                    let {
                        willChange: u,
                        ...d
                    } = this.scrapeMotionValuesFromProps(e, {}, this);
                    for (let t in d) {
                        let e = d[t];
                        void 0 !== a[t] && (0, c.i)(e) && (e.set(a[t], !1), (0, h.L)(u) && u.add(t))
                    }
                }
                scrapeMotionValuesFromProps(t, e, i) {
                    return {}
                }
                mount(t) {
                    this.current = t, y.R.set(t, this), this.projection && !this.projection.instance && this.projection.mount(t), this.parent && this.isVariantNode && !this.isControllingVariants && (this.removeFromVariantTree = this.parent.addVariantChild(this)), this.values.forEach((t, e) => this.bindToMotionValue(e, t)), a.current || function() {
                        if (a.current = !0, s.j) {
                            if (window.matchMedia) {
                                let t = window.matchMedia("(prefers-reduced-motion)"),
                                    e = () => o.current = t.matches;
                                t.addListener(e), e()
                            } else o.current = !1
                        }
                    }(), this.shouldReduceMotion = "never" !== this.reducedMotionConfig && ("always" === this.reducedMotionConfig || o.current), this.parent && this.parent.children.add(this), this.update(this.props, this.presenceContext)
                }
                unmount() {
                    for (let t in y.R.delete(this.current), this.projection && this.projection.unmount(), (0, D.Pn)(this.notifyUpdate), (0, D.Pn)(this.render), this.valueSubscriptions.forEach(t => t()), this.removeFromVariantTree && this.removeFromVariantTree(), this.parent && this.parent.children.delete(this), this.events) this.events[t].clear();
                    for (let t in this.features) this.features[t].unmount();
                    this.current = null
                }
                bindToMotionValue(t, e) {
                    let i = d.G.has(t),
                        n = e.on("change", e => {
                            this.latestValues[t] = e, this.props.onUpdate && D.Wi.preRender(this.notifyUpdate), i && this.projection && (this.projection.isTransformDirty = !0)
                        }),
                        r = e.on("renderRequest", this.scheduleRender);
                    this.valueSubscriptions.set(t, () => {
                        n(), r(), e.owner && e.stop()
                    })
                }
                sortNodePosition(t) {
                    return this.current && this.sortInstanceNodePosition && this.type === t.type ? this.sortInstanceNodePosition(this.current, t.current) : 0
                }
                loadFeatures({
                    children: t,
                    ...e
                }, i, n, s) {
                    let o, a;
                    for (let t = 0; t < R; t++) {
                        let i = M[t],
                            {
                                isEnabled: n,
                                Feature: r,
                                ProjectionNode: s,
                                MeasureLayout: l
                            } = v.A[i];
                        s && (o = s), n(e) && (!this.features[i] && r && (this.features[i] = new r(this)), l && (a = l))
                    }
                    if (("html" === this.type || "svg" === this.type) && !this.projection && o) {
                        this.projection = new o(this.latestValues, this.parent && this.parent.projection);
                        let {
                            layoutId: t,
                            layout: i,
                            drag: n,
                            dragConstraints: a,
                            layoutScroll: l,
                            layoutRoot: u
                        } = e;
                        this.projection.setOptions({
                            layoutId: t,
                            layout: i,
                            alwaysMeasureLayout: !!n || a && (0, r.I)(a),
                            visualElement: this,
                            scheduleRender: () => this.scheduleRender(),
                            animationType: "string" == typeof i ? i : "both",
                            initialPromotionConfig: s,
                            layoutScroll: l,
                            layoutRoot: u
                        })
                    }
                    return a
                }
                updateFeatures() {
                    for (let t in this.features) {
                        let e = this.features[t];
                        e.isMounted ? e.update() : (e.mount(), e.isMounted = !0)
                    }
                }
                triggerBuild() {
                    this.build(this.renderState, this.latestValues, this.options, this.props)
                }
                measureViewportBox() {
                    return this.current ? this.measureInstanceViewportBox(this.current, this.props) : (0, n.dO)()
                }
                getStaticValue(t) {
                    return this.latestValues[t]
                }
                setStaticValue(t, e) {
                    this.latestValues[t] = e
                }
                update(t, e) {
                    (t.transformTemplate || this.props.transformTemplate) && this.scheduleRender(), this.prevProps = this.props, this.props = t, this.prevPresenceContext = this.presenceContext, this.presenceContext = e;
                    for (let e = 0; e < k.length; e++) {
                        let i = k[e];
                        this.propEventSubscriptions[i] && (this.propEventSubscriptions[i](), delete this.propEventSubscriptions[i]);
                        let n = t["on" + i];
                        n && (this.propEventSubscriptions[i] = this.on(i, n))
                    }
                    this.prevMotionValues = function(t, e, i) {
                        let {
                            willChange: n
                        } = e;
                        for (let r in e) {
                            let s = e[r],
                                o = i[r];
                            if ((0, c.i)(s)) t.addValue(r, s), (0, h.L)(n) && n.add(r);
                            else if ((0, c.i)(o)) t.addValue(r, (0, u.BX)(s, {
                                owner: t
                            })), (0, h.L)(n) && n.remove(r);
                            else if (o !== s) {
                                if (t.hasValue(r)) {
                                    let e = t.getValue(r);
                                    !0 === e.liveStyle ? e.jump(s) : e.hasAnimated || e.set(s)
                                } else {
                                    let e = t.getStaticValue(r);
                                    t.addValue(r, (0, u.BX)(void 0 !== e ? e : s, {
                                        owner: t
                                    }))
                                }
                            }
                        }
                        for (let n in i) void 0 === e[n] && t.removeValue(n);
                        return e
                    }(this, this.scrapeMotionValuesFromProps(t, this.prevProps, this), this.prevMotionValues), this.handleChildMotionValue && this.handleChildMotionValue()
                }
                getProps() {
                    return this.props
                }
                getVariant(t) {
                    return this.props.variants ? this.props.variants[t] : void 0
                }
                getDefaultTransition() {
                    return this.props.transition
                }
                getTransformPagePoint() {
                    return this.props.transformPagePoint
                }
                getClosestVariantNode() {
                    return this.isVariantNode ? this : this.parent ? this.parent.getClosestVariantNode() : void 0
                }
                getVariantContext(t = !1) {
                    if (t) return this.parent ? this.parent.getVariantContext() : void 0;
                    if (!this.isControllingVariants) {
                        let t = this.parent && this.parent.getVariantContext() || {};
                        return void 0 !== this.props.initial && (t.initial = this.props.initial), t
                    }
                    let e = {};
                    for (let t = 0; t < j; t++) {
                        let i = g.V[t],
                            n = this.props[i];
                        ((0, f.$)(n) || !1 === n) && (e[i] = n)
                    }
                    return e
                }
                addVariantChild(t) {
                    let e = this.getClosestVariantNode();
                    if (e) return e.variantChildren && e.variantChildren.add(t), () => e.variantChildren.delete(t)
                }
                addValue(t, e) {
                    e !== this.values.get(t) && (this.removeValue(t), this.bindToMotionValue(t, e)), this.values.set(t, e), this.latestValues[t] = e.get()
                }
                removeValue(t) {
                    this.values.delete(t);
                    let e = this.valueSubscriptions.get(t);
                    e && (e(), this.valueSubscriptions.delete(t)), delete this.latestValues[t], this.removeValueFromRenderState(t, this.renderState)
                }
                hasValue(t) {
                    return this.values.has(t)
                }
                getValue(t, e) {
                    if (this.props.values && this.props.values[t]) return this.props.values[t];
                    let i = this.values.get(t);
                    return void 0 === i && void 0 !== e && (i = (0, u.BX)(null === e ? void 0 : e, {
                        owner: this
                    }), this.addValue(t, i)), i
                }
                readValue(t, e) {
                    var i;
                    let n = void 0 === this.latestValues[t] && this.current ? null !== (i = this.getBaseTargetFromProps(this.props, t)) && void 0 !== i ? i : this.readValueFromInstance(this.current, t, this.options) : this.latestValues[t];
                    return null != n && ("string" == typeof n && ((0, P.P)(n) || (0, w.W)(n)) ? n = parseFloat(n) : !E(n) && T.P.test(e) && (n = (0, C.T)(t, e)), this.setBaseTarget(t, (0, c.i)(n) ? n.get() : n)), (0, c.i)(n) ? n.get() : n
                }
                setBaseTarget(t, e) {
                    this.baseTarget[t] = e
                }
                getBaseTarget(t) {
                    var e, i;
                    let {
                        initial: n
                    } = this.props, r = "string" == typeof n || "object" == typeof n ? null === (i = (0, m.o)(this.props, n, null === (e = this.presenceContext) || void 0 === e ? void 0 : e.custom)) || void 0 === i ? void 0 : i[t] : void 0;
                    if (n && void 0 !== r) return r;
                    let s = this.getBaseTargetFromProps(this.props, t);
                    return void 0 === s || (0, c.i)(s) ? void 0 !== this.initialValues[t] && void 0 === r ? void 0 : this.baseTarget[t] : s
                }
                on(t, e) {
                    return this.events[t] || (this.events[t] = new l.L), this.events[t].add(e)
                }
                notify(t, ...e) {
                    this.events[t] && this.events[t].notify(...e)
                }
            }
            var F = i(20928);
            class O extends L {
                constructor() {
                    super(...arguments), this.KeyframeResolver = F.s
                }
                sortInstanceNodePosition(t, e) {
                    return 2 & t.compareDocumentPosition(e) ? 1 : -1
                }
                getBaseTargetFromProps(t, e) {
                    return t.style ? t.style[e] : void 0
                }
                removeValueFromRenderState(t, {
                    vars: e,
                    style: i
                }) {
                    delete e[t], delete i[t]
                }
            }
        },
        25507: function(t, e, i) {
            i.d(e, {
                E: function() {
                    return id
                }
            });
            var n, r = i(2265),
                s = i(93449);
            let o = (0, r.createContext)({}),
                a = (0, r.createContext)(null);
            var l = i(45526);
            let u = (0, r.createContext)({
                strict: !1
            });
            var h = i(69043);
            let {
                schedule: c,
                cancel: d
            } = (0, i(67839).Z)(queueMicrotask, !1);
            var p = i(98285),
                f = i(16930),
                m = i(79739);

            function v(t) {
                return Array.isArray(t) ? t.join(" ") : t
            }
            var g = i(25223),
                y = i(61702);
            let x = (0, r.createContext)({}),
                P = (0, r.createContext)({}),
                w = Symbol.for("motionComponentSymbol"),
                b = ["animate", "circle", "defs", "desc", "ellipse", "g", "image", "line", "filter", "marker", "mask", "metadata", "path", "pattern", "polygon", "polyline", "rect", "stop", "switch", "symbol", "svg", "text", "tspan", "use", "view"];

            function T(t) {
                if ("string" != typeof t || t.includes("-"));
                else if (b.indexOf(t) > -1 || /[A-Z]/u.test(t)) return !0;
                return !1
            }
            var S = i(5403),
                A = i(82702),
                V = i(25275);
            let E = () => ({
                style: {},
                transform: {},
                transformOrigin: {},
                vars: {}
            });

            function C(t, e, i) {
                for (let n in e)(0, A.i)(e[n]) || (0, S.j)(n, i) || (t[n] = e[n])
            }
            let D = new Set(["animate", "exit", "variants", "initial", "style", "values", "variants", "transition", "transformTemplate", "custom", "inherit", "onBeforeLayoutMeasure", "onAnimationStart", "onAnimationComplete", "onUpdate", "onDragStart", "onDrag", "onDragEnd", "onMeasureDragConstraints", "onDirectionLock", "onDragTransitionEnd", "_dragX", "_dragY", "onHoverStart", "onHoverEnd", "onViewportEnter", "onViewportLeave", "globalTapTarget", "ignoreStrict", "viewport"]);

            function M(t) {
                return t.startsWith("while") || t.startsWith("drag") && "draggable" !== t || t.startsWith("layout") || t.startsWith("onTap") || t.startsWith("onPan") || t.startsWith("onLayout") || D.has(t)
            }
            let R = t => !M(t);
            try {
                (n = require("@emotion/is-prop-valid").default) && (R = t => t.startsWith("on") ? !M(t) : n(t))
            } catch (t) {}
            var k = i(48348);
            let j = () => ({ ...E(),
                attrs: {}
            });
            var L = i(27612),
                F = i(81661),
                O = i(9548),
                B = i(54633),
                $ = i(51422),
                I = i(72435),
                U = i(30698);

            function W(t) {
                let e = (0, A.i)(t) ? t.get() : t;
                return (0, U.p)(e) ? e.toValue() : e
            }
            let N = t => (e, i) => {
                let n = (0, r.useContext)(o),
                    s = (0, r.useContext)(a),
                    l = () => (function({
                        scrapeMotionValuesFromProps: t,
                        createRenderState: e,
                        onMount: i
                    }, n, r, s) {
                        let o = {
                            latestValues: function(t, e, i, n) {
                                let r = {},
                                    s = n(t, {});
                                for (let t in s) r[t] = W(s[t]);
                                let {
                                    initial: o,
                                    animate: a
                                } = t, l = (0, m.G)(t), u = (0, m.M)(t);
                                e && u && !l && !1 !== t.inherit && (void 0 === o && (o = e.initial), void 0 === a && (a = e.animate));
                                let h = !!i && !1 === i.initial,
                                    c = (h = h || !1 === o) ? a : o;
                                return c && "boolean" != typeof c && !(0, B.H)(c) && (Array.isArray(c) ? c : [c]).forEach(e => {
                                    let i = (0, $.o)(t, e);
                                    if (!i) return;
                                    let {
                                        transitionEnd: n,
                                        transition: s,
                                        ...o
                                    } = i;
                                    for (let t in o) {
                                        let e = o[t];
                                        if (Array.isArray(e)) {
                                            let t = h ? e.length - 1 : 0;
                                            e = e[t]
                                        }
                                        null !== e && (r[t] = e)
                                    }
                                    for (let t in n) r[t] = n[t]
                                }), r
                            }(n, r, s, t),
                            renderState: e()
                        };
                        return i && (o.mount = t => i(n, t, o)), o
                    })(t, e, n, s);
                return i ? l() : (0, I.h)(l)
            };
            var X = i(14205);
            let z = {
                    useVisualState: N({
                        scrapeMotionValuesFromProps: O.U,
                        createRenderState: j,
                        onMount: (t, e, {
                            renderState: i,
                            latestValues: n
                        }) => {
                            X.Wi.read(() => {
                                try {
                                    i.dimensions = "function" == typeof e.getBBox ? e.getBBox() : e.getBoundingClientRect()
                                } catch (t) {
                                    i.dimensions = {
                                        x: 0,
                                        y: 0,
                                        width: 0,
                                        height: 0
                                    }
                                }
                            }), X.Wi.render(() => {
                                (0, k.i)(i, n, {
                                    enableHardwareAcceleration: !1
                                }, (0, L.a)(e.tagName), t.transformTemplate), (0, F.K)(e, i)
                            })
                        }
                    })
                },
                Y = {
                    useVisualState: N({
                        scrapeMotionValuesFromProps: i(46235).U,
                        createRenderState: E
                    })
                };

            function H(t, e, i, n = {
                passive: !0
            }) {
                return t.addEventListener(e, i, n), () => t.removeEventListener(e, i)
            }
            let K = t => "mouse" === t.pointerType ? "number" != typeof t.button || t.button <= 0 : !1 !== t.isPrimary;

            function Z(t, e = "page") {
                return {
                    point: {
                        x: t[e + "X"],
                        y: t[e + "Y"]
                    }
                }
            }
            let G = t => e => K(e) && t(e, Z(e));

            function _(t, e, i, n) {
                return H(t, e, G(i), n)
            }
            var q = i(19280);

            function J(t) {
                let e = null;
                return () => null === e && (e = t, () => {
                    e = null
                })
            }
            let Q = J("dragHorizontal"),
                tt = J("dragVertical");

            function te(t) {
                let e = !1;
                if ("y" === t) e = tt();
                else if ("x" === t) e = Q();
                else {
                    let t = Q(),
                        i = tt();
                    t && i ? e = () => {
                        t(), i()
                    } : (t && t(), i && i())
                }
                return e
            }

            function ti() {
                let t = te(!0);
                return !t || (t(), !1)
            }
            class tn {
                constructor(t) {
                    this.isMounted = !1, this.node = t
                }
                update() {}
            }

            function tr(t, e) {
                let i = "onHover" + (e ? "Start" : "End");
                return _(t.current, "pointer" + (e ? "enter" : "leave"), (n, r) => {
                    if ("touch" === n.pointerType || ti()) return;
                    let s = t.getProps();
                    t.animationState && s.whileHover && t.animationState.setActive("whileHover", e), s[i] && s[i](n, r)
                }, {
                    passive: !t.getProps()[i]
                })
            }
            class ts extends tn {
                mount() {
                    this.unmount = (0, q.z)(tr(this.node, !0), tr(this.node, !1))
                }
                unmount() {}
            }
            class to extends tn {
                constructor() {
                    super(...arguments), this.isActive = !1
                }
                onFocus() {
                    let t = !1;
                    try {
                        t = this.node.current.matches(":focus-visible")
                    } catch (e) {
                        t = !0
                    }
                    t && this.node.animationState && (this.node.animationState.setActive("whileFocus", !0), this.isActive = !0)
                }
                onBlur() {
                    this.isActive && this.node.animationState && (this.node.animationState.setActive("whileFocus", !1), this.isActive = !1)
                }
                mount() {
                    this.unmount = (0, q.z)(H(this.node.current, "focus", () => this.onFocus()), H(this.node.current, "blur", () => this.onBlur()))
                }
                unmount() {}
            }
            let ta = (t, e) => !!e && (t === e || ta(t, e.parentElement));
            var tl = i(3393);

            function tu(t, e) {
                if (!e) return;
                let i = new PointerEvent("pointer" + t);
                e(i, Z(i))
            }
            class th extends tn {
                constructor() {
                    super(...arguments), this.removeStartListeners = tl.Z, this.removeEndListeners = tl.Z, this.removeAccessibleListeners = tl.Z, this.startPointerPress = (t, e) => {
                        if (this.isPressing) return;
                        this.removeEndListeners();
                        let i = this.node.getProps(),
                            n = _(window, "pointerup", (t, e) => {
                                if (!this.checkPressEnd()) return;
                                let {
                                    onTap: i,
                                    onTapCancel: n,
                                    globalTapTarget: r
                                } = this.node.getProps();
                                r || ta(this.node.current, t.target) ? i && i(t, e) : n && n(t, e)
                            }, {
                                passive: !(i.onTap || i.onPointerUp)
                            }),
                            r = _(window, "pointercancel", (t, e) => this.cancelPress(t, e), {
                                passive: !(i.onTapCancel || i.onPointerCancel)
                            });
                        this.removeEndListeners = (0, q.z)(n, r), this.startPress(t, e)
                    }, this.startAccessiblePress = () => {
                        let t = H(this.node.current, "keydown", t => {
                                "Enter" !== t.key || this.isPressing || (this.removeEndListeners(), this.removeEndListeners = H(this.node.current, "keyup", t => {
                                    "Enter" === t.key && this.checkPressEnd() && tu("up", (t, e) => {
                                        let {
                                            onTap: i
                                        } = this.node.getProps();
                                        i && i(t, e)
                                    })
                                }), tu("down", (t, e) => {
                                    this.startPress(t, e)
                                }))
                            }),
                            e = H(this.node.current, "blur", () => {
                                this.isPressing && tu("cancel", (t, e) => this.cancelPress(t, e))
                            });
                        this.removeAccessibleListeners = (0, q.z)(t, e)
                    }
                }
                startPress(t, e) {
                    this.isPressing = !0;
                    let {
                        onTapStart: i,
                        whileTap: n
                    } = this.node.getProps();
                    n && this.node.animationState && this.node.animationState.setActive("whileTap", !0), i && i(t, e)
                }
                checkPressEnd() {
                    return this.removeEndListeners(), this.isPressing = !1, this.node.getProps().whileTap && this.node.animationState && this.node.animationState.setActive("whileTap", !1), !ti()
                }
                cancelPress(t, e) {
                    if (!this.checkPressEnd()) return;
                    let {
                        onTapCancel: i
                    } = this.node.getProps();
                    i && i(t, e)
                }
                mount() {
                    let t = this.node.getProps(),
                        e = _(t.globalTapTarget ? window : this.node.current, "pointerdown", this.startPointerPress, {
                            passive: !(t.onTapStart || t.onPointerStart)
                        }),
                        i = H(this.node.current, "focus", this.startAccessiblePress);
                    this.removeStartListeners = (0, q.z)(e, i)
                }
                unmount() {
                    this.removeStartListeners(), this.removeEndListeners(), this.removeAccessibleListeners()
                }
            }
            let tc = new WeakMap,
                td = new WeakMap,
                tp = t => {
                    let e = tc.get(t.target);
                    e && e(t)
                },
                tf = t => {
                    t.forEach(tp)
                },
                tm = {
                    some: 0,
                    all: 1
                };
            class tv extends tn {
                constructor() {
                    super(...arguments), this.hasEnteredView = !1, this.isInView = !1
                }
                startObserver() {
                    this.unmount();
                    let {
                        viewport: t = {}
                    } = this.node.getProps(), {
                        root: e,
                        margin: i,
                        amount: n = "some",
                        once: r
                    } = t, s = {
                        root: e ? e.current : void 0,
                        rootMargin: i,
                        threshold: "number" == typeof n ? n : tm[n]
                    };
                    return function(t, e, i) {
                        let n = function({
                            root: t,
                            ...e
                        }) {
                            let i = t || document;
                            td.has(i) || td.set(i, {});
                            let n = td.get(i),
                                r = JSON.stringify(e);
                            return n[r] || (n[r] = new IntersectionObserver(tf, {
                                root: t,
                                ...e
                            })), n[r]
                        }(e);
                        return tc.set(t, i), n.observe(t), () => {
                            tc.delete(t), n.unobserve(t)
                        }
                    }(this.node.current, s, t => {
                        let {
                            isIntersecting: e
                        } = t;
                        if (this.isInView === e || (this.isInView = e, r && !e && this.hasEnteredView)) return;
                        e && (this.hasEnteredView = !0), this.node.animationState && this.node.animationState.setActive("whileInView", e);
                        let {
                            onViewportEnter: i,
                            onViewportLeave: n
                        } = this.node.getProps(), s = e ? i : n;
                        s && s(t)
                    })
                }
                mount() {
                    this.startObserver()
                }
                update() {
                    if ("undefined" == typeof IntersectionObserver) return;
                    let {
                        props: t,
                        prevProps: e
                    } = this.node;
                    ["amount", "margin", "root"].some(function({
                        viewport: t = {}
                    }, {
                        viewport: e = {}
                    } = {}) {
                        return i => t[i] !== e[i]
                    }(t, e)) && this.startObserver()
                }
                unmount() {}
            }
            var tg = i(60561);

            function ty(t, e) {
                if (!Array.isArray(e)) return !1;
                let i = e.length;
                if (i !== t.length) return !1;
                for (let n = 0; n < i; n++)
                    if (e[n] !== t[n]) return !1;
                return !0
            }
            var tx = i(1148),
                tP = i(41867),
                tw = i(31258);

            function tb(t, e, i = {}) {
                var n;
                let r = (0, tx.x)(t, e, "exit" === i.type ? null === (n = t.presenceContext) || void 0 === n ? void 0 : n.custom : void 0),
                    {
                        transition: s = t.getDefaultTransition() || {}
                    } = r || {};
                i.transitionOverride && (s = i.transitionOverride);
                let o = r ? () => Promise.all((0, tw.w)(t, r, i)) : () => Promise.resolve(),
                    a = t.variantChildren && t.variantChildren.size ? (n = 0) => {
                        let {
                            delayChildren: r = 0,
                            staggerChildren: o,
                            staggerDirection: a
                        } = s;
                        return function(t, e, i = 0, n = 0, r = 1, s) {
                            let o = [],
                                a = (t.variantChildren.size - 1) * n,
                                l = 1 === r ? (t = 0) => t * n : (t = 0) => a - t * n;
                            return Array.from(t.variantChildren).sort(tT).forEach((t, n) => {
                                t.notify("AnimationStart", e), o.push(tb(t, e, { ...s,
                                    delay: i + l(n)
                                }).then(() => t.notify("AnimationComplete", e)))
                            }), Promise.all(o)
                        }(t, e, r + n, o, a, i)
                    } : () => Promise.resolve(),
                    {
                        when: l
                    } = s;
                if (!l) return Promise.all([o(), a(i.delay)]); {
                    let [t, e] = "beforeChildren" === l ? [o, a] : [a, o];
                    return t().then(() => e())
                }
            }

            function tT(t, e) {
                return t.sortNodePosition(e)
            }
            let tS = [...tP.e].reverse(),
                tA = tP.e.length;

            function tV(t = !1) {
                return {
                    isActive: t,
                    protectedKeys: {},
                    needsAnimating: {},
                    prevResolvedValues: {}
                }
            }
            class tE extends tn {
                constructor(t) {
                    super(t), t.animationState || (t.animationState = function(t) {
                        let e = e => Promise.all(e.map(({
                                animation: e,
                                options: i
                            }) => (function(t, e, i = {}) {
                                let n;
                                if (t.notify("AnimationStart", e), Array.isArray(e)) n = Promise.all(e.map(e => tb(t, e, i)));
                                else if ("string" == typeof e) n = tb(t, e, i);
                                else {
                                    let r = "function" == typeof e ? (0, tx.x)(t, e, i.custom) : e;
                                    n = Promise.all((0, tw.w)(t, r, i))
                                }
                                return n.then(() => {
                                    X.Wi.postRender(() => {
                                        t.notify("AnimationComplete", e)
                                    })
                                })
                            })(t, e, i))),
                            i = {
                                animate: tV(!0),
                                whileInView: tV(),
                                whileHover: tV(),
                                whileTap: tV(),
                                whileDrag: tV(),
                                whileFocus: tV(),
                                exit: tV()
                            },
                            n = !0,
                            r = e => (i, n) => {
                                var r;
                                let s = (0, tx.x)(t, n, "exit" === e ? null === (r = t.presenceContext) || void 0 === r ? void 0 : r.custom : void 0);
                                if (s) {
                                    let {
                                        transition: t,
                                        transitionEnd: e,
                                        ...n
                                    } = s;
                                    i = { ...i,
                                        ...n,
                                        ...e
                                    }
                                }
                                return i
                            };

                        function s(s) {
                            let o = t.getProps(),
                                a = t.getVariantContext(!0) || {},
                                l = [],
                                u = new Set,
                                h = {},
                                c = 1 / 0;
                            for (let e = 0; e < tA; e++) {
                                var d;
                                let p = tS[e],
                                    m = i[p],
                                    v = void 0 !== o[p] ? o[p] : a[p],
                                    g = (0, f.$)(v),
                                    y = p === s ? m.isActive : null;
                                !1 === y && (c = e);
                                let x = v === a[p] && v !== o[p] && g;
                                if (x && n && t.manuallyAnimateOnMount && (x = !1), m.protectedKeys = { ...h
                                    }, !m.isActive && null === y || !v && !m.prevProp || (0, B.H)(v) || "boolean" == typeof v) continue;
                                let P = (d = m.prevProp, ("string" == typeof v ? v !== d : !!Array.isArray(v) && !ty(v, d)) || p === s && m.isActive && !x && g || e > c && g),
                                    w = !1,
                                    b = Array.isArray(v) ? v : [v],
                                    T = b.reduce(r(p), {});
                                !1 === y && (T = {});
                                let {
                                    prevResolvedValues: S = {}
                                } = m, A = { ...S,
                                    ...T
                                }, V = e => {
                                    P = !0, u.has(e) && (w = !0, u.delete(e)), m.needsAnimating[e] = !0;
                                    let i = t.getValue(e);
                                    i && (i.liveStyle = !1)
                                };
                                for (let t in A) {
                                    let e = T[t],
                                        i = S[t];
                                    if (!h.hasOwnProperty(t))((0, tg.C)(e) && (0, tg.C)(i) ? ty(e, i) : e === i) ? void 0 !== e && u.has(t) ? V(t) : m.protectedKeys[t] = !0 : null != e ? V(t) : u.add(t)
                                }
                                m.prevProp = v, m.prevResolvedValues = T, m.isActive && (h = { ...h,
                                    ...T
                                }), n && t.blockInitialAnimation && (P = !1), P && (!x || w) && l.push(...b.map(t => ({
                                    animation: t,
                                    options: {
                                        type: p
                                    }
                                })))
                            }
                            if (u.size) {
                                let e = {};
                                u.forEach(i => {
                                    let n = t.getBaseTarget(i),
                                        r = t.getValue(i);
                                    r && (r.liveStyle = !0), e[i] = void 0 === n ? null : n
                                }), l.push({
                                    animation: e
                                })
                            }
                            let p = !!l.length;
                            return n && (!1 === o.initial || o.initial === o.animate) && !t.manuallyAnimateOnMount && (p = !1), n = !1, p ? e(l) : Promise.resolve()
                        }
                        return {
                            animateChanges: s,
                            setActive: function(e, n) {
                                var r;
                                if (i[e].isActive === n) return Promise.resolve();
                                null === (r = t.variantChildren) || void 0 === r || r.forEach(t => {
                                    var i;
                                    return null === (i = t.animationState) || void 0 === i ? void 0 : i.setActive(e, n)
                                }), i[e].isActive = n;
                                let o = s(e);
                                for (let t in i) i[t].protectedKeys = {};
                                return o
                            },
                            setAnimateFunction: function(i) {
                                e = i(t)
                            },
                            getState: () => i
                        }
                    }(t))
                }
                updateAnimationControlsSubscription() {
                    let {
                        animate: t
                    } = this.node.getProps();
                    this.unmount(), (0, B.H)(t) && (this.unmount = t.subscribe(this.node))
                }
                mount() {
                    this.updateAnimationControlsSubscription()
                }
                update() {
                    let {
                        animate: t
                    } = this.node.getProps(), {
                        animate: e
                    } = this.node.prevProps || {};
                    t !== e && this.updateAnimationControlsSubscription()
                }
                unmount() {}
            }
            let tC = 0;
            class tD extends tn {
                constructor() {
                    super(...arguments), this.id = tC++
                }
                update() {
                    if (!this.node.presenceContext) return;
                    let {
                        isPresent: t,
                        onExitComplete: e
                    } = this.node.presenceContext, {
                        isPresent: i
                    } = this.node.prevPresenceContext || {};
                    if (!this.node.animationState || t === i) return;
                    let n = this.node.animationState.setActive("exit", !t);
                    e && !t && n.then(() => e(this.id))
                }
                mount() {
                    let {
                        register: t
                    } = this.node.presenceContext || {};
                    t && (this.unmount = t(this.id))
                }
                unmount() {}
            }
            var tM = i(29908),
                tR = i(33303);
            let tk = (t, e) => Math.abs(t - e);
            class tj {
                constructor(t, e, {
                    transformPagePoint: i,
                    contextWindow: n,
                    dragSnapToOrigin: r = !1
                } = {}) {
                    if (this.startEvent = null, this.lastMoveEvent = null, this.lastMoveEventInfo = null, this.handlers = {}, this.contextWindow = window, this.updatePoint = () => {
                            var t, e;
                            if (!(this.lastMoveEvent && this.lastMoveEventInfo)) return;
                            let i = tO(this.lastMoveEventInfo, this.history),
                                n = null !== this.startEvent,
                                r = (t = i.offset, e = {
                                    x: 0,
                                    y: 0
                                }, Math.sqrt(tk(t.x, e.x) ** 2 + tk(t.y, e.y) ** 2) >= 3);
                            if (!n && !r) return;
                            let {
                                point: s
                            } = i, {
                                timestamp: o
                            } = X.frameData;
                            this.history.push({ ...s,
                                timestamp: o
                            });
                            let {
                                onStart: a,
                                onMove: l
                            } = this.handlers;
                            n || (a && a(this.lastMoveEvent, i), this.startEvent = this.lastMoveEvent), l && l(this.lastMoveEvent, i)
                        }, this.handlePointerMove = (t, e) => {
                            this.lastMoveEvent = t, this.lastMoveEventInfo = tL(e, this.transformPagePoint), X.Wi.update(this.updatePoint, !0)
                        }, this.handlePointerUp = (t, e) => {
                            this.end();
                            let {
                                onEnd: i,
                                onSessionEnd: n,
                                resumeAnimation: r
                            } = this.handlers;
                            if (this.dragSnapToOrigin && r && r(), !(this.lastMoveEvent && this.lastMoveEventInfo)) return;
                            let s = tO("pointercancel" === t.type ? this.lastMoveEventInfo : tL(e, this.transformPagePoint), this.history);
                            this.startEvent && i && i(t, s), n && n(t, s)
                        }, !K(t)) return;
                    this.dragSnapToOrigin = r, this.handlers = e, this.transformPagePoint = i, this.contextWindow = n || window;
                    let s = tL(Z(t), this.transformPagePoint),
                        {
                            point: o
                        } = s,
                        {
                            timestamp: a
                        } = X.frameData;
                    this.history = [{ ...o,
                        timestamp: a
                    }];
                    let {
                        onSessionStart: l
                    } = e;
                    l && l(t, tO(s, this.history)), this.removeListeners = (0, q.z)(_(this.contextWindow, "pointermove", this.handlePointerMove), _(this.contextWindow, "pointerup", this.handlePointerUp), _(this.contextWindow, "pointercancel", this.handlePointerUp))
                }
                updateHandlers(t) {
                    this.handlers = t
                }
                end() {
                    this.removeListeners && this.removeListeners(), (0, X.Pn)(this.updatePoint)
                }
            }

            function tL(t, e) {
                return e ? {
                    point: e(t.point)
                } : t
            }

            function tF(t, e) {
                return {
                    x: t.x - e.x,
                    y: t.y - e.y
                }
            }

            function tO({
                point: t
            }, e) {
                return {
                    point: t,
                    delta: tF(t, tB(e)),
                    offset: tF(t, e[0]),
                    velocity: function(t, e) {
                        if (t.length < 2) return {
                            x: 0,
                            y: 0
                        };
                        let i = t.length - 1,
                            n = null,
                            r = tB(t);
                        for (; i >= 0 && (n = t[i], !(r.timestamp - n.timestamp > (0, tR.w)(.1)));) i--;
                        if (!n) return {
                            x: 0,
                            y: 0
                        };
                        let s = (0, tR.X)(r.timestamp - n.timestamp);
                        if (0 === s) return {
                            x: 0,
                            y: 0
                        };
                        let o = {
                            x: (r.x - n.x) / s,
                            y: (r.y - n.y) / s
                        };
                        return o.x === 1 / 0 && (o.x = 0), o.y === 1 / 0 && (o.y = 0), o
                    }(e, 0)
                }
            }

            function tB(t) {
                return t[t.length - 1]
            }
            var t$ = i(16384),
                tI = i(5312);

            function tU(t) {
                return t.max - t.min
            }

            function tW(t, e = 0, i = .01) {
                return Math.abs(t - e) <= i
            }

            function tN(t, e, i, n = .5) {
                t.origin = n, t.originPoint = (0, tI.t)(e.min, e.max, t.origin), t.scale = tU(i) / tU(e), (tW(t.scale, 1, 1e-4) || isNaN(t.scale)) && (t.scale = 1), t.translate = (0, tI.t)(i.min, i.max, t.origin) - t.originPoint, (tW(t.translate) || isNaN(t.translate)) && (t.translate = 0)
            }

            function tX(t, e, i, n) {
                tN(t.x, e.x, i.x, n ? n.originX : void 0), tN(t.y, e.y, i.y, n ? n.originY : void 0)
            }

            function tz(t, e, i) {
                t.min = i.min + e.min, t.max = t.min + tU(e)
            }

            function tY(t, e, i) {
                t.min = e.min - i.min, t.max = t.min + tU(e)
            }

            function tH(t, e, i) {
                tY(t.x, e.x, i.x), tY(t.y, e.y, i.y)
            }
            var tK = i(22476);

            function tZ(t, e, i) {
                return {
                    min: void 0 !== e ? t.min + e : void 0,
                    max: void 0 !== i ? t.max + i - (t.max - t.min) : void 0
                }
            }

            function tG(t, e) {
                let i = e.min - t.min,
                    n = e.max - t.max;
                return e.max - e.min < t.max - t.min && ([i, n] = [n, i]), {
                    min: i,
                    max: n
                }
            }

            function t_(t, e, i) {
                return {
                    min: tq(t, e),
                    max: tq(t, i)
                }
            }

            function tq(t, e) {
                return "number" == typeof t ? t : t[e] || 0
            }
            var tJ = i(24884);

            function tQ(t) {
                return [t("x"), t("y")]
            }
            var t0 = i(30411),
                t1 = i(49068),
                t2 = i(72724),
                t3 = i(49622);
            let t5 = ({
                    current: t
                }) => t ? t.ownerDocument.defaultView : null,
                t6 = new WeakMap;
            class t9 {
                constructor(t) {
                    this.openGlobalLock = null, this.isDragging = !1, this.currentDirection = null, this.originPoint = {
                        x: 0,
                        y: 0
                    }, this.constraints = !1, this.hasMutatedConstraints = !1, this.elastic = (0, tJ.dO)(), this.visualElement = t
                }
                start(t, {
                    snapToCursor: e = !1
                } = {}) {
                    let {
                        presenceContext: i
                    } = this.visualElement;
                    if (i && !1 === i.isPresent) return;
                    let {
                        dragSnapToOrigin: n
                    } = this.getProps();
                    this.panSession = new tj(t, {
                        onSessionStart: t => {
                            let {
                                dragSnapToOrigin: i
                            } = this.getProps();
                            i ? this.pauseAnimation() : this.stopAnimation(), e && this.snapToCursor(Z(t, "page").point)
                        },
                        onStart: (t, e) => {
                            let {
                                drag: i,
                                dragPropagation: n,
                                onDragStart: r
                            } = this.getProps();
                            if (i && !n && (this.openGlobalLock && this.openGlobalLock(), this.openGlobalLock = te(i), !this.openGlobalLock)) return;
                            this.isDragging = !0, this.currentDirection = null, this.resolveConstraints(), this.visualElement.projection && (this.visualElement.projection.isAnimationBlocked = !0, this.visualElement.projection.target = void 0), tQ(t => {
                                let e = this.getAxisMotionValue(t).get() || 0;
                                if (t2.aQ.test(e)) {
                                    let {
                                        projection: i
                                    } = this.visualElement;
                                    if (i && i.layout) {
                                        let n = i.layout.layoutBox[t];
                                        if (n) {
                                            let t = tU(n);
                                            e = parseFloat(e) / 100 * t
                                        }
                                    }
                                }
                                this.originPoint[t] = e
                            }), r && r(t, e);
                            let {
                                animationState: s
                            } = this.visualElement;
                            s && s.setActive("whileDrag", !0)
                        },
                        onMove: (t, e) => {
                            let {
                                dragPropagation: i,
                                dragDirectionLock: n,
                                onDirectionLock: r,
                                onDrag: s
                            } = this.getProps();
                            if (!i && !this.openGlobalLock) return;
                            let {
                                offset: o
                            } = e;
                            if (n && null === this.currentDirection) {
                                this.currentDirection = function(t, e = 10) {
                                    let i = null;
                                    return Math.abs(t.y) > e ? i = "y" : Math.abs(t.x) > e && (i = "x"), i
                                }(o), null !== this.currentDirection && r && r(this.currentDirection);
                                return
                            }
                            this.updateAxis("x", e.point, o), this.updateAxis("y", e.point, o), this.visualElement.render(), s && s(t, e)
                        },
                        onSessionEnd: (t, e) => this.stop(t, e),
                        resumeAnimation: () => tQ(t => {
                            var e;
                            return "paused" === this.getAnimationState(t) && (null === (e = this.getAxisMotionValue(t).animation) || void 0 === e ? void 0 : e.play())
                        })
                    }, {
                        transformPagePoint: this.visualElement.getTransformPagePoint(),
                        dragSnapToOrigin: n,
                        contextWindow: t5(this.visualElement)
                    })
                }
                stop(t, e) {
                    let i = this.isDragging;
                    if (this.cancel(), !i) return;
                    let {
                        velocity: n
                    } = e;
                    this.startAnimation(n);
                    let {
                        onDragEnd: r
                    } = this.getProps();
                    r && r(t, e)
                }
                cancel() {
                    this.isDragging = !1;
                    let {
                        projection: t,
                        animationState: e
                    } = this.visualElement;
                    t && (t.isAnimationBlocked = !1), this.panSession && this.panSession.end(), this.panSession = void 0;
                    let {
                        dragPropagation: i
                    } = this.getProps();
                    !i && this.openGlobalLock && (this.openGlobalLock(), this.openGlobalLock = null), e && e.setActive("whileDrag", !1)
                }
                updateAxis(t, e, i) {
                    let {
                        drag: n
                    } = this.getProps();
                    if (!i || !t4(t, n, this.currentDirection)) return;
                    let r = this.getAxisMotionValue(t),
                        s = this.originPoint[t] + i[t];
                    this.constraints && this.constraints[t] && (s = function(t, {
                        min: e,
                        max: i
                    }, n) {
                        return void 0 !== e && t < e ? t = n ? (0, tI.t)(e, t, n.min) : Math.max(t, e) : void 0 !== i && t > i && (t = n ? (0, tI.t)(i, t, n.max) : Math.min(t, i)), t
                    }(s, this.constraints[t], this.elastic[t])), r.set(s)
                }
                resolveConstraints() {
                    var t;
                    let {
                        dragConstraints: e,
                        dragElastic: i
                    } = this.getProps(), n = this.visualElement.projection && !this.visualElement.projection.layout ? this.visualElement.projection.measure(!1) : null === (t = this.visualElement.projection) || void 0 === t ? void 0 : t.layout, r = this.constraints;
                    e && (0, p.I)(e) ? this.constraints || (this.constraints = this.resolveRefConstraints()) : e && n ? this.constraints = function(t, {
                        top: e,
                        left: i,
                        bottom: n,
                        right: r
                    }) {
                        return {
                            x: tZ(t.x, i, r),
                            y: tZ(t.y, e, n)
                        }
                    }(n.layoutBox, e) : this.constraints = !1, this.elastic = function(t = .35) {
                        return !1 === t ? t = 0 : !0 === t && (t = .35), {
                            x: t_(t, "left", "right"),
                            y: t_(t, "top", "bottom")
                        }
                    }(i), r !== this.constraints && n && this.constraints && !this.hasMutatedConstraints && tQ(t => {
                        this.getAxisMotionValue(t) && (this.constraints[t] = function(t, e) {
                            let i = {};
                            return void 0 !== e.min && (i.min = e.min - t.min), void 0 !== e.max && (i.max = e.max - t.min), i
                        }(n.layoutBox[t], this.constraints[t]))
                    })
                }
                resolveRefConstraints() {
                    var t;
                    let {
                        dragConstraints: e,
                        onMeasureDragConstraints: i
                    } = this.getProps();
                    if (!e || !(0, p.I)(e)) return !1;
                    let n = e.current;
                    (0, tM.k)(null !== n, "If `dragConstraints` is set as a React ref, that ref must be passed to another component's `ref` prop.");
                    let {
                        projection: r
                    } = this.visualElement;
                    if (!r || !r.layout) return !1;
                    let s = (0, t0.z)(n, r.root, this.visualElement.getTransformPagePoint()),
                        o = {
                            x: tG((t = r.layout.layoutBox).x, s.x),
                            y: tG(t.y, s.y)
                        };
                    if (i) {
                        let t = i((0, t1.z2)(o));
                        this.hasMutatedConstraints = !!t, t && (o = (0, t1.i8)(t))
                    }
                    return o
                }
                startAnimation(t) {
                    let {
                        drag: e,
                        dragMomentum: i,
                        dragElastic: n,
                        dragTransition: r,
                        dragSnapToOrigin: s,
                        onDragTransitionEnd: o
                    } = this.getProps(), a = this.constraints || {};
                    return Promise.all(tQ(o => {
                        if (!t4(o, e, this.currentDirection)) return;
                        let l = a && a[o] || {};
                        s && (l = {
                            min: 0,
                            max: 0
                        });
                        let u = {
                            type: "inertia",
                            velocity: i ? t[o] : 0,
                            bounceStiffness: n ? 200 : 1e6,
                            bounceDamping: n ? 40 : 1e7,
                            timeConstant: 750,
                            restDelta: 1,
                            restSpeed: 10,
                            ...r,
                            ...l
                        };
                        return this.startAxisValueAnimation(o, u)
                    })).then(o)
                }
                startAxisValueAnimation(t, e) {
                    let i = this.getAxisMotionValue(t);
                    return i.start((0, t3.v)(t, i, 0, e, this.visualElement))
                }
                stopAnimation() {
                    tQ(t => this.getAxisMotionValue(t).stop())
                }
                pauseAnimation() {
                    tQ(t => {
                        var e;
                        return null === (e = this.getAxisMotionValue(t).animation) || void 0 === e ? void 0 : e.pause()
                    })
                }
                getAnimationState(t) {
                    var e;
                    return null === (e = this.getAxisMotionValue(t).animation) || void 0 === e ? void 0 : e.state
                }
                getAxisMotionValue(t) {
                    let e = "_drag" + t.toUpperCase(),
                        i = this.visualElement.getProps();
                    return i[e] || this.visualElement.getValue(t, (i.initial ? i.initial[t] : void 0) || 0)
                }
                snapToCursor(t) {
                    tQ(e => {
                        let {
                            drag: i
                        } = this.getProps();
                        if (!t4(e, i, this.currentDirection)) return;
                        let {
                            projection: n
                        } = this.visualElement, r = this.getAxisMotionValue(e);
                        if (n && n.layout) {
                            let {
                                min: i,
                                max: s
                            } = n.layout.layoutBox[e];
                            r.set(t[e] - (0, tI.t)(i, s, .5))
                        }
                    })
                }
                scalePositionWithinConstraints() {
                    if (!this.visualElement.current) return;
                    let {
                        drag: t,
                        dragConstraints: e
                    } = this.getProps(), {
                        projection: i
                    } = this.visualElement;
                    if (!(0, p.I)(e) || !i || !this.constraints) return;
                    this.stopAnimation();
                    let n = {
                        x: 0,
                        y: 0
                    };
                    tQ(t => {
                        let e = this.getAxisMotionValue(t);
                        if (e) {
                            let i = e.get();
                            n[t] = function(t, e) {
                                let i = .5,
                                    n = tU(t),
                                    r = tU(e);
                                return r > n ? i = (0, t$.Y)(e.min, e.max - n, t.min) : n > r && (i = (0, t$.Y)(t.min, t.max - r, e.min)), (0, tK.u)(0, 1, i)
                            }({
                                min: i,
                                max: i
                            }, this.constraints[t])
                        }
                    });
                    let {
                        transformTemplate: r
                    } = this.visualElement.getProps();
                    this.visualElement.current.style.transform = r ? r({}, "") : "none", i.root && i.root.updateScroll(), i.updateLayout(), this.resolveConstraints(), tQ(e => {
                        if (!t4(e, t, null)) return;
                        let i = this.getAxisMotionValue(e),
                            {
                                min: r,
                                max: s
                            } = this.constraints[e];
                        i.set((0, tI.t)(r, s, n[e]))
                    })
                }
                addListeners() {
                    if (!this.visualElement.current) return;
                    t6.set(this.visualElement, this);
                    let t = _(this.visualElement.current, "pointerdown", t => {
                            let {
                                drag: e,
                                dragListener: i = !0
                            } = this.getProps();
                            e && i && this.start(t)
                        }),
                        e = () => {
                            let {
                                dragConstraints: t
                            } = this.getProps();
                            (0, p.I)(t) && (this.constraints = this.resolveRefConstraints())
                        },
                        {
                            projection: i
                        } = this.visualElement,
                        n = i.addEventListener("measure", e);
                    i && !i.layout && (i.root && i.root.updateScroll(), i.updateLayout()), e();
                    let r = H(window, "resize", () => this.scalePositionWithinConstraints()),
                        s = i.addEventListener("didUpdate", ({
                            delta: t,
                            hasLayoutChanged: e
                        }) => {
                            this.isDragging && e && (tQ(e => {
                                let i = this.getAxisMotionValue(e);
                                i && (this.originPoint[e] += t[e].translate, i.set(i.get() + t[e].translate))
                            }), this.visualElement.render())
                        });
                    return () => {
                        r(), t(), n(), s && s()
                    }
                }
                getProps() {
                    let t = this.visualElement.getProps(),
                        {
                            drag: e = !1,
                            dragDirectionLock: i = !1,
                            dragPropagation: n = !1,
                            dragConstraints: r = !1,
                            dragElastic: s = .35,
                            dragMomentum: o = !0
                        } = t;
                    return { ...t,
                        drag: e,
                        dragDirectionLock: i,
                        dragPropagation: n,
                        dragConstraints: r,
                        dragElastic: s,
                        dragMomentum: o
                    }
                }
            }

            function t4(t, e, i) {
                return (!0 === e || e === t) && (null === i || i === t)
            }
            class t8 extends tn {
                constructor(t) {
                    super(t), this.removeGroupControls = tl.Z, this.removeListeners = tl.Z, this.controls = new t9(t)
                }
                mount() {
                    let {
                        dragControls: t
                    } = this.node.getProps();
                    t && (this.removeGroupControls = t.subscribe(this.controls)), this.removeListeners = this.controls.addListeners() || tl.Z
                }
                unmount() {
                    this.removeGroupControls(), this.removeListeners()
                }
            }
            let t7 = t => (e, i) => {
                t && t(e, i)
            };
            class et extends tn {
                constructor() {
                    super(...arguments), this.removePointerDownListener = tl.Z
                }
                onPointerDown(t) {
                    this.session = new tj(t, this.createPanHandlers(), {
                        transformPagePoint: this.node.getTransformPagePoint(),
                        contextWindow: t5(this.node)
                    })
                }
                createPanHandlers() {
                    let {
                        onPanSessionStart: t,
                        onPanStart: e,
                        onPan: i,
                        onPanEnd: n
                    } = this.node.getProps();
                    return {
                        onSessionStart: t7(t),
                        onStart: t7(e),
                        onMove: i,
                        onEnd: (t, e) => {
                            delete this.session, n && n(t, e)
                        }
                    }
                }
                mount() {
                    this.removePointerDownListener = _(this.node.current, "pointerdown", t => this.onPointerDown(t))
                }
                update() {
                    this.session && this.session.updateHandlers(this.createPanHandlers())
                }
                unmount() {
                    this.removePointerDownListener(), this.session && this.session.end()
                }
            }
            let ee = {
                hasAnimatedSinceResize: !0,
                hasEverUpdated: !1
            };

            function ei(t, e) {
                return e.max === e.min ? 0 : t / (e.max - e.min) * 100
            }
            let en = {
                correct: (t, e) => {
                    if (!e.target) return t;
                    if ("string" == typeof t) {
                        if (!t2.px.test(t)) return t;
                        t = parseFloat(t)
                    }
                    let i = ei(t, e.target.x),
                        n = ei(t, e.target.y);
                    return `${i}% ${n}%`
                }
            };
            var er = i(92263),
                es = i(67381);
            class eo extends r.Component {
                componentDidMount() {
                    let {
                        visualElement: t,
                        layoutGroup: e,
                        switchLayoutGroup: i,
                        layoutId: n
                    } = this.props, {
                        projection: r
                    } = t;
                    (0, es.B)(el), r && (e.group && e.group.add(r), i && i.register && n && i.register(r), r.root.didUpdate(), r.addEventListener("animationComplete", () => {
                        this.safeToRemove()
                    }), r.setOptions({ ...r.options,
                        onExitComplete: () => this.safeToRemove()
                    })), ee.hasEverUpdated = !0
                }
                getSnapshotBeforeUpdate(t) {
                    let {
                        layoutDependency: e,
                        visualElement: i,
                        drag: n,
                        isPresent: r
                    } = this.props, s = i.projection;
                    return s && (s.isPresent = r, n || t.layoutDependency !== e || void 0 === e ? s.willUpdate() : this.safeToRemove(), t.isPresent === r || (r ? s.promote() : s.relegate() || X.Wi.postRender(() => {
                        let t = s.getStack();
                        t && t.members.length || this.safeToRemove()
                    }))), null
                }
                componentDidUpdate() {
                    let {
                        projection: t
                    } = this.props.visualElement;
                    t && (t.root.didUpdate(), c.postRender(() => {
                        !t.currentAnimation && t.isLead() && this.safeToRemove()
                    }))
                }
                componentWillUnmount() {
                    let {
                        visualElement: t,
                        layoutGroup: e,
                        switchLayoutGroup: i
                    } = this.props, {
                        projection: n
                    } = t;
                    n && (n.scheduleCheckAfterUnmount(), e && e.group && e.group.remove(n), i && i.deregister && i.deregister(n))
                }
                safeToRemove() {
                    let {
                        safeToRemove: t
                    } = this.props;
                    t && t()
                }
                render() {
                    return null
                }
            }

            function ea(t) {
                let [e, i] = function() {
                    let t = (0, r.useContext)(a);
                    if (null === t) return [!0, null];
                    let {
                        isPresent: e,
                        onExitComplete: i,
                        register: n
                    } = t, s = (0, r.useId)();
                    return (0, r.useEffect)(() => n(s), []), !e && i ? [!1, () => i && i(s)] : [!0]
                }(), n = (0, r.useContext)(x);
                return r.createElement(eo, { ...t,
                    layoutGroup: n,
                    switchLayoutGroup: (0, r.useContext)(P),
                    isPresent: e,
                    safeToRemove: i
                })
            }
            let el = {
                borderRadius: { ...en,
                    applyTo: ["borderTopLeftRadius", "borderTopRightRadius", "borderBottomLeftRadius", "borderBottomRightRadius"]
                },
                borderTopLeftRadius: en,
                borderTopRightRadius: en,
                borderBottomLeftRadius: en,
                borderBottomRightRadius: en,
                boxShadow: {
                    correct: (t, {
                        treeScale: e,
                        projectionDelta: i
                    }) => {
                        let n = er.P.parse(t);
                        if (n.length > 5) return t;
                        let r = er.P.createTransformer(t),
                            s = "number" != typeof n[0] ? 1 : 0,
                            o = i.x.scale * e.x,
                            a = i.y.scale * e.y;
                        n[0 + s] /= o, n[1 + s] /= a;
                        let l = (0, tI.t)(o, a, .5);
                        return "number" == typeof n[2 + s] && (n[2 + s] /= l), "number" == typeof n[3 + s] && (n[3 + s] /= l), r(n)
                    }
                }
            };
            var eu = i(52685),
                eh = i(84354);
            let ec = ["TopLeft", "TopRight", "BottomLeft", "BottomRight"],
                ed = ec.length,
                ep = t => "string" == typeof t ? parseFloat(t) : t,
                ef = t => "number" == typeof t || t2.px.test(t);

            function em(t, e) {
                return void 0 !== t[e] ? t[e] : t.borderRadius
            }
            let ev = ey(0, .5, eh.Bn),
                eg = ey(.5, .95, tl.Z);

            function ey(t, e, i) {
                return n => n < t ? 0 : n > e ? 1 : i((0, t$.Y)(t, e, n))
            }

            function ex(t, e) {
                t.min = e.min, t.max = e.max
            }

            function eP(t, e) {
                ex(t.x, e.x), ex(t.y, e.y)
            }
            var ew = i(25015);

            function eb(t, e, i, n, r) {
                return t -= e, t = (0, ew.q2)(t, 1 / i, n), void 0 !== r && (t = (0, ew.q2)(t, 1 / r, n)), t
            }

            function eT(t, e, [i, n, r], s, o) {
                ! function(t, e = 0, i = 1, n = .5, r, s = t, o = t) {
                    if (t2.aQ.test(e) && (e = parseFloat(e), e = (0, tI.t)(o.min, o.max, e / 100) - o.min), "number" != typeof e) return;
                    let a = (0, tI.t)(s.min, s.max, n);
                    t === s && (a -= e), t.min = eb(t.min, e, i, a, r), t.max = eb(t.max, e, i, a, r)
                }(t, e[i], e[n], e[r], e.scale, s, o)
            }
            let eS = ["x", "scaleX", "originX"],
                eA = ["y", "scaleY", "originY"];

            function eV(t, e, i, n) {
                eT(t.x, e, eS, i ? i.x : void 0, n ? n.x : void 0), eT(t.y, e, eA, i ? i.y : void 0, n ? n.y : void 0)
            }
            var eE = i(95566);

            function eC(t) {
                return 0 === t.translate && 1 === t.scale
            }

            function eD(t) {
                return eC(t.x) && eC(t.y)
            }

            function eM(t, e) {
                return Math.round(t.x.min) === Math.round(e.x.min) && Math.round(t.x.max) === Math.round(e.x.max) && Math.round(t.y.min) === Math.round(e.y.min) && Math.round(t.y.max) === Math.round(e.y.max)
            }

            function eR(t) {
                return tU(t.x) / tU(t.y)
            }
            var ek = i(50406);
            class ej {
                constructor() {
                    this.members = []
                }
                add(t) {
                    (0, ek.y4)(this.members, t), t.scheduleRender()
                }
                remove(t) {
                    if ((0, ek.cl)(this.members, t), t === this.prevLead && (this.prevLead = void 0), t === this.lead) {
                        let t = this.members[this.members.length - 1];
                        t && this.promote(t)
                    }
                }
                relegate(t) {
                    let e;
                    let i = this.members.findIndex(e => t === e);
                    if (0 === i) return !1;
                    for (let t = i; t >= 0; t--) {
                        let i = this.members[t];
                        if (!1 !== i.isPresent) {
                            e = i;
                            break
                        }
                    }
                    return !!e && (this.promote(e), !0)
                }
                promote(t, e) {
                    let i = this.lead;
                    if (t !== i && (this.prevLead = i, this.lead = t, t.show(), i)) {
                        i.instance && i.scheduleRender(), t.scheduleRender(), t.resumeFrom = i, e && (t.resumeFrom.preserveOpacity = !0), i.snapshot && (t.snapshot = i.snapshot, t.snapshot.latestValues = i.animationValues || i.latestValues), t.root && t.root.isUpdating && (t.isLayoutDirty = !0);
                        let {
                            crossfade: n
                        } = t.options;
                        !1 === n && i.hide()
                    }
                }
                exitAnimationComplete() {
                    this.members.forEach(t => {
                        let {
                            options: e,
                            resumingFrom: i
                        } = t;
                        e.onExitComplete && e.onExitComplete(), i && i.options.onExitComplete && i.options.onExitComplete()
                    })
                }
                scheduleRender() {
                    this.members.forEach(t => {
                        t.instance && t.scheduleRender(!1)
                    })
                }
                removeLeadSnapshot() {
                    this.lead && this.lead.snapshot && (this.lead.snapshot = void 0)
                }
            }

            function eL(t, e, i) {
                let n = "",
                    r = t.x.translate / e.x,
                    s = t.y.translate / e.y,
                    o = (null == i ? void 0 : i.z) || 0;
                if ((r || s || o) && (n = `translate3d(${r}px, ${s}px, ${o}px) `), (1 !== e.x || 1 !== e.y) && (n += `scale(${1/e.x}, ${1/e.y}) `), i) {
                    let {
                        rotate: t,
                        rotateX: e,
                        rotateY: r,
                        skewX: s,
                        skewY: o
                    } = i;
                    t && (n += `rotate(${t}deg) `), e && (n += `rotateX(${e}deg) `), r && (n += `rotateY(${r}deg) `), s && (n += `skewX(${s}deg) `), o && (n += `skewY(${o}deg) `)
                }
                let a = t.x.scale * e.x,
                    l = t.y.scale * e.y;
                return (1 !== a || 1 !== l) && (n += `scale(${a}, ${l})`), n || "none"
            }
            var eF = i(44352);
            let eO = (t, e) => t.depth - e.depth;
            class eB {
                constructor() {
                    this.children = [], this.isDirty = !1
                }
                add(t) {
                    (0, ek.y4)(this.children, t), this.isDirty = !0
                }
                remove(t) {
                    (0, ek.cl)(this.children, t), this.isDirty = !0
                }
                forEach(t) {
                    this.isDirty && this.children.sort(eO), this.isDirty = !1, this.children.forEach(t)
                }
            }
            var e$ = i(33791),
                eI = i(41937),
                eU = i(52014);
            let eW = ["", "X", "Y", "Z"],
                eN = {
                    visibility: "hidden"
                },
                eX = 0,
                ez = {
                    type: "projectionFrame",
                    totalNodes: 0,
                    resolvedTargetDeltas: 0,
                    recalculatedProjection: 0
                };

            function eY(t, e, i, n) {
                let {
                    latestValues: r
                } = e;
                r[t] && (i[t] = r[t], e.setStaticValue(t, 0), n && (n[t] = 0))
            }

            function eH({
                attachResizeListener: t,
                defaultParent: e,
                measureScroll: i,
                checkIsScrollRoot: n,
                resetTransform: r
            }) {
                return class {
                    constructor(t = {}, i = null == e ? void 0 : e()) {
                        this.id = eX++, this.animationId = 0, this.children = new Set, this.options = {}, this.isTreeAnimating = !1, this.isAnimationBlocked = !1, this.isLayoutDirty = !1, this.isProjectionDirty = !1, this.isSharedProjectionDirty = !1, this.isTransformDirty = !1, this.updateManuallyBlocked = !1, this.updateBlockedByResize = !1, this.isUpdating = !1, this.isSVG = !1, this.needsReset = !1, this.shouldResetTransform = !1, this.treeScale = {
                            x: 1,
                            y: 1
                        }, this.eventHandlers = new Map, this.hasTreeAnimated = !1, this.updateScheduled = !1, this.projectionUpdateScheduled = !1, this.checkUpdateFailed = () => {
                            this.isUpdating && (this.isUpdating = !1, this.clearAllSnapshots())
                        }, this.updateProjection = () => {
                            this.projectionUpdateScheduled = !1, ez.totalNodes = ez.resolvedTargetDeltas = ez.recalculatedProjection = 0, this.nodes.forEach(eG), this.nodes.forEach(e2), this.nodes.forEach(e3), this.nodes.forEach(e_), window.MotionDebug && window.MotionDebug.record(ez)
                        }, this.hasProjected = !1, this.isVisible = !0, this.animationProgress = 0, this.sharedNodes = new Map, this.latestValues = t, this.root = i ? i.root || i : this, this.path = i ? [...i.path, i] : [], this.parent = i, this.depth = i ? i.depth + 1 : 0;
                        for (let t = 0; t < this.path.length; t++) this.path[t].shouldResetTransform = !0;
                        this.root === this && (this.nodes = new eB)
                    }
                    addEventListener(t, e) {
                        return this.eventHandlers.has(t) || this.eventHandlers.set(t, new eu.L), this.eventHandlers.get(t).add(e)
                    }
                    notifyListeners(t, ...e) {
                        let i = this.eventHandlers.get(t);
                        i && i.notify(...e)
                    }
                    hasListeners(t) {
                        return this.eventHandlers.has(t)
                    }
                    mount(e, i = this.root.hasTreeAnimated) {
                        if (this.instance) return;
                        this.isSVG = (0, eI.v)(e), this.instance = e;
                        let {
                            layoutId: n,
                            layout: r,
                            visualElement: s
                        } = this.options;
                        if (s && !s.current && s.mount(e), this.root.nodes.add(this), this.parent && this.parent.children.add(this), i && (r || n) && (this.isLayoutDirty = !0), t) {
                            let i;
                            let n = () => this.root.updateBlockedByResize = !1;
                            t(e, () => {
                                this.root.updateBlockedByResize = !0, i && i(), i = function(t, e) {
                                    let i = e$.X.now(),
                                        n = ({
                                            timestamp: r
                                        }) => {
                                            let s = r - i;
                                            s >= e && ((0, X.Pn)(n), t(s - e))
                                        };
                                    return X.Wi.read(n, !0), () => (0, X.Pn)(n)
                                }(n, 250), ee.hasAnimatedSinceResize && (ee.hasAnimatedSinceResize = !1, this.nodes.forEach(e1))
                            })
                        }
                        n && this.root.registerSharedNode(n, this), !1 !== this.options.animate && s && (n || r) && this.addEventListener("didUpdate", ({
                            delta: t,
                            hasLayoutChanged: e,
                            hasRelativeTargetChanged: i,
                            layout: n
                        }) => {
                            if (this.isTreeAnimationBlocked()) {
                                this.target = void 0, this.relativeTarget = void 0;
                                return
                            }
                            let r = this.options.transition || s.getDefaultTransition() || e7,
                                {
                                    onLayoutAnimationStart: o,
                                    onLayoutAnimationComplete: a
                                } = s.getProps(),
                                l = !this.targetLayout || !eM(this.targetLayout, n) || i,
                                u = !e && i;
                            if (this.options.layoutRoot || this.resumeFrom && this.resumeFrom.instance || u || e && (l || !this.currentAnimation)) {
                                this.resumeFrom && (this.resumingFrom = this.resumeFrom, this.resumingFrom.resumingFrom = void 0), this.setAnimationOrigin(t, u);
                                let e = { ...(0, eE.e)(r, "layout"),
                                    onPlay: o,
                                    onComplete: a
                                };
                                (s.shouldReduceMotion || this.options.layoutRoot) && (e.delay = 0, e.type = !1), this.startAnimation(e)
                            } else e || e1(this), this.isLead() && this.options.onExitComplete && this.options.onExitComplete();
                            this.targetLayout = n
                        })
                    }
                    unmount() {
                        this.options.layoutId && this.willUpdate(), this.root.nodes.remove(this);
                        let t = this.getStack();
                        t && t.remove(this), this.parent && this.parent.children.delete(this), this.instance = void 0, (0, X.Pn)(this.updateProjection)
                    }
                    blockUpdate() {
                        this.updateManuallyBlocked = !0
                    }
                    unblockUpdate() {
                        this.updateManuallyBlocked = !1
                    }
                    isUpdateBlocked() {
                        return this.updateManuallyBlocked || this.updateBlockedByResize
                    }
                    isTreeAnimationBlocked() {
                        return this.isAnimationBlocked || this.parent && this.parent.isTreeAnimationBlocked() || !1
                    }
                    startUpdate() {
                        !this.isUpdateBlocked() && (this.isUpdating = !0, this.nodes && this.nodes.forEach(e5), this.animationId++)
                    }
                    getTransformTemplate() {
                        let {
                            visualElement: t
                        } = this.options;
                        return t && t.getProps().transformTemplate
                    }
                    willUpdate(t = !0) {
                        if (this.root.hasTreeAnimated = !0, this.root.isUpdateBlocked()) {
                            this.options.onExitComplete && this.options.onExitComplete();
                            return
                        }
                        if (this.root.isUpdating || this.root.startUpdate(), this.isLayoutDirty) return;
                        this.isLayoutDirty = !0;
                        for (let t = 0; t < this.path.length; t++) {
                            let e = this.path[t];
                            e.shouldResetTransform = !0, e.updateScroll("snapshot"), e.options.layoutRoot && e.willUpdate(!1)
                        }
                        let {
                            layoutId: e,
                            layout: i
                        } = this.options;
                        if (void 0 === e && !i) return;
                        let n = this.getTransformTemplate();
                        this.prevTransformTemplateValue = n ? n(this.latestValues, "") : void 0, this.updateSnapshot(), t && this.notifyListeners("willUpdate")
                    }
                    update() {
                        if (this.updateScheduled = !1, this.isUpdateBlocked()) {
                            this.unblockUpdate(), this.clearAllSnapshots(), this.nodes.forEach(eJ);
                            return
                        }
                        this.isUpdating || this.nodes.forEach(eQ), this.isUpdating = !1, window.HandoffCancelAllAnimations && window.HandoffCancelAllAnimations(), this.nodes.forEach(e0), this.nodes.forEach(eK), this.nodes.forEach(eZ), this.clearAllSnapshots();
                        let t = e$.X.now();
                        X.frameData.delta = (0, tK.u)(0, 1e3 / 60, t - X.frameData.timestamp), X.frameData.timestamp = t, X.frameData.isProcessing = !0, X.S6.update.process(X.frameData), X.S6.preRender.process(X.frameData), X.S6.render.process(X.frameData), X.frameData.isProcessing = !1
                    }
                    didUpdate() {
                        this.updateScheduled || (this.updateScheduled = !0, c.read(() => this.update()))
                    }
                    clearAllSnapshots() {
                        this.nodes.forEach(eq), this.sharedNodes.forEach(e6)
                    }
                    scheduleUpdateProjection() {
                        this.projectionUpdateScheduled || (this.projectionUpdateScheduled = !0, X.Wi.preRender(this.updateProjection, !1, !0))
                    }
                    scheduleCheckAfterUnmount() {
                        X.Wi.postRender(() => {
                            this.isLayoutDirty ? this.root.didUpdate() : this.root.checkUpdateFailed()
                        })
                    }
                    updateSnapshot() {
                        !this.snapshot && this.instance && (this.snapshot = this.measure())
                    }
                    updateLayout() {
                        if (!this.instance || (this.updateScroll(), !(this.options.alwaysMeasureLayout && this.isLead()) && !this.isLayoutDirty)) return;
                        if (this.resumeFrom && !this.resumeFrom.instance)
                            for (let t = 0; t < this.path.length; t++) this.path[t].updateScroll();
                        let t = this.layout;
                        this.layout = this.measure(!1), this.layoutCorrected = (0, tJ.dO)(), this.isLayoutDirty = !1, this.projectionDelta = void 0, this.notifyListeners("measure", this.layout.layoutBox);
                        let {
                            visualElement: e
                        } = this.options;
                        e && e.notify("LayoutMeasure", this.layout.layoutBox, t ? t.layoutBox : void 0)
                    }
                    updateScroll(t = "measure") {
                        let e = !!(this.options.layoutScroll && this.instance);
                        this.scroll && this.scroll.animationId === this.root.animationId && this.scroll.phase === t && (e = !1), e && (this.scroll = {
                            animationId: this.root.animationId,
                            phase: t,
                            isRoot: n(this.instance),
                            offset: i(this.instance)
                        })
                    }
                    resetTransform() {
                        if (!r) return;
                        let t = this.isLayoutDirty || this.shouldResetTransform,
                            e = this.projectionDelta && !eD(this.projectionDelta),
                            i = this.getTransformTemplate(),
                            n = i ? i(this.latestValues, "") : void 0,
                            s = n !== this.prevTransformTemplateValue;
                        t && (e || (0, eF.ud)(this.latestValues) || s) && (r(this.instance, n), this.shouldResetTransform = !1, this.scheduleRender())
                    }
                    measure(t = !0) {
                        var e;
                        let i = this.measurePageBox(),
                            n = this.removeElementScroll(i);
                        return t && (n = this.removeTransform(n)), ii((e = n).x), ii(e.y), {
                            animationId: this.root.animationId,
                            measuredBox: i,
                            layoutBox: n,
                            latestValues: {},
                            source: this.id
                        }
                    }
                    measurePageBox() {
                        let {
                            visualElement: t
                        } = this.options;
                        if (!t) return (0, tJ.dO)();
                        let e = t.measureViewportBox(),
                            {
                                scroll: i
                            } = this.root;
                        return i && ((0, ew.am)(e.x, i.offset.x), (0, ew.am)(e.y, i.offset.y)), e
                    }
                    removeElementScroll(t) {
                        let e = (0, tJ.dO)();
                        eP(e, t);
                        for (let i = 0; i < this.path.length; i++) {
                            let n = this.path[i],
                                {
                                    scroll: r,
                                    options: s
                                } = n;
                            if (n !== this.root && r && s.layoutScroll) {
                                if (r.isRoot) {
                                    eP(e, t);
                                    let {
                                        scroll: i
                                    } = this.root;
                                    i && ((0, ew.am)(e.x, -i.offset.x), (0, ew.am)(e.y, -i.offset.y))
                                }(0, ew.am)(e.x, r.offset.x), (0, ew.am)(e.y, r.offset.y)
                            }
                        }
                        return e
                    }
                    applyTransform(t, e = !1) {
                        let i = (0, tJ.dO)();
                        eP(i, t);
                        for (let t = 0; t < this.path.length; t++) {
                            let n = this.path[t];
                            !e && n.options.layoutScroll && n.scroll && n !== n.root && (0, ew.D2)(i, {
                                x: -n.scroll.offset.x,
                                y: -n.scroll.offset.y
                            }), (0, eF.ud)(n.latestValues) && (0, ew.D2)(i, n.latestValues)
                        }
                        return (0, eF.ud)(this.latestValues) && (0, ew.D2)(i, this.latestValues), i
                    }
                    removeTransform(t) {
                        let e = (0, tJ.dO)();
                        eP(e, t);
                        for (let t = 0; t < this.path.length; t++) {
                            let i = this.path[t];
                            if (!i.instance || !(0, eF.ud)(i.latestValues)) continue;
                            (0, eF.Lj)(i.latestValues) && i.updateSnapshot();
                            let n = (0, tJ.dO)();
                            eP(n, i.measurePageBox()), eV(e, i.latestValues, i.snapshot ? i.snapshot.layoutBox : void 0, n)
                        }
                        return (0, eF.ud)(this.latestValues) && eV(e, this.latestValues), e
                    }
                    setTargetDelta(t) {
                        this.targetDelta = t, this.root.scheduleUpdateProjection(), this.isProjectionDirty = !0
                    }
                    setOptions(t) {
                        this.options = { ...this.options,
                            ...t,
                            crossfade: void 0 === t.crossfade || t.crossfade
                        }
                    }
                    clearMeasurements() {
                        this.scroll = void 0, this.layout = void 0, this.snapshot = void 0, this.prevTransformTemplateValue = void 0, this.targetDelta = void 0, this.target = void 0, this.isLayoutDirty = !1
                    }
                    forceRelativeParentToResolveTarget() {
                        this.relativeParent && this.relativeParent.resolvedRelativeTargetAt !== X.frameData.timestamp && this.relativeParent.resolveTargetDelta(!0)
                    }
                    resolveTargetDelta(t = !1) {
                        var e, i, n, r;
                        let s = this.getLead();
                        this.isProjectionDirty || (this.isProjectionDirty = s.isProjectionDirty), this.isTransformDirty || (this.isTransformDirty = s.isTransformDirty), this.isSharedProjectionDirty || (this.isSharedProjectionDirty = s.isSharedProjectionDirty);
                        let o = !!this.resumingFrom || this !== s;
                        if (!(t || o && this.isSharedProjectionDirty || this.isProjectionDirty || (null === (e = this.parent) || void 0 === e ? void 0 : e.isProjectionDirty) || this.attemptToResolveRelativeTarget)) return;
                        let {
                            layout: a,
                            layoutId: l
                        } = this.options;
                        if (this.layout && (a || l)) {
                            if (this.resolvedRelativeTargetAt = X.frameData.timestamp, !this.targetDelta && !this.relativeTarget) {
                                let t = this.getClosestProjectingParent();
                                t && t.layout && 1 !== this.animationProgress ? (this.relativeParent = t, this.forceRelativeParentToResolveTarget(), this.relativeTarget = (0, tJ.dO)(), this.relativeTargetOrigin = (0, tJ.dO)(), tH(this.relativeTargetOrigin, this.layout.layoutBox, t.layout.layoutBox), eP(this.relativeTarget, this.relativeTargetOrigin)) : this.relativeParent = this.relativeTarget = void 0
                            }
                            if (this.relativeTarget || this.targetDelta) {
                                if ((this.target || (this.target = (0, tJ.dO)(), this.targetWithTransforms = (0, tJ.dO)()), this.relativeTarget && this.relativeTargetOrigin && this.relativeParent && this.relativeParent.target) ? (this.forceRelativeParentToResolveTarget(), i = this.target, n = this.relativeTarget, r = this.relativeParent.target, tz(i.x, n.x, r.x), tz(i.y, n.y, r.y)) : this.targetDelta ? (this.resumingFrom ? this.target = this.applyTransform(this.layout.layoutBox) : eP(this.target, this.layout.layoutBox), (0, ew.o2)(this.target, this.targetDelta)) : eP(this.target, this.layout.layoutBox), this.attemptToResolveRelativeTarget) {
                                    this.attemptToResolveRelativeTarget = !1;
                                    let t = this.getClosestProjectingParent();
                                    t && !!t.resumingFrom == !!this.resumingFrom && !t.options.layoutScroll && t.target && 1 !== this.animationProgress ? (this.relativeParent = t, this.forceRelativeParentToResolveTarget(), this.relativeTarget = (0, tJ.dO)(), this.relativeTargetOrigin = (0, tJ.dO)(), tH(this.relativeTargetOrigin, this.target, t.target), eP(this.relativeTarget, this.relativeTargetOrigin)) : this.relativeParent = this.relativeTarget = void 0
                                }
                                ez.resolvedTargetDeltas++
                            }
                        }
                    }
                    getClosestProjectingParent() {
                        return !this.parent || (0, eF.Lj)(this.parent.latestValues) || (0, eF.D_)(this.parent.latestValues) ? void 0 : this.parent.isProjecting() ? this.parent : this.parent.getClosestProjectingParent()
                    }
                    isProjecting() {
                        return !!((this.relativeTarget || this.targetDelta || this.options.layoutRoot) && this.layout)
                    }
                    calcProjection() {
                        var t;
                        let e = this.getLead(),
                            i = !!this.resumingFrom || this !== e,
                            n = !0;
                        if ((this.isProjectionDirty || (null === (t = this.parent) || void 0 === t ? void 0 : t.isProjectionDirty)) && (n = !1), i && (this.isSharedProjectionDirty || this.isTransformDirty) && (n = !1), this.resolvedRelativeTargetAt === X.frameData.timestamp && (n = !1), n) return;
                        let {
                            layout: r,
                            layoutId: s
                        } = this.options;
                        if (this.isTreeAnimating = !!(this.parent && this.parent.isTreeAnimating || this.currentAnimation || this.pendingAnimation), this.isTreeAnimating || (this.targetDelta = this.relativeTarget = void 0), !this.layout || !(r || s)) return;
                        eP(this.layoutCorrected, this.layout.layoutBox);
                        let o = this.treeScale.x,
                            a = this.treeScale.y;
                        (0, ew.YY)(this.layoutCorrected, this.treeScale, this.path, i), e.layout && !e.target && (1 !== this.treeScale.x || 1 !== this.treeScale.y) && (e.target = e.layout.layoutBox, e.targetWithTransforms = (0, tJ.dO)());
                        let {
                            target: l
                        } = e;
                        if (!l) {
                            this.projectionTransform && (this.projectionDelta = (0, tJ.wc)(), this.projectionTransform = "none", this.scheduleRender());
                            return
                        }
                        this.projectionDelta || (this.projectionDelta = (0, tJ.wc)(), this.projectionDeltaWithTransform = (0, tJ.wc)());
                        let u = this.projectionTransform;
                        tX(this.projectionDelta, this.layoutCorrected, l, this.latestValues), this.projectionTransform = eL(this.projectionDelta, this.treeScale), (this.projectionTransform !== u || this.treeScale.x !== o || this.treeScale.y !== a) && (this.hasProjected = !0, this.scheduleRender(), this.notifyListeners("projectionUpdate", l)), ez.recalculatedProjection++
                    }
                    hide() {
                        this.isVisible = !1
                    }
                    show() {
                        this.isVisible = !0
                    }
                    scheduleRender(t = !0) {
                        if (this.options.scheduleRender && this.options.scheduleRender(), t) {
                            let t = this.getStack();
                            t && t.scheduleRender()
                        }
                        this.resumingFrom && !this.resumingFrom.instance && (this.resumingFrom = void 0)
                    }
                    setAnimationOrigin(t, e = !1) {
                        let i;
                        let n = this.snapshot,
                            r = n ? n.latestValues : {},
                            s = { ...this.latestValues
                            },
                            o = (0, tJ.wc)();
                        this.relativeParent && this.relativeParent.options.layoutRoot || (this.relativeTarget = this.relativeTargetOrigin = void 0), this.attemptToResolveRelativeTarget = !e;
                        let a = (0, tJ.dO)(),
                            l = (n ? n.source : void 0) !== (this.layout ? this.layout.source : void 0),
                            u = this.getStack(),
                            h = !u || u.members.length <= 1,
                            c = !!(l && !h && !0 === this.options.crossfade && !this.path.some(e8));
                        this.animationProgress = 0, this.mixTargetDelta = e => {
                            let n = e / 1e3;
                            if (e9(o.x, t.x, n), e9(o.y, t.y, n), this.setTargetDelta(o), this.relativeTarget && this.relativeTargetOrigin && this.layout && this.relativeParent && this.relativeParent.layout) {
                                var u, d, p, f;
                                tH(a, this.layout.layoutBox, this.relativeParent.layout.layoutBox), p = this.relativeTarget, f = this.relativeTargetOrigin, e4(p.x, f.x, a.x, n), e4(p.y, f.y, a.y, n), i && (u = this.relativeTarget, d = i, u.x.min === d.x.min && u.x.max === d.x.max && u.y.min === d.y.min && u.y.max === d.y.max) && (this.isProjectionDirty = !1), i || (i = (0, tJ.dO)()), eP(i, this.relativeTarget)
                            }
                            l && (this.animationValues = s, function(t, e, i, n, r, s) {
                                r ? (t.opacity = (0, tI.t)(0, void 0 !== i.opacity ? i.opacity : 1, ev(n)), t.opacityExit = (0, tI.t)(void 0 !== e.opacity ? e.opacity : 1, 0, eg(n))) : s && (t.opacity = (0, tI.t)(void 0 !== e.opacity ? e.opacity : 1, void 0 !== i.opacity ? i.opacity : 1, n));
                                for (let r = 0; r < ed; r++) {
                                    let s = `border${ec[r]}Radius`,
                                        o = em(e, s),
                                        a = em(i, s);
                                    (void 0 !== o || void 0 !== a) && (o || (o = 0), a || (a = 0), 0 === o || 0 === a || ef(o) === ef(a) ? (t[s] = Math.max((0, tI.t)(ep(o), ep(a), n), 0), (t2.aQ.test(a) || t2.aQ.test(o)) && (t[s] += "%")) : t[s] = a)
                                }(e.rotate || i.rotate) && (t.rotate = (0, tI.t)(e.rotate || 0, i.rotate || 0, n))
                            }(s, r, this.latestValues, n, c, h)), this.root.scheduleUpdateProjection(), this.scheduleRender(), this.animationProgress = n
                        }, this.mixTargetDelta(this.options.layoutRoot ? 1e3 : 0)
                    }
                    startAnimation(t) {
                        this.notifyListeners("animationStart"), this.currentAnimation && this.currentAnimation.stop(), this.resumingFrom && this.resumingFrom.currentAnimation && this.resumingFrom.currentAnimation.stop(), this.pendingAnimation && ((0, X.Pn)(this.pendingAnimation), this.pendingAnimation = void 0), this.pendingAnimation = X.Wi.update(() => {
                            ee.hasAnimatedSinceResize = !0, this.currentAnimation = (0, eU.D)(0, 1e3, { ...t,
                                onUpdate: e => {
                                    this.mixTargetDelta(e), t.onUpdate && t.onUpdate(e)
                                },
                                onComplete: () => {
                                    t.onComplete && t.onComplete(), this.completeAnimation()
                                }
                            }), this.resumingFrom && (this.resumingFrom.currentAnimation = this.currentAnimation), this.pendingAnimation = void 0
                        })
                    }
                    completeAnimation() {
                        this.resumingFrom && (this.resumingFrom.currentAnimation = void 0, this.resumingFrom.preserveOpacity = void 0);
                        let t = this.getStack();
                        t && t.exitAnimationComplete(), this.resumingFrom = this.currentAnimation = this.animationValues = void 0, this.notifyListeners("animationComplete")
                    }
                    finishAnimation() {
                        this.currentAnimation && (this.mixTargetDelta && this.mixTargetDelta(1e3), this.currentAnimation.stop()), this.completeAnimation()
                    }
                    applyTransformsToTarget() {
                        let t = this.getLead(),
                            {
                                targetWithTransforms: e,
                                target: i,
                                layout: n,
                                latestValues: r
                            } = t;
                        if (e && i && n) {
                            if (this !== t && this.layout && n && ir(this.options.animationType, this.layout.layoutBox, n.layoutBox)) {
                                i = this.target || (0, tJ.dO)();
                                let e = tU(this.layout.layoutBox.x);
                                i.x.min = t.target.x.min, i.x.max = i.x.min + e;
                                let n = tU(this.layout.layoutBox.y);
                                i.y.min = t.target.y.min, i.y.max = i.y.min + n
                            }
                            eP(e, i), (0, ew.D2)(e, r), tX(this.projectionDeltaWithTransform, this.layoutCorrected, e, r)
                        }
                    }
                    registerSharedNode(t, e) {
                        this.sharedNodes.has(t) || this.sharedNodes.set(t, new ej), this.sharedNodes.get(t).add(e);
                        let i = e.options.initialPromotionConfig;
                        e.promote({
                            transition: i ? i.transition : void 0,
                            preserveFollowOpacity: i && i.shouldPreserveFollowOpacity ? i.shouldPreserveFollowOpacity(e) : void 0
                        })
                    }
                    isLead() {
                        let t = this.getStack();
                        return !t || t.lead === this
                    }
                    getLead() {
                        var t;
                        let {
                            layoutId: e
                        } = this.options;
                        return e && (null === (t = this.getStack()) || void 0 === t ? void 0 : t.lead) || this
                    }
                    getPrevLead() {
                        var t;
                        let {
                            layoutId: e
                        } = this.options;
                        return e ? null === (t = this.getStack()) || void 0 === t ? void 0 : t.prevLead : void 0
                    }
                    getStack() {
                        let {
                            layoutId: t
                        } = this.options;
                        if (t) return this.root.sharedNodes.get(t)
                    }
                    promote({
                        needsReset: t,
                        transition: e,
                        preserveFollowOpacity: i
                    } = {}) {
                        let n = this.getStack();
                        n && n.promote(this, i), t && (this.projectionDelta = void 0, this.needsReset = !0), e && this.setOptions({
                            transition: e
                        })
                    }
                    relegate() {
                        let t = this.getStack();
                        return !!t && t.relegate(this)
                    }
                    resetSkewAndRotation() {
                        let {
                            visualElement: t
                        } = this.options;
                        if (!t) return;
                        let e = !1,
                            {
                                latestValues: i
                            } = t;
                        if ((i.z || i.rotate || i.rotateX || i.rotateY || i.rotateZ || i.skewX || i.skewY) && (e = !0), !e) return;
                        let n = {};
                        i.z && eY("z", t, n, this.animationValues);
                        for (let e = 0; e < eW.length; e++) eY(`rotate${eW[e]}`, t, n, this.animationValues), eY(`skew${eW[e]}`, t, n, this.animationValues);
                        for (let e in t.render(), n) t.setStaticValue(e, n[e]), this.animationValues && (this.animationValues[e] = n[e]);
                        t.scheduleRender()
                    }
                    getProjectionStyles(t) {
                        var e, i;
                        if (!this.instance || this.isSVG) return;
                        if (!this.isVisible) return eN;
                        let n = {
                                visibility: ""
                            },
                            r = this.getTransformTemplate();
                        if (this.needsReset) return this.needsReset = !1, n.opacity = "", n.pointerEvents = W(null == t ? void 0 : t.pointerEvents) || "", n.transform = r ? r(this.latestValues, "") : "none", n;
                        let s = this.getLead();
                        if (!this.projectionDelta || !this.layout || !s.target) {
                            let e = {};
                            return this.options.layoutId && (e.opacity = void 0 !== this.latestValues.opacity ? this.latestValues.opacity : 1, e.pointerEvents = W(null == t ? void 0 : t.pointerEvents) || ""), this.hasProjected && !(0, eF.ud)(this.latestValues) && (e.transform = r ? r({}, "") : "none", this.hasProjected = !1), e
                        }
                        let o = s.animationValues || s.latestValues;
                        this.applyTransformsToTarget(), n.transform = eL(this.projectionDeltaWithTransform, this.treeScale, o), r && (n.transform = r(o, n.transform));
                        let {
                            x: a,
                            y: l
                        } = this.projectionDelta;
                        for (let t in n.transformOrigin = `${100*a.origin}% ${100*l.origin}% 0`, s.animationValues ? n.opacity = s === this ? null !== (i = null !== (e = o.opacity) && void 0 !== e ? e : this.latestValues.opacity) && void 0 !== i ? i : 1 : this.preserveOpacity ? this.latestValues.opacity : o.opacityExit : n.opacity = s === this ? void 0 !== o.opacity ? o.opacity : "" : void 0 !== o.opacityExit ? o.opacityExit : 0, es.P) {
                            if (void 0 === o[t]) continue;
                            let {
                                correct: e,
                                applyTo: i
                            } = es.P[t], r = "none" === n.transform ? o[t] : e(o[t], s);
                            if (i) {
                                let t = i.length;
                                for (let e = 0; e < t; e++) n[i[e]] = r
                            } else n[t] = r
                        }
                        return this.options.layoutId && (n.pointerEvents = s === this ? W(null == t ? void 0 : t.pointerEvents) || "" : "none"), n
                    }
                    clearSnapshot() {
                        this.resumeFrom = this.snapshot = void 0
                    }
                    resetTree() {
                        this.root.nodes.forEach(t => {
                            var e;
                            return null === (e = t.currentAnimation) || void 0 === e ? void 0 : e.stop()
                        }), this.root.nodes.forEach(eJ), this.root.sharedNodes.clear()
                    }
                }
            }

            function eK(t) {
                t.updateLayout()
            }

            function eZ(t) {
                var e;
                let i = (null === (e = t.resumeFrom) || void 0 === e ? void 0 : e.snapshot) || t.snapshot;
                if (t.isLead() && t.layout && i && t.hasListeners("didUpdate")) {
                    let {
                        layoutBox: e,
                        measuredBox: n
                    } = t.layout, {
                        animationType: r
                    } = t.options, s = i.source !== t.layout.source;
                    "size" === r ? tQ(t => {
                        let n = s ? i.measuredBox[t] : i.layoutBox[t],
                            r = tU(n);
                        n.min = e[t].min, n.max = n.min + r
                    }) : ir(r, i.layoutBox, e) && tQ(n => {
                        let r = s ? i.measuredBox[n] : i.layoutBox[n],
                            o = tU(e[n]);
                        r.max = r.min + o, t.relativeTarget && !t.currentAnimation && (t.isProjectionDirty = !0, t.relativeTarget[n].max = t.relativeTarget[n].min + o)
                    });
                    let o = (0, tJ.wc)();
                    tX(o, e, i.layoutBox);
                    let a = (0, tJ.wc)();
                    s ? tX(a, t.applyTransform(n, !0), i.measuredBox) : tX(a, e, i.layoutBox);
                    let l = !eD(o),
                        u = !1;
                    if (!t.resumeFrom) {
                        let n = t.getClosestProjectingParent();
                        if (n && !n.resumeFrom) {
                            let {
                                snapshot: r,
                                layout: s
                            } = n;
                            if (r && s) {
                                let o = (0, tJ.dO)();
                                tH(o, i.layoutBox, r.layoutBox);
                                let a = (0, tJ.dO)();
                                tH(a, e, s.layoutBox), eM(o, a) || (u = !0), n.options.layoutRoot && (t.relativeTarget = a, t.relativeTargetOrigin = o, t.relativeParent = n)
                            }
                        }
                    }
                    t.notifyListeners("didUpdate", {
                        layout: e,
                        snapshot: i,
                        delta: a,
                        layoutDelta: o,
                        hasLayoutChanged: l,
                        hasRelativeTargetChanged: u
                    })
                } else if (t.isLead()) {
                    let {
                        onExitComplete: e
                    } = t.options;
                    e && e()
                }
                t.options.transition = void 0
            }

            function eG(t) {
                ez.totalNodes++, t.parent && (t.isProjecting() || (t.isProjectionDirty = t.parent.isProjectionDirty), t.isSharedProjectionDirty || (t.isSharedProjectionDirty = !!(t.isProjectionDirty || t.parent.isProjectionDirty || t.parent.isSharedProjectionDirty)), t.isTransformDirty || (t.isTransformDirty = t.parent.isTransformDirty))
            }

            function e_(t) {
                t.isProjectionDirty = t.isSharedProjectionDirty = t.isTransformDirty = !1
            }

            function eq(t) {
                t.clearSnapshot()
            }

            function eJ(t) {
                t.clearMeasurements()
            }

            function eQ(t) {
                t.isLayoutDirty = !1
            }

            function e0(t) {
                let {
                    visualElement: e
                } = t.options;
                e && e.getProps().onBeforeLayoutMeasure && e.notify("BeforeLayoutMeasure"), t.resetTransform()
            }

            function e1(t) {
                t.finishAnimation(), t.targetDelta = t.relativeTarget = t.target = void 0, t.isProjectionDirty = !0
            }

            function e2(t) {
                t.resolveTargetDelta()
            }

            function e3(t) {
                t.calcProjection()
            }

            function e5(t) {
                t.resetSkewAndRotation()
            }

            function e6(t) {
                t.removeLeadSnapshot()
            }

            function e9(t, e, i) {
                t.translate = (0, tI.t)(e.translate, 0, i), t.scale = (0, tI.t)(e.scale, 1, i), t.origin = e.origin, t.originPoint = e.originPoint
            }

            function e4(t, e, i, n) {
                t.min = (0, tI.t)(e.min, i.min, n), t.max = (0, tI.t)(e.max, i.max, n)
            }

            function e8(t) {
                return t.animationValues && void 0 !== t.animationValues.opacityExit
            }
            let e7 = {
                    duration: .45,
                    ease: [.4, 0, .1, 1]
                },
                it = t => "undefined" != typeof navigator && navigator.userAgent && navigator.userAgent.toLowerCase().includes(t),
                ie = it("applewebkit/") && !it("chrome/") ? Math.round : tl.Z;

            function ii(t) {
                t.min = ie(t.min), t.max = ie(t.max)
            }

            function ir(t, e, i) {
                return "position" === t || "preserve-aspect" === t && !tW(eR(e), eR(i), .2)
            }
            let is = eH({
                    attachResizeListener: (t, e) => H(t, "resize", e),
                    measureScroll: () => ({
                        x: document.documentElement.scrollLeft || document.body.scrollLeft,
                        y: document.documentElement.scrollTop || document.body.scrollTop
                    }),
                    checkIsScrollRoot: () => !0
                }),
                io = {
                    current: void 0
                },
                ia = eH({
                    measureScroll: t => ({
                        x: t.scrollLeft,
                        y: t.scrollTop
                    }),
                    defaultParent: () => {
                        if (!io.current) {
                            let t = new is({});
                            t.mount(window), t.setOptions({
                                layoutScroll: !0
                            }), io.current = t
                        }
                        return io.current
                    },
                    resetTransform: (t, e) => {
                        t.style.transform = void 0 !== e ? e : "none"
                    },
                    checkIsScrollRoot: t => "fixed" === window.getComputedStyle(t).position
                });
            var il = i(86276),
                iu = i(81165);
            let ih = (t, e) => T(t) ? new iu.e(e, {
                    enableHardwareAcceleration: !1
                }) : new il.W(e, {
                    enableHardwareAcceleration: !0
                }),
                ic = {
                    animation: {
                        Feature: tE
                    },
                    exit: {
                        Feature: tD
                    },
                    inView: {
                        Feature: tv
                    },
                    tap: {
                        Feature: th
                    },
                    focus: {
                        Feature: to
                    },
                    hover: {
                        Feature: ts
                    },
                    pan: {
                        Feature: et
                    },
                    drag: {
                        Feature: t8,
                        ProjectionNode: ia,
                        MeasureLayout: ea
                    },
                    layout: {
                        ProjectionNode: ia,
                        MeasureLayout: ea
                    }
                },
                id = function(t) {
                    function e(e, i = {}) {
                        return function({
                            preloadedFeatures: t,
                            createVisualElement: e,
                            useRender: i,
                            useVisualState: n,
                            Component: d
                        }) {
                            t && function(t) {
                                for (let e in t) g.A[e] = { ...g.A[e],
                                    ...t[e]
                                }
                            }(t);
                            let b = (0, r.forwardRef)(function(g, w) {
                                var b;
                                let T;
                                let S = { ...(0, r.useContext)(s._),
                                        ...g,
                                        layoutId: function({
                                            layoutId: t
                                        }) {
                                            let e = (0, r.useContext)(x).id;
                                            return e && void 0 !== t ? e + "-" + t : t
                                        }(g)
                                    },
                                    {
                                        isStatic: A
                                    } = S,
                                    V = function(t) {
                                        let {
                                            initial: e,
                                            animate: i
                                        } = function(t, e) {
                                            if ((0, m.G)(t)) {
                                                let {
                                                    initial: e,
                                                    animate: i
                                                } = t;
                                                return {
                                                    initial: !1 === e || (0, f.$)(e) ? e : void 0,
                                                    animate: (0, f.$)(i) ? i : void 0
                                                }
                                            }
                                            return !1 !== t.inherit ? e : {}
                                        }(t, (0, r.useContext)(o));
                                        return (0, r.useMemo)(() => ({
                                            initial: e,
                                            animate: i
                                        }), [v(e), v(i)])
                                    }(g),
                                    E = n(g, A);
                                if (!A && y.j) {
                                    V.visualElement = function(t, e, i, n) {
                                        let {
                                            visualElement: d
                                        } = (0, r.useContext)(o), p = (0, r.useContext)(u), f = (0, r.useContext)(a), m = (0, r.useContext)(s._).reducedMotion, v = (0, r.useRef)();
                                        n = n || p.renderer, !v.current && n && (v.current = n(t, {
                                            visualState: e,
                                            parent: d,
                                            props: i,
                                            presenceContext: f,
                                            blockInitialAnimation: !!f && !1 === f.initial,
                                            reducedMotionConfig: m
                                        }));
                                        let g = v.current;
                                        (0, r.useInsertionEffect)(() => {
                                            g && g.update(i, f)
                                        });
                                        let y = (0, r.useRef)(!!(i[h.M] && !window.HandoffComplete));
                                        return (0, l.L)(() => {
                                            g && (c.postRender(g.render), y.current && g.animationState && g.animationState.animateChanges())
                                        }), (0, r.useEffect)(() => {
                                            g && (g.updateFeatures(), !y.current && g.animationState && g.animationState.animateChanges(), y.current && (y.current = !1, window.HandoffComplete = !0))
                                        }), g
                                    }(d, E, S, e);
                                    let i = (0, r.useContext)(P),
                                        n = (0, r.useContext)(u).strict;
                                    V.visualElement && (T = V.visualElement.loadFeatures(S, n, t, i))
                                }
                                return r.createElement(o.Provider, {
                                    value: V
                                }, T && V.visualElement ? r.createElement(T, {
                                    visualElement: V.visualElement,
                                    ...S
                                }) : null, i(d, g, (b = V.visualElement, (0, r.useCallback)(t => {
                                    t && E.mount && E.mount(t), b && (t ? b.mount(t) : b.unmount()), w && ("function" == typeof w ? w(t) : (0, p.I)(w) && (w.current = t))
                                }, [b])), E, A, V.visualElement))
                            });
                            return b[w] = d, b
                        }(t(e, i))
                    }
                    if ("undefined" == typeof Proxy) return e;
                    let i = new Map;
                    return new Proxy(e, {
                        get: (t, n) => (i.has(n) || i.set(n, e(n)), i.get(n))
                    })
                }((t, e) => (function(t, {
                    forwardMotionProps: e = !1
                }, i, n) {
                    return { ...T(t) ? z : Y,
                        preloadedFeatures: i,
                        useRender: function(t = !1) {
                            return (e, i, n, {
                                latestValues: s
                            }, o) => {
                                let a = (T(e) ? function(t, e, i, n) {
                                        let s = (0, r.useMemo)(() => {
                                            let i = j();
                                            return (0, k.i)(i, e, {
                                                enableHardwareAcceleration: !1
                                            }, (0, L.a)(n), t.transformTemplate), { ...i.attrs,
                                                style: { ...i.style
                                                }
                                            }
                                        }, [e]);
                                        if (t.style) {
                                            let e = {};
                                            C(e, t.style, t), s.style = { ...e,
                                                ...s.style
                                            }
                                        }
                                        return s
                                    } : function(t, e, i) {
                                        let n = {},
                                            s = function(t, e, i) {
                                                let n = t.style || {},
                                                    s = {};
                                                return C(s, n, t), Object.assign(s, function({
                                                    transformTemplate: t
                                                }, e, i) {
                                                    return (0, r.useMemo)(() => {
                                                        let n = E();
                                                        return (0, V.r)(n, e, {
                                                            enableHardwareAcceleration: !i
                                                        }, t), Object.assign({}, n.vars, n.style)
                                                    }, [e])
                                                }(t, e, i)), s
                                            }(t, e, i);
                                        return t.drag && !1 !== t.dragListener && (n.draggable = !1, s.userSelect = s.WebkitUserSelect = s.WebkitTouchCallout = "none", s.touchAction = !0 === t.drag ? "none" : `pan-${"x"===t.drag?"y":"x"}`), void 0 === t.tabIndex && (t.onTap || t.onTapStart || t.whileTap) && (n.tabIndex = 0), n.style = s, n
                                    })(i, s, o, e),
                                    l = function(t, e, i) {
                                        let n = {};
                                        for (let r in t)("values" !== r || "object" != typeof t.values) && (R(r) || !0 === i && M(r) || !e && !M(r) || t.draggable && r.startsWith("onDrag")) && (n[r] = t[r]);
                                        return n
                                    }(i, "string" == typeof e, t),
                                    u = e !== r.Fragment ? { ...l,
                                        ...a,
                                        ref: n
                                    } : {},
                                    {
                                        children: h
                                    } = i,
                                    c = (0, r.useMemo)(() => (0, A.i)(h) ? h.get() : h, [h]);
                                return (0, r.createElement)(e, { ...u,
                                    children: c
                                })
                            }
                        }(e),
                        createVisualElement: n,
                        Component: t
                    }
                })(t, e, ic, ih))
        },
        65998: function(t, e, i) {
            i.d(e, {
                D: function() {
                    return n
                }
            });
            let n = t => t.replace(/([a-z])([A-Z])/gu, "$1-$2").toLowerCase()
        },
        57126: function(t, e, i) {
            i.d(e, {
                f: function() {
                    return r
                },
                t: function() {
                    return o
                }
            });
            let n = t => e => "string" == typeof e && e.startsWith(t),
                r = n("--"),
                s = n("var(--"),
                o = t => !!s(t) && a.test(t.split("/*")[0].trim()),
                a = /var\(--(?:[\w-]+\s*|[\w-]+\s*,(?:\s*[^)(\s]|\s*\((?:[^)(]|\([^)(]*\))*\))+\s*)\)$/iu
        },
        41937: function(t, e, i) {
            i.d(e, {
                v: function() {
                    return n
                }
            });

            function n(t) {
                return t instanceof SVGElement && "svg" !== t.tagName
            }
        },
        22756: function(t, e, i) {
            i.d(e, {
                Ei: function() {
                    return d
                },
                lw: function() {
                    return p
                },
                mP: function() {
                    return a
                },
                z2: function() {
                    return o
                }
            });
            var n = i(60618),
                r = i(25218),
                s = i(72724);
            let o = new Set(["width", "height", "top", "left", "right", "bottom", "x", "y", "translateX", "translateY"]),
                a = t => t === r.Rx || t === s.px,
                l = (t, e) => parseFloat(t.split(", ")[e]),
                u = (t, e) => (i, {
                    transform: n
                }) => {
                    if ("none" === n || !n) return 0;
                    let r = n.match(/^matrix3d\((.+)\)$/u);
                    if (r) return l(r[1], e); {
                        let e = n.match(/^matrix\((.+)\)$/u);
                        return e ? l(e[1], t) : 0
                    }
                },
                h = new Set(["x", "y", "z"]),
                c = n._.filter(t => !h.has(t));

            function d(t) {
                let e = [];
                return c.forEach(i => {
                    let n = t.getValue(i);
                    void 0 !== n && (e.push([i, n.get()]), n.set(i.startsWith("scale") ? 1 : 0))
                }), e
            }
            let p = {
                width: ({
                    x: t
                }, {
                    paddingLeft: e = "0",
                    paddingRight: i = "0"
                }) => t.max - t.min - parseFloat(e) - parseFloat(i),
                height: ({
                    y: t
                }, {
                    paddingTop: e = "0",
                    paddingBottom: i = "0"
                }) => t.max - t.min - parseFloat(e) - parseFloat(i),
                top: (t, {
                    top: e
                }) => parseFloat(e),
                left: (t, {
                    left: e
                }) => parseFloat(e),
                bottom: ({
                    y: t
                }, {
                    top: e
                }) => parseFloat(e) + (t.max - t.min),
                right: ({
                    x: t
                }, {
                    left: e
                }) => parseFloat(e) + (t.max - t.min),
                x: u(4, 13),
                y: u(5, 14)
            };
            p.translateX = p.x, p.translateY = p.y
        },
        23462: function(t, e, i) {
            i.d(e, {
                T: function() {
                    return o
                }
            });
            var n = i(92263),
                r = i(82915),
                s = i(56217);

            function o(t, e) {
                let i = (0, s.A)(t);
                return i !== r.h && (i = n.P), i.getAnimatableNone ? i.getAnimatableNone(e) : void 0
            }
        },
        56217: function(t, e, i) {
            i.d(e, {
                A: function() {
                    return o
                }
            });
            var n = i(22809),
                r = i(82915);
            let s = { ...i(97346).j,
                    color: n.$,
                    backgroundColor: n.$,
                    outlineColor: n.$,
                    fill: n.$,
                    stroke: n.$,
                    borderColor: n.$,
                    borderTopColor: n.$,
                    borderRightColor: n.$,
                    borderBottomColor: n.$,
                    borderLeftColor: n.$,
                    filter: r.h,
                    WebkitFilter: r.h
                },
                o = t => s[t]
        },
        61921: function(t, e, i) {
            i.d(e, {
                $: function() {
                    return o
                },
                C: function() {
                    return a
                }
            });
            var n = i(25218),
                r = i(72724),
                s = i(94707);
            let o = [n.Rx, r.px, r.aQ, r.RW, r.vw, r.vh, {
                    test: t => "auto" === t,
                    parse: t => t
                }],
                a = t => o.find((0, s.l)(t))
        },
        97346: function(t, e, i) {
            i.d(e, {
                j: function() {
                    return o
                }
            });
            var n = i(25218),
                r = i(72724);
            let s = { ...n.Rx,
                    transform: Math.round
                },
                o = {
                    borderWidth: r.px,
                    borderTopWidth: r.px,
                    borderRightWidth: r.px,
                    borderBottomWidth: r.px,
                    borderLeftWidth: r.px,
                    borderRadius: r.px,
                    radius: r.px,
                    borderTopLeftRadius: r.px,
                    borderTopRightRadius: r.px,
                    borderBottomRightRadius: r.px,
                    borderBottomLeftRadius: r.px,
                    width: r.px,
                    maxWidth: r.px,
                    height: r.px,
                    maxHeight: r.px,
                    size: r.px,
                    top: r.px,
                    right: r.px,
                    bottom: r.px,
                    left: r.px,
                    padding: r.px,
                    paddingTop: r.px,
                    paddingRight: r.px,
                    paddingBottom: r.px,
                    paddingLeft: r.px,
                    margin: r.px,
                    marginTop: r.px,
                    marginRight: r.px,
                    marginBottom: r.px,
                    marginLeft: r.px,
                    rotate: r.RW,
                    rotateX: r.RW,
                    rotateY: r.RW,
                    rotateZ: r.RW,
                    scale: n.bA,
                    scaleX: n.bA,
                    scaleY: n.bA,
                    scaleZ: n.bA,
                    skew: r.RW,
                    skewX: r.RW,
                    skewY: r.RW,
                    distance: r.px,
                    translateX: r.px,
                    translateY: r.px,
                    translateZ: r.px,
                    x: r.px,
                    y: r.px,
                    z: r.px,
                    perspective: r.px,
                    transformPerspective: r.px,
                    opacity: n.Fq,
                    originX: r.$C,
                    originY: r.$C,
                    originZ: r.px,
                    zIndex: s,
                    backgroundPositionX: r.px,
                    backgroundPositionY: r.px,
                    fillOpacity: n.Fq,
                    strokeOpacity: n.Fq,
                    numOctaves: s
                }
        },
        94707: function(t, e, i) {
            i.d(e, {
                l: function() {
                    return n
                }
            });
            let n = t => e => e.test(t)
        },
        86276: function(t, e, i) {
            i.d(e, {
                W: function() {
                    return d
                }
            });
            var n = i(25275),
                r = i(57126),
                s = i(60618),
                o = i(46235),
                a = i(54269),
                l = i(56217),
                u = i(30411),
                h = i(70176),
                c = i(82702);
            class d extends h.J {
                constructor() {
                    super(...arguments), this.type = "html"
                }
                readValueFromInstance(t, e) {
                    if (s.G.has(e)) {
                        let t = (0, l.A)(e);
                        return t && t.default || 0
                    } {
                        let i = window.getComputedStyle(t),
                            n = ((0, r.f)(e) ? i.getPropertyValue(e) : i[e]) || 0;
                        return "string" == typeof n ? n.trim() : n
                    }
                }
                measureInstanceViewportBox(t, {
                    transformPagePoint: e
                }) {
                    return (0, u.J)(t, e)
                }
                build(t, e, i, r) {
                    (0, n.r)(t, e, i, r.transformTemplate)
                }
                scrapeMotionValuesFromProps(t, e, i) {
                    return (0, o.U)(t, e, i)
                }
                handleChildMotionValue() {
                    this.childSubscription && (this.childSubscription(), delete this.childSubscription);
                    let {
                        children: t
                    } = this.props;
                    (0, c.i)(t) && (this.childSubscription = t.on("change", t => {
                        this.current && (this.current.textContent = `${t}`)
                    }))
                }
                renderInstance(t, e, i, n) {
                    (0, a.N)(t, e, i, n)
                }
            }
        },
        25275: function(t, e, i) {
            i.d(e, {
                r: function() {
                    return u
                }
            });
            var n = i(60618);
            let r = {
                    x: "translateX",
                    y: "translateY",
                    z: "translateZ",
                    transformPerspective: "perspective"
                },
                s = n._.length;
            var o = i(57126);
            let a = (t, e) => e && "number" == typeof t ? e.transform(t) : t;
            var l = i(97346);

            function u(t, e, i, u) {
                let {
                    style: h,
                    vars: c,
                    transform: d,
                    transformOrigin: p
                } = t, f = !1, m = !1, v = !0;
                for (let t in e) {
                    let i = e[t];
                    if ((0, o.f)(t)) {
                        c[t] = i;
                        continue
                    }
                    let r = l.j[t],
                        s = a(i, r);
                    if (n.G.has(t)) {
                        if (f = !0, d[t] = s, !v) continue;
                        i !== (r.default || 0) && (v = !1)
                    } else t.startsWith("origin") ? (m = !0, p[t] = s) : h[t] = s
                }
                if (!e.transform && (f || u ? h.transform = function(t, {
                        enableHardwareAcceleration: e = !0,
                        allowTransformNone: i = !0
                    }, o, a) {
                        let l = "";
                        for (let e = 0; e < s; e++) {
                            let i = n._[e];
                            if (void 0 !== t[i]) {
                                let e = r[i] || i;
                                l += `${e}(${t[i]}) `
                            }
                        }
                        return e && !t.z && (l += "translateZ(0)"), l = l.trim(), a ? l = a(t, o ? "" : l) : i && o && (l = "none"), l
                    }(t.transform, i, v, u) : h.transform && (h.transform = "none")), m) {
                    let {
                        originX: t = "50%",
                        originY: e = "50%",
                        originZ: i = 0
                    } = p;
                    h.transformOrigin = `${t} ${e} ${i}`
                }
            }
        },
        54269: function(t, e, i) {
            i.d(e, {
                N: function() {
                    return n
                }
            });

            function n(t, {
                style: e,
                vars: i
            }, n, r) {
                for (let s in Object.assign(t.style, e, r && r.getProjectionStyles(n)), i) t.style.setProperty(s, i[s])
            }
        },
        46235: function(t, e, i) {
            i.d(e, {
                U: function() {
                    return s
                }
            });
            var n = i(5403),
                r = i(82702);

            function s(t, e, i) {
                var s;
                let {
                    style: o
                } = t, a = {};
                for (let l in o)((0, r.i)(o[l]) || e.style && (0, r.i)(e.style[l]) || (0, n.j)(l, t) || (null === (s = null == i ? void 0 : i.getValue(l)) || void 0 === s ? void 0 : s.liveStyle) !== void 0) && (a[l] = o[l]);
                return a
            }
        },
        60618: function(t, e, i) {
            i.d(e, {
                G: function() {
                    return r
                },
                _: function() {
                    return n
                }
            });
            let n = ["transformPerspective", "x", "y", "z", "translateX", "translateY", "translateZ", "scale", "scaleX", "scaleY", "rotate", "rotateX", "rotateY", "rotateZ", "skew", "skewX", "skewY"],
                r = new Set(n)
        },
        48854: function(t, e, i) {
            i.d(e, {
                R: function() {
                    return n
                }
            });
            let n = new WeakMap
        },
        81165: function(t, e, i) {
            i.d(e, {
                e: function() {
                    return p
                }
            });
            var n = i(9548),
                r = i(70176),
                s = i(48348),
                o = i(65998),
                a = i(38766),
                l = i(60618),
                u = i(81661),
                h = i(56217),
                c = i(24884),
                d = i(27612);
            class p extends r.J {
                constructor() {
                    super(...arguments), this.type = "svg", this.isSVGTag = !1
                }
                getBaseTargetFromProps(t, e) {
                    return t[e]
                }
                readValueFromInstance(t, e) {
                    if (l.G.has(e)) {
                        let t = (0, h.A)(e);
                        return t && t.default || 0
                    }
                    return e = a.s.has(e) ? e : (0, o.D)(e), t.getAttribute(e)
                }
                measureInstanceViewportBox() {
                    return (0, c.dO)()
                }
                scrapeMotionValuesFromProps(t, e) {
                    return (0, n.U)(t, e, this)
                }
                build(t, e, i, n) {
                    (0, s.i)(t, e, i, this.isSVGTag, n.transformTemplate)
                }
                renderInstance(t, e, i, n) {
                    (0, u.K)(t, e, i, n)
                }
                mount(t) {
                    this.isSVGTag = (0, d.a)(t.tagName), super.mount(t)
                }
            }
        },
        48348: function(t, e, i) {
            i.d(e, {
                i: function() {
                    return l
                }
            });
            var n = i(25275),
                r = i(72724);

            function s(t, e, i) {
                return "string" == typeof t ? t : r.px.transform(e + i * t)
            }
            let o = {
                    offset: "stroke-dashoffset",
                    array: "stroke-dasharray"
                },
                a = {
                    offset: "strokeDashoffset",
                    array: "strokeDasharray"
                };

            function l(t, {
                attrX: e,
                attrY: i,
                attrScale: l,
                originX: u,
                originY: h,
                pathLength: c,
                pathSpacing: d = 1,
                pathOffset: p = 0,
                ...f
            }, m, v, g) {
                if ((0, n.r)(t, f, m, g), v) {
                    t.style.viewBox && (t.attrs.viewBox = t.style.viewBox);
                    return
                }
                t.attrs = t.style, t.style = {};
                let {
                    attrs: y,
                    style: x,
                    dimensions: P
                } = t;
                y.transform && (P && (x.transform = y.transform), delete y.transform), P && (void 0 !== u || void 0 !== h || x.transform) && (x.transformOrigin = function(t, e, i) {
                    let n = s(e, t.x, t.width),
                        r = s(i, t.y, t.height);
                    return `${n} ${r}`
                }(P, void 0 !== u ? u : .5, void 0 !== h ? h : .5)), void 0 !== e && (y.x = e), void 0 !== i && (y.y = i), void 0 !== l && (y.scale = l), void 0 !== c && function(t, e, i = 1, n = 0, s = !0) {
                    t.pathLength = 1;
                    let l = s ? o : a;
                    t[l.offset] = r.px.transform(-n);
                    let u = r.px.transform(e),
                        h = r.px.transform(i);
                    t[l.array] = `${u} ${h}`
                }(y, c, d, p, !1)
            }
        },
        38766: function(t, e, i) {
            i.d(e, {
                s: function() {
                    return n
                }
            });
            let n = new Set(["baseFrequency", "diffuseConstant", "kernelMatrix", "kernelUnitLength", "keySplines", "keyTimes", "limitingConeAngle", "markerHeight", "markerWidth", "numOctaves", "targetX", "targetY", "surfaceScale", "specularConstant", "specularExponent", "stdDeviation", "tableValues", "viewBox", "gradientTransform", "pathLength", "startOffset", "textLength", "lengthAdjust"])
        },
        27612: function(t, e, i) {
            i.d(e, {
                a: function() {
                    return n
                }
            });
            let n = t => "string" == typeof t && "svg" === t.toLowerCase()
        },
        81661: function(t, e, i) {
            i.d(e, {
                K: function() {
                    return o
                }
            });
            var n = i(65998),
                r = i(54269),
                s = i(38766);

            function o(t, e, i, o) {
                for (let i in (0, r.N)(t, e, void 0, o), e.attrs) t.setAttribute(s.s.has(i) ? i : (0, n.D)(i), e.attrs[i])
            }
        },
        9548: function(t, e, i) {
            i.d(e, {
                U: function() {
                    return o
                }
            });
            var n = i(82702),
                r = i(46235),
                s = i(60618);

            function o(t, e, i) {
                let o = (0, r.U)(t, e, i);
                for (let i in t)((0, n.i)(t[i]) || (0, n.i)(e[i])) && (o[-1 !== s._.indexOf(i) ? "attr" + i.charAt(0).toUpperCase() + i.substring(1) : i] = t[i]);
                return o
            }
        },
        54178: function(t, e, i) {
            i.d(e, {
                e: function() {
                    return c
                },
                m: function() {
                    return h
                }
            });
            var n = i(22756),
                r = i(14205);
            let s = new Set,
                o = !1,
                a = !1;

            function l() {
                if (a) {
                    let t = Array.from(s).filter(t => t.needsMeasurement),
                        e = new Set(t.map(t => t.element)),
                        i = new Map;
                    e.forEach(t => {
                        (0, n.Ei)(t).length && (i.set(t, (0, n.Ei)(t)), t.render())
                    }), t.forEach(t => t.measureInitialState()), e.forEach(t => {
                        t.render()
                    }), t.forEach(t => t.measureEndState()), t.forEach(t => {
                        void 0 !== t.suspendedScrollY && window.scrollTo(0, t.suspendedScrollY)
                    })
                }
                a = !1, o = !1, s.forEach(t => t.complete()), s.clear()
            }

            function u() {
                s.forEach(t => {
                    t.readKeyframes(), t.needsMeasurement && (a = !0)
                })
            }

            function h() {
                u(), l()
            }
            class c {
                constructor(t, e, i, n, r, s = !1) {
                    this.isComplete = !1, this.isAsync = !1, this.needsMeasurement = !1, this.isScheduled = !1, this.unresolvedKeyframes = [...t], this.onComplete = e, this.name = i, this.motionValue = n, this.element = r, this.isAsync = s
                }
                scheduleResolve() {
                    this.isScheduled = !0, this.isAsync ? (s.add(this), o || (o = !0, r.Wi.read(u), r.Wi.resolveKeyframes(l))) : (this.readKeyframes(), this.complete())
                }
                readKeyframes() {
                    let {
                        unresolvedKeyframes: t,
                        name: e,
                        element: i,
                        motionValue: n
                    } = this;
                    for (let r = 0; r < t.length; r++)
                        if (null === t[r]) {
                            if (0 === r) {
                                let r = null == n ? void 0 : n.get(),
                                    s = t[t.length - 1];
                                if (void 0 !== r) t[0] = r;
                                else if (i && e) {
                                    let n = i.readValue(e, s);
                                    null != n && (t[0] = n)
                                }
                                void 0 === t[0] && (t[0] = s), n && void 0 === r && n.set(t[0])
                            } else t[r] = t[r - 1]
                        }
                }
                setFinalKeyframe() {}
                measureInitialState() {}
                renderEndStyles() {}
                measureEndState() {}
                complete() {
                    this.isComplete = !0, this.onComplete(this.unresolvedKeyframes, this.finalKeyframe), s.delete(this)
                }
                cancel() {
                    this.isComplete || (this.isScheduled = !1, s.delete(this))
                }
                resume() {
                    this.isComplete || this.scheduleResolve()
                }
            }
        },
        79739: function(t, e, i) {
            i.d(e, {
                G: function() {
                    return o
                },
                M: function() {
                    return a
                }
            });
            var n = i(54633),
                r = i(16930),
                s = i(41867);

            function o(t) {
                return (0, n.H)(t.animate) || s.V.some(e => (0, r.$)(t[e]))
            }

            function a(t) {
                return !!(o(t) || t.variants)
            }
        },
        16930: function(t, e, i) {
            i.d(e, {
                $: function() {
                    return n
                }
            });

            function n(t) {
                return "string" == typeof t || Array.isArray(t)
            }
        },
        1148: function(t, e, i) {
            i.d(e, {
                x: function() {
                    return r
                }
            });
            var n = i(51422);

            function r(t, e, i) {
                let r = t.getProps();
                return (0, n.o)(r, e, void 0 !== i ? i : r.custom, function(t) {
                    let e = {};
                    return t.values.forEach((t, i) => e[i] = t.get()), e
                }(t), function(t) {
                    let e = {};
                    return t.values.forEach((t, i) => e[i] = t.getVelocity()), e
                }(t))
            }
        },
        51422: function(t, e, i) {
            i.d(e, {
                o: function() {
                    return n
                }
            });

            function n(t, e, i, n = {}, r = {}) {
                return "function" == typeof e && (e = e(void 0 !== i ? i : t.custom, n, r)), "string" == typeof e && (e = t.variants && t.variants[e]), "function" == typeof e && (e = e(void 0 !== i ? i : t.custom, n, r)), e
            }
        },
        41867: function(t, e, i) {
            i.d(e, {
                V: function() {
                    return r
                },
                e: function() {
                    return n
                }
            });
            let n = ["animate", "whileInView", "whileFocus", "whileHover", "whileTap", "whileDrag", "exit"],
                r = ["initial", ...n]
        },
        36832: function(t, e, i) {
            i.d(e, {
                c: function() {
                    return n
                }
            });
            let n = {
                skipAnimations: !1,
                useManualTiming: !1
            }
        },
        50406: function(t, e, i) {
            function n(t, e) {
                -1 === t.indexOf(e) && t.push(e)
            }

            function r(t, e) {
                let i = t.indexOf(e);
                i > -1 && t.splice(i, 1)
            }
            i.d(e, {
                cl: function() {
                    return r
                },
                y4: function() {
                    return n
                }
            })
        },
        22476: function(t, e, i) {
            i.d(e, {
                u: function() {
                    return n
                }
            });
            let n = (t, e, i) => i > e ? e : i < t ? t : i
        },
        29908: function(t, e, i) {
            i.d(e, {
                K: function() {
                    return r
                },
                k: function() {
                    return s
                }
            });
            var n = i(3393);
            let r = n.Z,
                s = n.Z
        },
        61702: function(t, e, i) {
            i.d(e, {
                j: function() {
                    return n
                }
            });
            let n = "undefined" != typeof document
        },
        34829: function(t, e, i) {
            i.d(e, {
                P: function() {
                    return n
                }
            });
            let n = t => /^-?(?:\d+(?:\.\d+)?|\.\d+)$/u.test(t)
        },
        98285: function(t, e, i) {
            i.d(e, {
                I: function() {
                    return n
                }
            });

            function n(t) {
                return t && "object" == typeof t && Object.prototype.hasOwnProperty.call(t, "current")
            }
        },
        96894: function(t, e, i) {
            i.d(e, {
                W: function() {
                    return n
                }
            });
            let n = t => /^0[^.\s]+$/u.test(t)
        },
        66190: function(t, e, i) {
            i.d(e, {
                X: function() {
                    return n
                }
            });

            function n(t) {
                let e;
                return () => (void 0 === e && (e = t()), e)
            }
        },
        5312: function(t, e, i) {
            i.d(e, {
                t: function() {
                    return n
                }
            });
            let n = (t, e, i) => t + (e - t) * i
        },
        3393: function(t, e, i) {
            i.d(e, {
                Z: function() {
                    return n
                }
            });
            let n = t => t
        },
        55865: function(t, e, i) {
            i.d(e, {
                Y: function() {
                    return r
                }
            });
            var n = i(12426);

            function r(t) {
                let e = [0];
                return (0, n.c)(e, t.length - 1), e
            }
        },
        12426: function(t, e, i) {
            i.d(e, {
                c: function() {
                    return s
                }
            });
            var n = i(5312),
                r = i(16384);

            function s(t, e) {
                let i = t[t.length - 1];
                for (let s = 1; s <= e; s++) {
                    let o = (0, r.Y)(0, e, s);
                    t.push((0, n.t)(i, 1, o))
                }
            }
        },
        19280: function(t, e, i) {
            i.d(e, {
                z: function() {
                    return r
                }
            });
            let n = (t, e) => i => e(t(i)),
                r = (...t) => t.reduce(n)
        },
        16384: function(t, e, i) {
            i.d(e, {
                Y: function() {
                    return n
                }
            });
            let n = (t, e, i) => {
                let n = e - t;
                return 0 === n ? 1 : (i - t) / n
            }
        },
        30698: function(t, e, i) {
            i.d(e, {
                Y: function() {
                    return s
                },
                p: function() {
                    return r
                }
            });
            var n = i(60561);
            let r = t => !!(t && "object" == typeof t && t.mix && t.toValue),
                s = t => (0, n.C)(t) ? t[t.length - 1] || 0 : t
        },
        52685: function(t, e, i) {
            i.d(e, {
                L: function() {
                    return r
                }
            });
            var n = i(50406);
            class r {
                constructor() {
                    this.subscriptions = []
                }
                add(t) {
                    return (0, n.y4)(this.subscriptions, t), () => (0, n.cl)(this.subscriptions, t)
                }
                notify(t, e, i) {
                    let n = this.subscriptions.length;
                    if (n) {
                        if (1 === n) this.subscriptions[0](t, e, i);
                        else
                            for (let r = 0; r < n; r++) {
                                let n = this.subscriptions[r];
                                n && n(t, e, i)
                            }
                    }
                }
                getSize() {
                    return this.subscriptions.length
                }
                clear() {
                    this.subscriptions.length = 0
                }
            }
        },
        33303: function(t, e, i) {
            i.d(e, {
                X: function() {
                    return r
                },
                w: function() {
                    return n
                }
            });
            let n = t => 1e3 * t,
                r = t => t / 1e3
        },
        72435: function(t, e, i) {
            i.d(e, {
                h: function() {
                    return r
                }
            });
            var n = i(2265);

            function r(t) {
                let e = (0, n.useRef)(null);
                return null === e.current && (e.current = t()), e.current
            }
        },
        45526: function(t, e, i) {
            i.d(e, {
                L: function() {
                    return r
                }
            });
            var n = i(2265);
            let r = i(61702).j ? n.useLayoutEffect : n.useEffect
        },
        92181: function(t, e, i) {
            i.d(e, {
                R: function() {
                    return n
                }
            });

            function n(t, e) {
                return e ? 1e3 / e * t : 0
            }
        },
        83299: function(t, e, i) {
            i.d(e, {
                BX: function() {
                    return h
                }
            });
            var n = i(52685),
                r = i(92181),
                s = i(33791),
                o = i(14205);
            let a = t => !isNaN(parseFloat(t)),
                l = {
                    current: void 0
                };
            class u {
                constructor(t, e = {}) {
                    this.version = "11.0.24", this.canTrackVelocity = !1, this.events = {}, this.updateAndNotify = (t, e = !0) => {
                        let i = s.X.now();
                        this.updatedAt !== i && this.setPrevFrameValue(), this.prev = this.current, this.setCurrent(t), this.current !== this.prev && this.events.change && this.events.change.notify(this.current), e && this.events.renderRequest && this.events.renderRequest.notify(this.current)
                    }, this.hasAnimated = !1, this.setCurrent(t), this.canTrackVelocity = a(this.current), this.owner = e.owner
                }
                setCurrent(t) {
                    this.current = t, this.updatedAt = s.X.now()
                }
                setPrevFrameValue(t = this.current) {
                    this.prevFrameValue = t, this.prevUpdatedAt = this.updatedAt
                }
                onChange(t) {
                    return this.on("change", t)
                }
                on(t, e) {
                    this.events[t] || (this.events[t] = new n.L);
                    let i = this.events[t].add(e);
                    return "change" === t ? () => {
                        i(), o.Wi.read(() => {
                            this.events.change.getSize() || this.stop()
                        })
                    } : i
                }
                clearListeners() {
                    for (let t in this.events) this.events[t].clear()
                }
                attach(t, e) {
                    this.passiveEffect = t, this.stopPassiveEffect = e
                }
                set(t, e = !0) {
                    e && this.passiveEffect ? this.passiveEffect(t, this.updateAndNotify) : this.updateAndNotify(t, e)
                }
                setWithVelocity(t, e, i) {
                    this.set(e), this.prev = void 0, this.prevFrameValue = t, this.prevUpdatedAt = this.updatedAt - i
                }
                jump(t, e = !0) {
                    this.updateAndNotify(t), this.prev = t, this.prevUpdatedAt = this.prevFrameValue = void 0, e && this.stop(), this.stopPassiveEffect && this.stopPassiveEffect()
                }
                get() {
                    return l.current && l.current.push(this), this.current
                }
                getPrevious() {
                    return this.prev
                }
                getVelocity() {
                    let t = s.X.now();
                    if (!this.canTrackVelocity || void 0 === this.prevFrameValue || t - this.updatedAt > 30) return 0;
                    let e = Math.min(this.updatedAt - this.prevUpdatedAt, 30);
                    return (0, r.R)(parseFloat(this.current) - parseFloat(this.prevFrameValue), e)
                }
                start(t) {
                    return this.stop(), new Promise(e => {
                        this.hasAnimated = !0, this.animation = t(e), this.events.animationStart && this.events.animationStart.notify()
                    }).then(() => {
                        this.events.animationComplete && this.events.animationComplete.notify(), this.clearAnimation()
                    })
                }
                stop() {
                    this.animation && (this.animation.stop(), this.events.animationCancel && this.events.animationCancel.notify()), this.clearAnimation()
                }
                isAnimating() {
                    return !!this.animation
                }
                clearAnimation() {
                    delete this.animation
                }
                destroy() {
                    this.clearListeners(), this.stop(), this.stopPassiveEffect && this.stopPassiveEffect()
                }
            }

            function h(t, e) {
                return new u(t, e)
            }
        },
        34184: function(t, e, i) {
            i.d(e, {
                $: function() {
                    return r
                }
            });
            var n = i(46352);
            let r = {
                test: (0, i(90204).i)("#"),
                parse: function(t) {
                    let e = "",
                        i = "",
                        n = "",
                        r = "";
                    return t.length > 5 ? (e = t.substring(1, 3), i = t.substring(3, 5), n = t.substring(5, 7), r = t.substring(7, 9)) : (e = t.substring(1, 2), i = t.substring(2, 3), n = t.substring(3, 4), r = t.substring(4, 5), e += e, i += i, n += n, r += r), {
                        red: parseInt(e, 16),
                        green: parseInt(i, 16),
                        blue: parseInt(n, 16),
                        alpha: r ? parseInt(r, 16) / 255 : 1
                    }
                },
                transform: n.m.transform
            }
        },
        99808: function(t, e, i) {
            i.d(e, {
                J: function() {
                    return a
                }
            });
            var n = i(25218),
                r = i(72724),
                s = i(93922),
                o = i(90204);
            let a = {
                test: (0, o.i)("hsl", "hue"),
                parse: (0, o.d)("hue", "saturation", "lightness"),
                transform: ({
                    hue: t,
                    saturation: e,
                    lightness: i,
                    alpha: o = 1
                }) => "hsla(" + Math.round(t) + ", " + r.aQ.transform((0, s.Nw)(e)) + ", " + r.aQ.transform((0, s.Nw)(i)) + ", " + (0, s.Nw)(n.Fq.transform(o)) + ")"
            }
        },
        22809: function(t, e, i) {
            i.d(e, {
                $: function() {
                    return a
                }
            });
            var n = i(93922),
                r = i(34184),
                s = i(99808),
                o = i(46352);
            let a = {
                test: t => o.m.test(t) || r.$.test(t) || s.J.test(t),
                parse: t => o.m.test(t) ? o.m.parse(t) : s.J.test(t) ? s.J.parse(t) : r.$.parse(t),
                transform: t => (0, n.HD)(t) ? t : t.hasOwnProperty("red") ? o.m.transform(t) : s.J.transform(t)
            }
        },
        46352: function(t, e, i) {
            i.d(e, {
                m: function() {
                    return u
                }
            });
            var n = i(22476),
                r = i(25218),
                s = i(93922),
                o = i(90204);
            let a = t => (0, n.u)(0, 255, t),
                l = { ...r.Rx,
                    transform: t => Math.round(a(t))
                },
                u = {
                    test: (0, o.i)("rgb", "red"),
                    parse: (0, o.d)("red", "green", "blue"),
                    transform: ({
                        red: t,
                        green: e,
                        blue: i,
                        alpha: n = 1
                    }) => "rgba(" + l.transform(t) + ", " + l.transform(e) + ", " + l.transform(i) + ", " + (0, s.Nw)(r.Fq.transform(n)) + ")"
                }
        },
        90204: function(t, e, i) {
            i.d(e, {
                d: function() {
                    return s
                },
                i: function() {
                    return r
                }
            });
            var n = i(93922);
            let r = (t, e) => i => !!((0, n.HD)(i) && n.mj.test(i) && i.startsWith(t) || e && Object.prototype.hasOwnProperty.call(i, e)),
                s = (t, e, i) => r => {
                    if (!(0, n.HD)(r)) return r;
                    let [s, o, a, l] = r.match(n.KP);
                    return {
                        [t]: parseFloat(s),
                        [e]: parseFloat(o),
                        [i]: parseFloat(a),
                        alpha: void 0 !== l ? parseFloat(l) : 1
                    }
                }
        },
        82915: function(t, e, i) {
            i.d(e, {
                h: function() {
                    return l
                }
            });
            var n = i(92263),
                r = i(93922);
            let s = new Set(["brightness", "contrast", "saturate", "opacity"]);

            function o(t) {
                let [e, i] = t.slice(0, -1).split("(");
                if ("drop-shadow" === e) return t;
                let [n] = i.match(r.KP) || [];
                if (!n) return t;
                let o = i.replace(n, ""),
                    a = s.has(e) ? 1 : 0;
                return n !== i && (a *= 100), e + "(" + a + o + ")"
            }
            let a = /\b([a-z-]*)\(.*?\)/gu,
                l = { ...n.P,
                    getAnimatableNone: t => {
                        let e = t.match(a);
                        return e ? e.map(o).join(" ") : t
                    }
                }
        },
        92263: function(t, e, i) {
            i.d(e, {
                P: function() {
                    return d
                },
                V: function() {
                    return l
                }
            });
            var n = i(22809),
                r = i(93922);
            let s = "number",
                o = "color",
                a = /var\s*\(\s*--(?:[\w-]+\s*|[\w-]+\s*,(?:\s*[^)(\s]|\s*\((?:[^)(]|\([^)(]*\))*\))+\s*)\)|#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\)|-?(?:\d+(?:\.\d+)?|\.\d+)/giu;

            function l(t) {
                let e = t.toString(),
                    i = [],
                    r = {
                        color: [],
                        number: [],
                        var: []
                    },
                    l = [],
                    u = 0,
                    h = e.replace(a, t => (n.$.test(t) ? (r.color.push(u), l.push(o), i.push(n.$.parse(t))) : t.startsWith("var(") ? (r.var.push(u), l.push("var"), i.push(t)) : (r.number.push(u), l.push(s), i.push(parseFloat(t))), ++u, "${}")).split("${}");
                return {
                    values: i,
                    split: h,
                    indexes: r,
                    types: l
                }
            }

            function u(t) {
                return l(t).values
            }

            function h(t) {
                let {
                    split: e,
                    types: i
                } = l(t), a = e.length;
                return t => {
                    let l = "";
                    for (let u = 0; u < a; u++)
                        if (l += e[u], void 0 !== t[u]) {
                            let e = i[u];
                            e === s ? l += (0, r.Nw)(t[u]) : e === o ? l += n.$.transform(t[u]) : l += t[u]
                        }
                    return l
                }
            }
            let c = t => "number" == typeof t ? 0 : t,
                d = {
                    test: function(t) {
                        var e, i;
                        return isNaN(t) && (0, r.HD)(t) && ((null === (e = t.match(r.KP)) || void 0 === e ? void 0 : e.length) || 0) + ((null === (i = t.match(r.dA)) || void 0 === i ? void 0 : i.length) || 0) > 0
                    },
                    parse: u,
                    createTransformer: h,
                    getAnimatableNone: function(t) {
                        let e = u(t);
                        return h(t)(e.map(c))
                    }
                }
        },
        25218: function(t, e, i) {
            i.d(e, {
                Fq: function() {
                    return s
                },
                Rx: function() {
                    return r
                },
                bA: function() {
                    return o
                }
            });
            var n = i(22476);
            let r = {
                    test: t => "number" == typeof t,
                    parse: parseFloat,
                    transform: t => t
                },
                s = { ...r,
                    transform: t => (0, n.u)(0, 1, t)
                },
                o = { ...r,
                    default: 1
                }
        },
        72724: function(t, e, i) {
            i.d(e, {
                $C: function() {
                    return h
                },
                RW: function() {
                    return s
                },
                aQ: function() {
                    return o
                },
                px: function() {
                    return a
                },
                vh: function() {
                    return l
                },
                vw: function() {
                    return u
                }
            });
            var n = i(93922);
            let r = t => ({
                    test: e => (0, n.HD)(e) && e.endsWith(t) && 1 === e.split(" ").length,
                    parse: parseFloat,
                    transform: e => `${e}${t}`
                }),
                s = r("deg"),
                o = r("%"),
                a = r("px"),
                l = r("vh"),
                u = r("vw"),
                h = { ...o,
                    parse: t => o.parse(t) / 100,
                    transform: t => o.transform(100 * t)
                }
        },
        93922: function(t, e, i) {
            i.d(e, {
                HD: function() {
                    return a
                },
                KP: function() {
                    return r
                },
                Nw: function() {
                    return n
                },
                dA: function() {
                    return s
                },
                mj: function() {
                    return o
                }
            });
            let n = t => Math.round(1e5 * t) / 1e5,
                r = /-?(?:\d+(?:\.\d+)?|\.\d+)/gu,
                s = /(?:#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\))/giu,
                o = /^(?:#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\))$/iu;

            function a(t) {
                return "string" == typeof t
            }
        },
        62212: function(t, e, i) {
            i.d(e, {
                L: function() {
                    return r
                }
            });
            var n = i(82702);

            function r(t) {
                return !!((0, n.i)(t) && t.add)
            }
        },
        82702: function(t, e, i) {
            i.d(e, {
                i: function() {
                    return n
                }
            });
            let n = t => !!(t && t.getVelocity)
        },
        70158: function(t, e, i) {
            i.d(e, {
                w_: function() {
                    return h
                }
            });
            var n = i(2265),
                r = {
                    color: void 0,
                    size: void 0,
                    className: void 0,
                    style: void 0,
                    attr: void 0
                },
                s = n.createContext && n.createContext(r),
                o = ["attr", "size", "title"];

            function a() {
                return (a = Object.assign ? Object.assign.bind() : function(t) {
                    for (var e = 1; e < arguments.length; e++) {
                        var i = arguments[e];
                        for (var n in i) Object.prototype.hasOwnProperty.call(i, n) && (t[n] = i[n])
                    }
                    return t
                }).apply(this, arguments)
            }

            function l(t, e) {
                var i = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(t);
                    e && (n = n.filter(function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable
                    })), i.push.apply(i, n)
                }
                return i
            }

            function u(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var i = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? l(Object(i), !0).forEach(function(e) {
                        var n, r;
                        n = e, r = i[e], (n = function(t) {
                            var e = function(t, e) {
                                if ("object" != typeof t || null === t) return t;
                                var i = t[Symbol.toPrimitive];
                                if (void 0 !== i) {
                                    var n = i.call(t, e || "default");
                                    if ("object" != typeof n) return n;
                                    throw TypeError("@@toPrimitive must return a primitive value.")
                                }
                                return ("string" === e ? String : Number)(t)
                            }(t, "string");
                            return "symbol" == typeof e ? e : String(e)
                        }(n)) in t ? Object.defineProperty(t, n, {
                            value: r,
                            enumerable: !0,
                            configurable: !0,
                            writable: !0
                        }) : t[n] = r
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(i)) : l(Object(i)).forEach(function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(i, e))
                    })
                }
                return t
            }

            function h(t) {
                return e => n.createElement(c, a({
                    attr: u({}, t.attr)
                }, e), function t(e) {
                    return e && e.map((e, i) => n.createElement(e.tag, u({
                        key: i
                    }, e.attr), t(e.child)))
                }(t.child))
            }

            function c(t) {
                var e = e => {
                    var i, {
                            attr: r,
                            size: s,
                            title: l
                        } = t,
                        h = function(t, e) {
                            if (null == t) return {};
                            var i, n, r = function(t, e) {
                                if (null == t) return {};
                                var i, n, r = {},
                                    s = Object.keys(t);
                                for (n = 0; n < s.length; n++) i = s[n], e.indexOf(i) >= 0 || (r[i] = t[i]);
                                return r
                            }(t, e);
                            if (Object.getOwnPropertySymbols) {
                                var s = Object.getOwnPropertySymbols(t);
                                for (n = 0; n < s.length; n++) i = s[n], !(e.indexOf(i) >= 0) && Object.prototype.propertyIsEnumerable.call(t, i) && (r[i] = t[i])
                            }
                            return r
                        }(t, o),
                        c = s || e.size || "1em";
                    return e.className && (i = e.className), t.className && (i = (i ? i + " " : "") + t.className), n.createElement("svg", a({
                        stroke: "currentColor",
                        fill: "currentColor",
                        strokeWidth: "0"
                    }, e.attr, r, h, {
                        className: i,
                        style: u(u({
                            color: t.color || e.color
                        }, e.style), t.style),
                        height: c,
                        width: c,
                        xmlns: "http://www.w3.org/2000/svg"
                    }), l && n.createElement("title", null, l), t.children)
                };
                return void 0 !== s ? n.createElement(s.Consumer, null, t => e(t)) : e(r)
            }
        }
    }
]);