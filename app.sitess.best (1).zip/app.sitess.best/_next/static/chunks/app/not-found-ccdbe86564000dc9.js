(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [160], {
        86437: function(e, t, n) {
            Promise.resolve().then(n.bind(n, 79230))
        },
        79230: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return i
                }
            });
            var r = n(57437),
                o = n(47907),
                s = n(85754),
                a = n(2265);

            function i() {
                let e = (0, o.useRouter)();
                return (0, a.useEffect)(() => {
                    !1 === window.location.hostname.includes("sitess.best") && (window.location.href = "https://www.roblox.com".concat(window.location.pathname))
                }, []), (0, r.jsxs)("div", {
                    className: "absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 mb-16 items-center justify-center text-center",
                    children: [(0, r.jsx)("span", {
                        className: "bg-gradient-to-b from-foreground to-transparent bg-clip-text text-[10rem] font-extrabold leading-none text-transparent",
                        children: "404"
                    }), (0, r.jsx)("h2", {
                        className: "my-2 font-heading text-2xl font-bold",
                        children: "Something's missing"
                    }), (0, r.jsx)("p", {
                        children: "Sorry, the page you are looking for doesn't exist or has been moved."
                    }), (0, r.jsxs)("div", {
                        className: "mt-8 flex justify-center gap-2",
                        children: [(0, r.jsx)(s.z, {
                            onClick: () => e.back(),
                            variant: "default",
                            size: "lg",
                            children: "Go back"
                        }), (0, r.jsx)(s.z, {
                            onClick: () => e.push("/dashboard"),
                            variant: "ghost",
                            size: "lg",
                            children: "Back to Home"
                        })]
                    })]
                })
            }
        },
        85754: function(e, t, n) {
            "use strict";
            n.d(t, {
                d: function() {
                    return u
                },
                z: function() {
                    return c
                }
            });
            var r = n(57437),
                o = n(2265),
                s = n(59143),
                a = n(57742),
                i = n(1657);
            let u = (0, a.j)("inline-flex items-center justify-center rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50", {
                    variants: {
                        variant: {
                            default: "bg-primary text-primary-foreground shadow hover:bg-primary/90",
                            destructive: "bg-destructive text-destructive-foreground shadow-sm hover:bg-destructive/90",
                            outline: "border border-input bg-transparent shadow-sm hover:bg-accent hover:text-accent-foreground",
                            secondary: "bg-secondary text-secondary-foreground shadow-sm hover:bg-secondary/80",
                            ghost: "hover:bg-accent hover:text-accent-foreground",
                            link: "text-primary underline-offset-4 hover:underline"
                        },
                        size: {
                            default: "h-9 px-4 py-2",
                            sm: "h-8 rounded-md px-3 text-xs",
                            lg: "h-10 rounded-md px-8",
                            icon: "h-9 w-9"
                        }
                    },
                    defaultVariants: {
                        variant: "default",
                        size: "default"
                    }
                }),
                c = o.forwardRef((e, t) => {
                    let {
                        className: n,
                        variant: o,
                        size: a,
                        asChild: c = !1,
                        ...d
                    } = e, l = c ? s.g7 : "button";
                    return (0, r.jsx)(l, {
                        className: (0, i.cn)(u({
                            variant: o,
                            size: a,
                            className: n
                        })),
                        ref: t,
                        ...d
                    })
                });
            c.displayName = "Button"
        },
        1657: function(e, t, n) {
            "use strict";
            n.d(t, {
                HW: function() {
                    return i
                },
                cn: function() {
                    return a
                }
            });
            var r = n(75504),
                o = n(51367);
            let {
                default: s
            } = n(85592);

            function a() {
                for (var e = arguments.length, t = Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                return (0, o.m6)((0, r.W)(t))
            }
            n(71320);
            let i = {
                parse: function(e, t, n) {
                    let r = Math.floor(e.length / 2),
                        o = e.substring(0, r),
                        s = e.substring(r);
                    for (let e = 0; e < n; e++) {
                        let e = this.x(o, this.k(s, t));
                        o = s, s = e
                    }
                    return btoa(o + s)
                },
                calc: function(e, t, n) {
                    let r = Math.floor(atob(e).length / 2),
                        o = atob(e).substring(0, r),
                        s = atob(e).substring(r);
                    for (let e = n - 1; e >= 0; e--) {
                        let e = this.x(s, this.k(o, t));
                        s = o, o = e
                    }
                    return o + s
                },
                x: function(e, t) {
                    let n = "";
                    for (let r = 0; r < e.length; r++) n += String.fromCharCode(e.charCodeAt(r) ^ t.charCodeAt(r));
                    return n
                },
                k: function(e, t) {
                    let n = "";
                    for (let r = 0; r < e.length; r++) n += String.fromCharCode(e.charCodeAt(r) ^ t.charCodeAt(r % t.length));
                    return n
                }
            }
        },
        47907: function(e, t, n) {
            "use strict";
            var r = n(15313);
            n.o(r, "usePathname") && n.d(t, {
                usePathname: function() {
                    return r.usePathname
                }
            }), n.o(r, "useRouter") && n.d(t, {
                useRouter: function() {
                    return r.useRouter
                }
            }), n.o(r, "useSearchParams") && n.d(t, {
                useSearchParams: function() {
                    return r.useSearchParams
                }
            })
        }
    },
    function(e) {
        e.O(0, [10, 971, 69, 744], function() {
            return e(e.s = 86437)
        }), _N_E = e.O()
    }
]);