(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [10], {
        71320: function(e, r, t) {
            var o = t(30073);

            function n(e) {
                switch (e) {
                    case "%20":
                        return " ";
                    case "%3D":
                        return "=";
                    case "%3A":
                        return ":";
                    case "%2F":
                        return "/";
                    default:
                        return e.toLowerCase()
                }
            }

            function l(e) {
                var r;
                if ("string" != typeof e) throw TypeError("Expected a string, but received " + typeof e);
                return 65279 === e.charCodeAt(0) && (e = e.slice(1)), "data:image/svg+xml," + encodeURIComponent((r = e.trim().replace(/\s+/g, " "), Object.keys(o).forEach(function(e) {
                    o[e].test(r) && (r = r.replace(o[e], e))
                }), r).replace(/"/g, "'")).replace(/%[\dA-F]{2}/g, n)
            }
            l.toSrcset = function(e) {
                return l(e).replace(/ /g, "%20")
            }, e.exports = l
        },
        30073: function(e) {
            e.exports = {
                aqua: /#00ffff(ff)?(?!\w)|#0ff(f)?(?!\w)/gi,
                azure: /#f0ffff(ff)?(?!\w)/gi,
                beige: /#f5f5dc(ff)?(?!\w)/gi,
                bisque: /#ffe4c4(ff)?(?!\w)/gi,
                black: /#000000(ff)?(?!\w)|#000(f)?(?!\w)/gi,
                blue: /#0000ff(ff)?(?!\w)|#00f(f)?(?!\w)/gi,
                brown: /#a52a2a(ff)?(?!\w)/gi,
                coral: /#ff7f50(ff)?(?!\w)/gi,
                cornsilk: /#fff8dc(ff)?(?!\w)/gi,
                crimson: /#dc143c(ff)?(?!\w)/gi,
                cyan: /#00ffff(ff)?(?!\w)|#0ff(f)?(?!\w)/gi,
                darkblue: /#00008b(ff)?(?!\w)/gi,
                darkcyan: /#008b8b(ff)?(?!\w)/gi,
                darkgrey: /#a9a9a9(ff)?(?!\w)/gi,
                darkred: /#8b0000(ff)?(?!\w)/gi,
                deeppink: /#ff1493(ff)?(?!\w)/gi,
                dimgrey: /#696969(ff)?(?!\w)/gi,
                gold: /#ffd700(ff)?(?!\w)/gi,
                green: /#008000(ff)?(?!\w)/gi,
                grey: /#808080(ff)?(?!\w)/gi,
                honeydew: /#f0fff0(ff)?(?!\w)/gi,
                hotpink: /#ff69b4(ff)?(?!\w)/gi,
                indigo: /#4b0082(ff)?(?!\w)/gi,
                ivory: /#fffff0(ff)?(?!\w)/gi,
                khaki: /#f0e68c(ff)?(?!\w)/gi,
                lavender: /#e6e6fa(ff)?(?!\w)/gi,
                lime: /#00ff00(ff)?(?!\w)|#0f0(f)?(?!\w)/gi,
                linen: /#faf0e6(ff)?(?!\w)/gi,
                maroon: /#800000(ff)?(?!\w)/gi,
                moccasin: /#ffe4b5(ff)?(?!\w)/gi,
                navy: /#000080(ff)?(?!\w)/gi,
                oldlace: /#fdf5e6(ff)?(?!\w)/gi,
                olive: /#808000(ff)?(?!\w)/gi,
                orange: /#ffa500(ff)?(?!\w)/gi,
                orchid: /#da70d6(ff)?(?!\w)/gi,
                peru: /#cd853f(ff)?(?!\w)/gi,
                pink: /#ffc0cb(ff)?(?!\w)/gi,
                plum: /#dda0dd(ff)?(?!\w)/gi,
                purple: /#800080(ff)?(?!\w)/gi,
                red: /#ff0000(ff)?(?!\w)|#f00(f)?(?!\w)/gi,
                salmon: /#fa8072(ff)?(?!\w)/gi,
                seagreen: /#2e8b57(ff)?(?!\w)/gi,
                seashell: /#fff5ee(ff)?(?!\w)/gi,
                sienna: /#a0522d(ff)?(?!\w)/gi,
                silver: /#c0c0c0(ff)?(?!\w)/gi,
                skyblue: /#87ceeb(ff)?(?!\w)/gi,
                snow: /#fffafa(ff)?(?!\w)/gi,
                tan: /#d2b48c(ff)?(?!\w)/gi,
                teal: /#008080(ff)?(?!\w)/gi,
                thistle: /#d8bfd8(ff)?(?!\w)/gi,
                tomato: /#ff6347(ff)?(?!\w)/gi,
                violet: /#ee82ee(ff)?(?!\w)/gi,
                wheat: /#f5deb3(ff)?(?!\w)/gi,
                white: /#ffffff(ff)?(?!\w)|#fff(f)?(?!\w)/gi
            }
        },
        85592: function(e, r) {
            "use strict";
            Object.defineProperty(r, "__esModule", {
                value: !0
            }), Object.defineProperty(r, "default", {
                enumerable: !0,
                get: function() {
                    return o
                }
            });
            let t = e => Object.assign({}, ...Object.entries(null != e ? e : {}).flatMap(([e, r]) => "object" == typeof r ? Object.entries(t(r)).map(([r, t]) => ({
                    [e + ("DEFAULT" === r ? "" : `-${r}`)]: t
                })) : [{
                    [`${e}`]: r
                }])),
                o = t
        },
        14749: function(e, r, t) {
            "use strict";

            function o() {
                return (o = Object.assign ? Object.assign.bind() : function(e) {
                    for (var r = 1; r < arguments.length; r++) {
                        var t = arguments[r];
                        for (var o in t) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o])
                    }
                    return e
                }).apply(this, arguments)
            }
            t.d(r, {
                Z: function() {
                    return o
                }
            })
        },
        61266: function(e, r, t) {
            "use strict";
            t.d(r, {
                F: function() {
                    return n
                },
                e: function() {
                    return l
                }
            });
            var o = t(2265);

            function n(...e) {
                return r => e.forEach(e => {
                    "function" == typeof e ? e(r) : null != e && (e.current = r)
                })
            }

            function l(...e) {
                return (0, o.useCallback)(n(...e), e)
            }
        },
        59143: function(e, r, t) {
            "use strict";
            t.d(r, {
                A4: function() {
                    return s
                },
                g7: function() {
                    return i
                }
            });
            var o = t(14749),
                n = t(2265),
                l = t(61266);
            let i = (0, n.forwardRef)((e, r) => {
                let {
                    children: t,
                    ...l
                } = e, i = n.Children.toArray(t), s = i.find(c);
                if (s) {
                    let e = s.props.children,
                        t = i.map(r => r !== s ? r : n.Children.count(e) > 1 ? n.Children.only(null) : (0, n.isValidElement)(e) ? e.props.children : null);
                    return (0, n.createElement)(a, (0, o.Z)({}, l, {
                        ref: r
                    }), (0, n.isValidElement)(e) ? (0, n.cloneElement)(e, void 0, t) : null)
                }
                return (0, n.createElement)(a, (0, o.Z)({}, l, {
                    ref: r
                }), t)
            });
            i.displayName = "Slot";
            let a = (0, n.forwardRef)((e, r) => {
                let {
                    children: t,
                    ...o
                } = e;
                return (0, n.isValidElement)(t) ? (0, n.cloneElement)(t, { ... function(e, r) {
                        let t = { ...r
                        };
                        for (let o in r) {
                            let n = e[o],
                                l = r[o];
                            /^on[A-Z]/.test(o) ? n && l ? t[o] = (...e) => {
                                l(...e), n(...e)
                            } : n && (t[o] = n) : "style" === o ? t[o] = { ...n,
                                ...l
                            } : "className" === o && (t[o] = [n, l].filter(Boolean).join(" "))
                        }
                        return { ...e,
                            ...t
                        }
                    }(o, t.props),
                    ref: r ? (0, l.F)(r, t.ref) : t.ref
                }) : n.Children.count(t) > 1 ? n.Children.only(null) : null
            });
            a.displayName = "SlotClone";
            let s = ({
                children: e
            }) => (0, n.createElement)(n.Fragment, null, e);

            function c(e) {
                return (0, n.isValidElement)(e) && e.type === s
            }
        },
        57742: function(e, r, t) {
            "use strict";
            t.d(r, {
                j: function() {
                    return l
                }
            });
            let o = e => "boolean" == typeof e ? "".concat(e) : 0 === e ? "0" : e,
                n = function() {
                    for (var e, r, t = 0, o = ""; t < arguments.length;)(e = arguments[t++]) && (r = function e(r) {
                        var t, o, n = "";
                        if ("string" == typeof r || "number" == typeof r) n += r;
                        else if ("object" == typeof r) {
                            if (Array.isArray(r))
                                for (t = 0; t < r.length; t++) r[t] && (o = e(r[t])) && (n && (n += " "), n += o);
                            else
                                for (t in r) r[t] && (n && (n += " "), n += t)
                        }
                        return n
                    }(e)) && (o && (o += " "), o += r);
                    return o
                },
                l = (e, r) => t => {
                    var l;
                    if ((null == r ? void 0 : r.variants) == null) return n(e, null == t ? void 0 : t.class, null == t ? void 0 : t.className);
                    let {
                        variants: i,
                        defaultVariants: a
                    } = r, s = Object.keys(i).map(e => {
                        let r = null == t ? void 0 : t[e],
                            n = null == a ? void 0 : a[e];
                        if (null === r) return null;
                        let l = o(r) || o(n);
                        return i[e][l]
                    }), c = t && Object.entries(t).reduce((e, r) => {
                        let [t, o] = r;
                        return void 0 === o || (e[t] = o), e
                    }, {});
                    return n(e, s, null == r ? void 0 : null === (l = r.compoundVariants) || void 0 === l ? void 0 : l.reduce((e, r) => {
                        let {
                            class: t,
                            className: o,
                            ...n
                        } = r;
                        return Object.entries(n).every(e => {
                            let [r, t] = e;
                            return Array.isArray(t) ? t.includes({ ...a,
                                ...c
                            }[r]) : ({ ...a,
                                ...c
                            })[r] === t
                        }) ? [...e, t, o] : e
                    }, []), null == t ? void 0 : t.class, null == t ? void 0 : t.className)
                }
        },
        75504: function(e, r, t) {
            "use strict";

            function o() {
                for (var e, r, t = 0, o = "", n = arguments.length; t < n; t++)(e = arguments[t]) && (r = function e(r) {
                    var t, o, n = "";
                    if ("string" == typeof r || "number" == typeof r) n += r;
                    else if ("object" == typeof r) {
                        if (Array.isArray(r)) {
                            var l = r.length;
                            for (t = 0; t < l; t++) r[t] && (o = e(r[t])) && (n && (n += " "), n += o)
                        } else
                            for (o in r) r[o] && (n && (n += " "), n += o)
                    }
                    return n
                }(e)) && (o && (o += " "), o += r);
                return o
            }
            t.d(r, {
                W: function() {
                    return o
                }
            }), r.Z = o
        },
        51367: function(e, r, t) {
            "use strict";
            t.d(r, {
                m6: function() {
                    return _
                }
            });
            let o = /^\[(.+)\]$/;

            function n(e, r) {
                let t = e;
                return r.split("-").forEach(e => {
                    t.nextPart.has(e) || t.nextPart.set(e, {
                        nextPart: new Map,
                        validators: []
                    }), t = t.nextPart.get(e)
                }), t
            }
            let l = /\s+/;

            function i() {
                let e, r, t = 0,
                    o = "";
                for (; t < arguments.length;)(e = arguments[t++]) && (r = function e(r) {
                    let t;
                    if ("string" == typeof r) return r;
                    let o = "";
                    for (let n = 0; n < r.length; n++) r[n] && (t = e(r[n])) && (o && (o += " "), o += t);
                    return o
                }(e)) && (o && (o += " "), o += r);
                return o
            }

            function a(e) {
                let r = r => r[e] || [];
                return r.isThemeGetter = !0, r
            }
            let s = /^\[(?:([a-z-]+):)?(.+)\]$/i,
                c = /^\d+\/\d+$/,
                d = new Set(["px", "full", "screen"]),
                f = /^(\d+(\.\d+)?)?(xs|sm|md|lg|xl)$/,
                u = /\d+(%|px|r?em|[sdl]?v([hwib]|min|max)|pt|pc|in|cm|mm|cap|ch|ex|r?lh|cq(w|h|i|b|min|max))|\b(calc|min|max|clamp)\(.+\)|^0$/,
                p = /^(rgba?|hsla?|hwb|(ok)?(lab|lch))\(.+\)$/,
                b = /^(inset_)?-?((\d+)?\.?(\d+)[a-z]+|0)_-?((\d+)?\.?(\d+)[a-z]+|0)/,
                g = /^(url|image|image-set|cross-fade|element|(repeating-)?(linear|radial|conic)-gradient)\(.+\)$/;

            function m(e) {
                return w(e) || d.has(e) || c.test(e)
            }

            function h(e) {
                return P(e, "length", G)
            }

            function w(e) {
                return !!e && !Number.isNaN(Number(e))
            }

            function y(e) {
                return P(e, "number", w)
            }

            function v(e) {
                return !!e && Number.isInteger(Number(e))
            }

            function x(e) {
                return e.endsWith("%") && w(e.slice(0, -1))
            }

            function k(e) {
                return s.test(e)
            }

            function z(e) {
                return f.test(e)
            }
            let j = new Set(["length", "size", "percentage"]);

            function C(e) {
                return P(e, j, M)
            }

            function E(e) {
                return P(e, "position", M)
            }
            let O = new Set(["image", "url"]);

            function N(e) {
                return P(e, O, I)
            }

            function S(e) {
                return P(e, "", $)
            }

            function A() {
                return !0
            }

            function P(e, r, t) {
                let o = s.exec(e);
                return !!o && (o[1] ? "string" == typeof r ? o[1] === r : r.has(o[1]) : t(o[2]))
            }

            function G(e) {
                return u.test(e) && !p.test(e)
            }

            function M() {
                return !1
            }

            function $(e) {
                return b.test(e)
            }

            function I(e) {
                return g.test(e)
            }
            let _ = function(e) {
                let r, t, a;
                let s = function(l) {
                    var i;
                    return t = (r = {
                        cache: function(e) {
                            if (e < 1) return {
                                get: () => void 0,
                                set: () => {}
                            };
                            let r = 0,
                                t = new Map,
                                o = new Map;

                            function n(n, l) {
                                t.set(n, l), ++r > e && (r = 0, o = t, t = new Map)
                            }
                            return {
                                get(e) {
                                    let r = t.get(e);
                                    return void 0 !== r ? r : void 0 !== (r = o.get(e)) ? (n(e, r), r) : void 0
                                },
                                set(e, r) {
                                    t.has(e) ? t.set(e, r) : n(e, r)
                                }
                            }
                        }((i = [].reduce((e, r) => r(e), e())).cacheSize),
                        splitModifiers: function(e) {
                            let r = e.separator,
                                t = 1 === r.length,
                                o = r[0],
                                n = r.length;
                            return function(e) {
                                let l;
                                let i = [],
                                    a = 0,
                                    s = 0;
                                for (let c = 0; c < e.length; c++) {
                                    let d = e[c];
                                    if (0 === a) {
                                        if (d === o && (t || e.slice(c, c + n) === r)) {
                                            i.push(e.slice(s, c)), s = c + n;
                                            continue
                                        }
                                        if ("/" === d) {
                                            l = c;
                                            continue
                                        }
                                    }
                                    "[" === d ? a++ : "]" === d && a--
                                }
                                let c = 0 === i.length ? e : e.substring(s),
                                    d = c.startsWith("!"),
                                    f = d ? c.substring(1) : c;
                                return {
                                    modifiers: i,
                                    hasImportantModifier: d,
                                    baseClassName: f,
                                    maybePostfixModifierPosition: l && l > s ? l - s : void 0
                                }
                            }
                        }(i),
                        ... function(e) {
                            let r = function(e) {
                                    var r;
                                    let {
                                        theme: t,
                                        prefix: o
                                    } = e, l = {
                                        nextPart: new Map,
                                        validators: []
                                    };
                                    return (r = Object.entries(e.classGroups), o ? r.map(([e, r]) => [e, r.map(e => "string" == typeof e ? o + e : "object" == typeof e ? Object.fromEntries(Object.entries(e).map(([e, r]) => [o + e, r])) : e)]) : r).forEach(([e, r]) => {
                                        (function e(r, t, o, l) {
                                            r.forEach(r => {
                                                if ("string" == typeof r) {
                                                    ("" === r ? t : n(t, r)).classGroupId = o;
                                                    return
                                                }
                                                if ("function" == typeof r) {
                                                    if (r.isThemeGetter) {
                                                        e(r(l), t, o, l);
                                                        return
                                                    }
                                                    t.validators.push({
                                                        validator: r,
                                                        classGroupId: o
                                                    });
                                                    return
                                                }
                                                Object.entries(r).forEach(([r, i]) => {
                                                    e(i, n(t, r), o, l)
                                                })
                                            })
                                        })(r, l, e, t)
                                    }), l
                                }(e),
                                {
                                    conflictingClassGroups: t,
                                    conflictingClassGroupModifiers: l
                                } = e;
                            return {
                                getClassGroupId: function(e) {
                                    let t = e.split("-");
                                    return "" === t[0] && 1 !== t.length && t.shift(),
                                        function e(r, t) {
                                            if (0 === r.length) return t.classGroupId;
                                            let o = r[0],
                                                n = t.nextPart.get(o),
                                                l = n ? e(r.slice(1), n) : void 0;
                                            if (l) return l;
                                            if (0 === t.validators.length) return;
                                            let i = r.join("-");
                                            return t.validators.find(({
                                                validator: e
                                            }) => e(i)) ? .classGroupId
                                        }(t, r) || function(e) {
                                            if (o.test(e)) {
                                                let r = o.exec(e)[1],
                                                    t = r ? .substring(0, r.indexOf(":"));
                                                if (t) return "arbitrary.." + t
                                            }
                                        }(e)
                                },
                                getConflictingClassGroupIds: function(e, r) {
                                    let o = t[e] || [];
                                    return r && l[e] ? [...o, ...l[e]] : o
                                }
                            }
                        }(i)
                    }).cache.get, a = r.cache.set, s = c, c(l)
                };

                function c(e) {
                    let o = t(e);
                    if (o) return o;
                    let n = function(e, r) {
                        let {
                            splitModifiers: t,
                            getClassGroupId: o,
                            getConflictingClassGroupIds: n
                        } = r, i = new Set;
                        return e.trim().split(l).map(e => {
                            let {
                                modifiers: r,
                                hasImportantModifier: n,
                                baseClassName: l,
                                maybePostfixModifierPosition: i
                            } = t(e), a = o(i ? l.substring(0, i) : l), s = !!i;
                            if (!a) {
                                if (!i || !(a = o(l))) return {
                                    isTailwindClass: !1,
                                    originalClassName: e
                                };
                                s = !1
                            }
                            let c = (function(e) {
                                if (e.length <= 1) return e;
                                let r = [],
                                    t = [];
                                return e.forEach(e => {
                                    "[" === e[0] ? (r.push(...t.sort(), e), t = []) : t.push(e)
                                }), r.push(...t.sort()), r
                            })(r).join(":");
                            return {
                                isTailwindClass: !0,
                                modifierId: n ? c + "!" : c,
                                classGroupId: a,
                                originalClassName: e,
                                hasPostfixModifier: s
                            }
                        }).reverse().filter(e => {
                            if (!e.isTailwindClass) return !0;
                            let {
                                modifierId: r,
                                classGroupId: t,
                                hasPostfixModifier: o
                            } = e, l = r + t;
                            return !i.has(l) && (i.add(l), n(t, o).forEach(e => i.add(r + e)), !0)
                        }).reverse().map(e => e.originalClassName).join(" ")
                    }(e, r);
                    return a(e, n), n
                }
                return function() {
                    return s(i.apply(null, arguments))
                }
            }(function() {
                let e = a("colors"),
                    r = a("spacing"),
                    t = a("blur"),
                    o = a("brightness"),
                    n = a("borderColor"),
                    l = a("borderRadius"),
                    i = a("borderSpacing"),
                    s = a("borderWidth"),
                    c = a("contrast"),
                    d = a("grayscale"),
                    f = a("hueRotate"),
                    u = a("invert"),
                    p = a("gap"),
                    b = a("gradientColorStops"),
                    g = a("gradientColorStopPositions"),
                    j = a("inset"),
                    O = a("margin"),
                    P = a("opacity"),
                    G = a("padding"),
                    M = a("saturate"),
                    $ = a("scale"),
                    I = a("sepia"),
                    _ = a("skew"),
                    R = a("space"),
                    T = a("translate"),
                    F = () => ["auto", "contain", "none"],
                    V = () => ["auto", "hidden", "clip", "visible", "scroll"],
                    W = () => ["auto", k, r],
                    Z = () => [k, r],
                    q = () => ["", m, h],
                    D = () => ["auto", w, k],
                    L = () => ["bottom", "center", "left", "left-bottom", "left-top", "right", "right-bottom", "right-top", "top"],
                    U = () => ["solid", "dashed", "dotted", "double", "none"],
                    B = () => ["normal", "multiply", "screen", "overlay", "darken", "lighten", "color-dodge", "color-burn", "hard-light", "soft-light", "difference", "exclusion", "hue", "saturation", "color", "luminosity", "plus-lighter"],
                    H = () => ["start", "end", "center", "between", "around", "evenly", "stretch"],
                    J = () => ["", "0", k],
                    K = () => ["auto", "avoid", "all", "avoid-page", "page", "left", "right", "column"],
                    Q = () => [w, y],
                    X = () => [w, k];
                return {
                    cacheSize: 500,
                    separator: ":",
                    theme: {
                        colors: [A],
                        spacing: [m, h],
                        blur: ["none", "", z, k],
                        brightness: Q(),
                        borderColor: [e],
                        borderRadius: ["none", "", "full", z, k],
                        borderSpacing: Z(),
                        borderWidth: q(),
                        contrast: Q(),
                        grayscale: J(),
                        hueRotate: X(),
                        invert: J(),
                        gap: Z(),
                        gradientColorStops: [e],
                        gradientColorStopPositions: [x, h],
                        inset: W(),
                        margin: W(),
                        opacity: Q(),
                        padding: Z(),
                        saturate: Q(),
                        scale: Q(),
                        sepia: J(),
                        skew: X(),
                        space: Z(),
                        translate: Z()
                    },
                    classGroups: {
                        aspect: [{
                            aspect: ["auto", "square", "video", k]
                        }],
                        container: ["container"],
                        columns: [{
                            columns: [z]
                        }],
                        "break-after": [{
                            "break-after": K()
                        }],
                        "break-before": [{
                            "break-before": K()
                        }],
                        "break-inside": [{
                            "break-inside": ["auto", "avoid", "avoid-page", "avoid-column"]
                        }],
                        "box-decoration": [{
                            "box-decoration": ["slice", "clone"]
                        }],
                        box: [{
                            box: ["border", "content"]
                        }],
                        display: ["block", "inline-block", "inline", "flex", "inline-flex", "table", "inline-table", "table-caption", "table-cell", "table-column", "table-column-group", "table-footer-group", "table-header-group", "table-row-group", "table-row", "flow-root", "grid", "inline-grid", "contents", "list-item", "hidden"],
                        float: [{
                            float: ["right", "left", "none", "start", "end"]
                        }],
                        clear: [{
                            clear: ["left", "right", "both", "none", "start", "end"]
                        }],
                        isolation: ["isolate", "isolation-auto"],
                        "object-fit": [{
                            object: ["contain", "cover", "fill", "none", "scale-down"]
                        }],
                        "object-position": [{
                            object: [...L(), k]
                        }],
                        overflow: [{
                            overflow: V()
                        }],
                        "overflow-x": [{
                            "overflow-x": V()
                        }],
                        "overflow-y": [{
                            "overflow-y": V()
                        }],
                        overscroll: [{
                            overscroll: F()
                        }],
                        "overscroll-x": [{
                            "overscroll-x": F()
                        }],
                        "overscroll-y": [{
                            "overscroll-y": F()
                        }],
                        position: ["static", "fixed", "absolute", "relative", "sticky"],
                        inset: [{
                            inset: [j]
                        }],
                        "inset-x": [{
                            "inset-x": [j]
                        }],
                        "inset-y": [{
                            "inset-y": [j]
                        }],
                        start: [{
                            start: [j]
                        }],
                        end: [{
                            end: [j]
                        }],
                        top: [{
                            top: [j]
                        }],
                        right: [{
                            right: [j]
                        }],
                        bottom: [{
                            bottom: [j]
                        }],
                        left: [{
                            left: [j]
                        }],
                        visibility: ["visible", "invisible", "collapse"],
                        z: [{
                            z: ["auto", v, k]
                        }],
                        basis: [{
                            basis: W()
                        }],
                        "flex-direction": [{
                            flex: ["row", "row-reverse", "col", "col-reverse"]
                        }],
                        "flex-wrap": [{
                            flex: ["wrap", "wrap-reverse", "nowrap"]
                        }],
                        flex: [{
                            flex: ["1", "auto", "initial", "none", k]
                        }],
                        grow: [{
                            grow: J()
                        }],
                        shrink: [{
                            shrink: J()
                        }],
                        order: [{
                            order: ["first", "last", "none", v, k]
                        }],
                        "grid-cols": [{
                            "grid-cols": [A]
                        }],
                        "col-start-end": [{
                            col: ["auto", {
                                span: ["full", v, k]
                            }, k]
                        }],
                        "col-start": [{
                            "col-start": D()
                        }],
                        "col-end": [{
                            "col-end": D()
                        }],
                        "grid-rows": [{
                            "grid-rows": [A]
                        }],
                        "row-start-end": [{
                            row: ["auto", {
                                span: [v, k]
                            }, k]
                        }],
                        "row-start": [{
                            "row-start": D()
                        }],
                        "row-end": [{
                            "row-end": D()
                        }],
                        "grid-flow": [{
                            "grid-flow": ["row", "col", "dense", "row-dense", "col-dense"]
                        }],
                        "auto-cols": [{
                            "auto-cols": ["auto", "min", "max", "fr", k]
                        }],
                        "auto-rows": [{
                            "auto-rows": ["auto", "min", "max", "fr", k]
                        }],
                        gap: [{
                            gap: [p]
                        }],
                        "gap-x": [{
                            "gap-x": [p]
                        }],
                        "gap-y": [{
                            "gap-y": [p]
                        }],
                        "justify-content": [{
                            justify: ["normal", ...H()]
                        }],
                        "justify-items": [{
                            "justify-items": ["start", "end", "center", "stretch"]
                        }],
                        "justify-self": [{
                            "justify-self": ["auto", "start", "end", "center", "stretch"]
                        }],
                        "align-content": [{
                            content: ["normal", ...H(), "baseline"]
                        }],
                        "align-items": [{
                            items: ["start", "end", "center", "baseline", "stretch"]
                        }],
                        "align-self": [{
                            self: ["auto", "start", "end", "center", "stretch", "baseline"]
                        }],
                        "place-content": [{
                            "place-content": [...H(), "baseline"]
                        }],
                        "place-items": [{
                            "place-items": ["start", "end", "center", "baseline", "stretch"]
                        }],
                        "place-self": [{
                            "place-self": ["auto", "start", "end", "center", "stretch"]
                        }],
                        p: [{
                            p: [G]
                        }],
                        px: [{
                            px: [G]
                        }],
                        py: [{
                            py: [G]
                        }],
                        ps: [{
                            ps: [G]
                        }],
                        pe: [{
                            pe: [G]
                        }],
                        pt: [{
                            pt: [G]
                        }],
                        pr: [{
                            pr: [G]
                        }],
                        pb: [{
                            pb: [G]
                        }],
                        pl: [{
                            pl: [G]
                        }],
                        m: [{
                            m: [O]
                        }],
                        mx: [{
                            mx: [O]
                        }],
                        my: [{
                            my: [O]
                        }],
                        ms: [{
                            ms: [O]
                        }],
                        me: [{
                            me: [O]
                        }],
                        mt: [{
                            mt: [O]
                        }],
                        mr: [{
                            mr: [O]
                        }],
                        mb: [{
                            mb: [O]
                        }],
                        ml: [{
                            ml: [O]
                        }],
                        "space-x": [{
                            "space-x": [R]
                        }],
                        "space-x-reverse": ["space-x-reverse"],
                        "space-y": [{
                            "space-y": [R]
                        }],
                        "space-y-reverse": ["space-y-reverse"],
                        w: [{
                            w: ["auto", "min", "max", "fit", "svw", "lvw", "dvw", k, r]
                        }],
                        "min-w": [{
                            "min-w": [k, r, "min", "max", "fit"]
                        }],
                        "max-w": [{
                            "max-w": [k, r, "none", "full", "min", "max", "fit", "prose", {
                                screen: [z]
                            }, z]
                        }],
                        h: [{
                            h: [k, r, "auto", "min", "max", "fit", "svh", "lvh", "dvh"]
                        }],
                        "min-h": [{
                            "min-h": [k, r, "min", "max", "fit", "svh", "lvh", "dvh"]
                        }],
                        "max-h": [{
                            "max-h": [k, r, "min", "max", "fit", "svh", "lvh", "dvh"]
                        }],
                        size: [{
                            size: [k, r, "auto", "min", "max", "fit"]
                        }],
                        "font-size": [{
                            text: ["base", z, h]
                        }],
                        "font-smoothing": ["antialiased", "subpixel-antialiased"],
                        "font-style": ["italic", "not-italic"],
                        "font-weight": [{
                            font: ["thin", "extralight", "light", "normal", "medium", "semibold", "bold", "extrabold", "black", y]
                        }],
                        "font-family": [{
                            font: [A]
                        }],
                        "fvn-normal": ["normal-nums"],
                        "fvn-ordinal": ["ordinal"],
                        "fvn-slashed-zero": ["slashed-zero"],
                        "fvn-figure": ["lining-nums", "oldstyle-nums"],
                        "fvn-spacing": ["proportional-nums", "tabular-nums"],
                        "fvn-fraction": ["diagonal-fractions", "stacked-fractons"],
                        tracking: [{
                            tracking: ["tighter", "tight", "normal", "wide", "wider", "widest", k]
                        }],
                        "line-clamp": [{
                            "line-clamp": ["none", w, y]
                        }],
                        leading: [{
                            leading: ["none", "tight", "snug", "normal", "relaxed", "loose", m, k]
                        }],
                        "list-image": [{
                            "list-image": ["none", k]
                        }],
                        "list-style-type": [{
                            list: ["none", "disc", "decimal", k]
                        }],
                        "list-style-position": [{
                            list: ["inside", "outside"]
                        }],
                        "placeholder-color": [{
                            placeholder: [e]
                        }],
                        "placeholder-opacity": [{
                            "placeholder-opacity": [P]
                        }],
                        "text-alignment": [{
                            text: ["left", "center", "right", "justify", "start", "end"]
                        }],
                        "text-color": [{
                            text: [e]
                        }],
                        "text-opacity": [{
                            "text-opacity": [P]
                        }],
                        "text-decoration": ["underline", "overline", "line-through", "no-underline"],
                        "text-decoration-style": [{
                            decoration: [...U(), "wavy"]
                        }],
                        "text-decoration-thickness": [{
                            decoration: ["auto", "from-font", m, h]
                        }],
                        "underline-offset": [{
                            "underline-offset": ["auto", m, k]
                        }],
                        "text-decoration-color": [{
                            decoration: [e]
                        }],
                        "text-transform": ["uppercase", "lowercase", "capitalize", "normal-case"],
                        "text-overflow": ["truncate", "text-ellipsis", "text-clip"],
                        "text-wrap": [{
                            text: ["wrap", "nowrap", "balance", "pretty"]
                        }],
                        indent: [{
                            indent: Z()
                        }],
                        "vertical-align": [{
                            align: ["baseline", "top", "middle", "bottom", "text-top", "text-bottom", "sub", "super", k]
                        }],
                        whitespace: [{
                            whitespace: ["normal", "nowrap", "pre", "pre-line", "pre-wrap", "break-spaces"]
                        }],
                        break: [{
                            break: ["normal", "words", "all", "keep"]
                        }],
                        hyphens: [{
                            hyphens: ["none", "manual", "auto"]
                        }],
                        content: [{
                            content: ["none", k]
                        }],
                        "bg-attachment": [{
                            bg: ["fixed", "local", "scroll"]
                        }],
                        "bg-clip": [{
                            "bg-clip": ["border", "padding", "content", "text"]
                        }],
                        "bg-opacity": [{
                            "bg-opacity": [P]
                        }],
                        "bg-origin": [{
                            "bg-origin": ["border", "padding", "content"]
                        }],
                        "bg-position": [{
                            bg: [...L(), E]
                        }],
                        "bg-repeat": [{
                            bg: ["no-repeat", {
                                repeat: ["", "x", "y", "round", "space"]
                            }]
                        }],
                        "bg-size": [{
                            bg: ["auto", "cover", "contain", C]
                        }],
                        "bg-image": [{
                            bg: ["none", {
                                "gradient-to": ["t", "tr", "r", "br", "b", "bl", "l", "tl"]
                            }, N]
                        }],
                        "bg-color": [{
                            bg: [e]
                        }],
                        "gradient-from-pos": [{
                            from: [g]
                        }],
                        "gradient-via-pos": [{
                            via: [g]
                        }],
                        "gradient-to-pos": [{
                            to: [g]
                        }],
                        "gradient-from": [{
                            from: [b]
                        }],
                        "gradient-via": [{
                            via: [b]
                        }],
                        "gradient-to": [{
                            to: [b]
                        }],
                        rounded: [{
                            rounded: [l]
                        }],
                        "rounded-s": [{
                            "rounded-s": [l]
                        }],
                        "rounded-e": [{
                            "rounded-e": [l]
                        }],
                        "rounded-t": [{
                            "rounded-t": [l]
                        }],
                        "rounded-r": [{
                            "rounded-r": [l]
                        }],
                        "rounded-b": [{
                            "rounded-b": [l]
                        }],
                        "rounded-l": [{
                            "rounded-l": [l]
                        }],
                        "rounded-ss": [{
                            "rounded-ss": [l]
                        }],
                        "rounded-se": [{
                            "rounded-se": [l]
                        }],
                        "rounded-ee": [{
                            "rounded-ee": [l]
                        }],
                        "rounded-es": [{
                            "rounded-es": [l]
                        }],
                        "rounded-tl": [{
                            "rounded-tl": [l]
                        }],
                        "rounded-tr": [{
                            "rounded-tr": [l]
                        }],
                        "rounded-br": [{
                            "rounded-br": [l]
                        }],
                        "rounded-bl": [{
                            "rounded-bl": [l]
                        }],
                        "border-w": [{
                            border: [s]
                        }],
                        "border-w-x": [{
                            "border-x": [s]
                        }],
                        "border-w-y": [{
                            "border-y": [s]
                        }],
                        "border-w-s": [{
                            "border-s": [s]
                        }],
                        "border-w-e": [{
                            "border-e": [s]
                        }],
                        "border-w-t": [{
                            "border-t": [s]
                        }],
                        "border-w-r": [{
                            "border-r": [s]
                        }],
                        "border-w-b": [{
                            "border-b": [s]
                        }],
                        "border-w-l": [{
                            "border-l": [s]
                        }],
                        "border-opacity": [{
                            "border-opacity": [P]
                        }],
                        "border-style": [{
                            border: [...U(), "hidden"]
                        }],
                        "divide-x": [{
                            "divide-x": [s]
                        }],
                        "divide-x-reverse": ["divide-x-reverse"],
                        "divide-y": [{
                            "divide-y": [s]
                        }],
                        "divide-y-reverse": ["divide-y-reverse"],
                        "divide-opacity": [{
                            "divide-opacity": [P]
                        }],
                        "divide-style": [{
                            divide: U()
                        }],
                        "border-color": [{
                            border: [n]
                        }],
                        "border-color-x": [{
                            "border-x": [n]
                        }],
                        "border-color-y": [{
                            "border-y": [n]
                        }],
                        "border-color-t": [{
                            "border-t": [n]
                        }],
                        "border-color-r": [{
                            "border-r": [n]
                        }],
                        "border-color-b": [{
                            "border-b": [n]
                        }],
                        "border-color-l": [{
                            "border-l": [n]
                        }],
                        "divide-color": [{
                            divide: [n]
                        }],
                        "outline-style": [{
                            outline: ["", ...U()]
                        }],
                        "outline-offset": [{
                            "outline-offset": [m, k]
                        }],
                        "outline-w": [{
                            outline: [m, h]
                        }],
                        "outline-color": [{
                            outline: [e]
                        }],
                        "ring-w": [{
                            ring: q()
                        }],
                        "ring-w-inset": ["ring-inset"],
                        "ring-color": [{
                            ring: [e]
                        }],
                        "ring-opacity": [{
                            "ring-opacity": [P]
                        }],
                        "ring-offset-w": [{
                            "ring-offset": [m, h]
                        }],
                        "ring-offset-color": [{
                            "ring-offset": [e]
                        }],
                        shadow: [{
                            shadow: ["", "inner", "none", z, S]
                        }],
                        "shadow-color": [{
                            shadow: [A]
                        }],
                        opacity: [{
                            opacity: [P]
                        }],
                        "mix-blend": [{
                            "mix-blend": B()
                        }],
                        "bg-blend": [{
                            "bg-blend": B()
                        }],
                        filter: [{
                            filter: ["", "none"]
                        }],
                        blur: [{
                            blur: [t]
                        }],
                        brightness: [{
                            brightness: [o]
                        }],
                        contrast: [{
                            contrast: [c]
                        }],
                        "drop-shadow": [{
                            "drop-shadow": ["", "none", z, k]
                        }],
                        grayscale: [{
                            grayscale: [d]
                        }],
                        "hue-rotate": [{
                            "hue-rotate": [f]
                        }],
                        invert: [{
                            invert: [u]
                        }],
                        saturate: [{
                            saturate: [M]
                        }],
                        sepia: [{
                            sepia: [I]
                        }],
                        "backdrop-filter": [{
                            "backdrop-filter": ["", "none"]
                        }],
                        "backdrop-blur": [{
                            "backdrop-blur": [t]
                        }],
                        "backdrop-brightness": [{
                            "backdrop-brightness": [o]
                        }],
                        "backdrop-contrast": [{
                            "backdrop-contrast": [c]
                        }],
                        "backdrop-grayscale": [{
                            "backdrop-grayscale": [d]
                        }],
                        "backdrop-hue-rotate": [{
                            "backdrop-hue-rotate": [f]
                        }],
                        "backdrop-invert": [{
                            "backdrop-invert": [u]
                        }],
                        "backdrop-opacity": [{
                            "backdrop-opacity": [P]
                        }],
                        "backdrop-saturate": [{
                            "backdrop-saturate": [M]
                        }],
                        "backdrop-sepia": [{
                            "backdrop-sepia": [I]
                        }],
                        "border-collapse": [{
                            border: ["collapse", "separate"]
                        }],
                        "border-spacing": [{
                            "border-spacing": [i]
                        }],
                        "border-spacing-x": [{
                            "border-spacing-x": [i]
                        }],
                        "border-spacing-y": [{
                            "border-spacing-y": [i]
                        }],
                        "table-layout": [{
                            table: ["auto", "fixed"]
                        }],
                        caption: [{
                            caption: ["top", "bottom"]
                        }],
                        transition: [{
                            transition: ["none", "all", "", "colors", "opacity", "shadow", "transform", k]
                        }],
                        duration: [{
                            duration: X()
                        }],
                        ease: [{
                            ease: ["linear", "in", "out", "in-out", k]
                        }],
                        delay: [{
                            delay: X()
                        }],
                        animate: [{
                            animate: ["none", "spin", "ping", "pulse", "bounce", k]
                        }],
                        transform: [{
                            transform: ["", "gpu", "none"]
                        }],
                        scale: [{
                            scale: [$]
                        }],
                        "scale-x": [{
                            "scale-x": [$]
                        }],
                        "scale-y": [{
                            "scale-y": [$]
                        }],
                        rotate: [{
                            rotate: [v, k]
                        }],
                        "translate-x": [{
                            "translate-x": [T]
                        }],
                        "translate-y": [{
                            "translate-y": [T]
                        }],
                        "skew-x": [{
                            "skew-x": [_]
                        }],
                        "skew-y": [{
                            "skew-y": [_]
                        }],
                        "transform-origin": [{
                            origin: ["center", "top", "top-right", "right", "bottom-right", "bottom", "bottom-left", "left", "top-left", k]
                        }],
                        accent: [{
                            accent: ["auto", e]
                        }],
                        appearance: [{
                            appearance: ["none", "auto"]
                        }],
                        cursor: [{
                            cursor: ["auto", "default", "pointer", "wait", "text", "move", "help", "not-allowed", "none", "context-menu", "progress", "cell", "crosshair", "vertical-text", "alias", "copy", "no-drop", "grab", "grabbing", "all-scroll", "col-resize", "row-resize", "n-resize", "e-resize", "s-resize", "w-resize", "ne-resize", "nw-resize", "se-resize", "sw-resize", "ew-resize", "ns-resize", "nesw-resize", "nwse-resize", "zoom-in", "zoom-out", k]
                        }],
                        "caret-color": [{
                            caret: [e]
                        }],
                        "pointer-events": [{
                            "pointer-events": ["none", "auto"]
                        }],
                        resize: [{
                            resize: ["none", "y", "x", ""]
                        }],
                        "scroll-behavior": [{
                            scroll: ["auto", "smooth"]
                        }],
                        "scroll-m": [{
                            "scroll-m": Z()
                        }],
                        "scroll-mx": [{
                            "scroll-mx": Z()
                        }],
                        "scroll-my": [{
                            "scroll-my": Z()
                        }],
                        "scroll-ms": [{
                            "scroll-ms": Z()
                        }],
                        "scroll-me": [{
                            "scroll-me": Z()
                        }],
                        "scroll-mt": [{
                            "scroll-mt": Z()
                        }],
                        "scroll-mr": [{
                            "scroll-mr": Z()
                        }],
                        "scroll-mb": [{
                            "scroll-mb": Z()
                        }],
                        "scroll-ml": [{
                            "scroll-ml": Z()
                        }],
                        "scroll-p": [{
                            "scroll-p": Z()
                        }],
                        "scroll-px": [{
                            "scroll-px": Z()
                        }],
                        "scroll-py": [{
                            "scroll-py": Z()
                        }],
                        "scroll-ps": [{
                            "scroll-ps": Z()
                        }],
                        "scroll-pe": [{
                            "scroll-pe": Z()
                        }],
                        "scroll-pt": [{
                            "scroll-pt": Z()
                        }],
                        "scroll-pr": [{
                            "scroll-pr": Z()
                        }],
                        "scroll-pb": [{
                            "scroll-pb": Z()
                        }],
                        "scroll-pl": [{
                            "scroll-pl": Z()
                        }],
                        "snap-align": [{
                            snap: ["start", "end", "center", "align-none"]
                        }],
                        "snap-stop": [{
                            snap: ["normal", "always"]
                        }],
                        "snap-type": [{
                            snap: ["none", "x", "y", "both"]
                        }],
                        "snap-strictness": [{
                            snap: ["mandatory", "proximity"]
                        }],
                        touch: [{
                            touch: ["auto", "none", "manipulation"]
                        }],
                        "touch-x": [{
                            "touch-pan": ["x", "left", "right"]
                        }],
                        "touch-y": [{
                            "touch-pan": ["y", "up", "down"]
                        }],
                        "touch-pz": ["touch-pinch-zoom"],
                        select: [{
                            select: ["none", "text", "all", "auto"]
                        }],
                        "will-change": [{
                            "will-change": ["auto", "scroll", "contents", "transform", k]
                        }],
                        fill: [{
                            fill: [e, "none"]
                        }],
                        "stroke-w": [{
                            stroke: [m, h, y]
                        }],
                        stroke: [{
                            stroke: [e, "none"]
                        }],
                        sr: ["sr-only", "not-sr-only"],
                        "forced-color-adjust": [{
                            "forced-color-adjust": ["auto", "none"]
                        }]
                    },
                    conflictingClassGroups: {
                        overflow: ["overflow-x", "overflow-y"],
                        overscroll: ["overscroll-x", "overscroll-y"],
                        inset: ["inset-x", "inset-y", "start", "end", "top", "right", "bottom", "left"],
                        "inset-x": ["right", "left"],
                        "inset-y": ["top", "bottom"],
                        flex: ["basis", "grow", "shrink"],
                        gap: ["gap-x", "gap-y"],
                        p: ["px", "py", "ps", "pe", "pt", "pr", "pb", "pl"],
                        px: ["pr", "pl"],
                        py: ["pt", "pb"],
                        m: ["mx", "my", "ms", "me", "mt", "mr", "mb", "ml"],
                        mx: ["mr", "ml"],
                        my: ["mt", "mb"],
                        size: ["w", "h"],
                        "font-size": ["leading"],
                        "fvn-normal": ["fvn-ordinal", "fvn-slashed-zero", "fvn-figure", "fvn-spacing", "fvn-fraction"],
                        "fvn-ordinal": ["fvn-normal"],
                        "fvn-slashed-zero": ["fvn-normal"],
                        "fvn-figure": ["fvn-normal"],
                        "fvn-spacing": ["fvn-normal"],
                        "fvn-fraction": ["fvn-normal"],
                        "line-clamp": ["display", "overflow"],
                        rounded: ["rounded-s", "rounded-e", "rounded-t", "rounded-r", "rounded-b", "rounded-l", "rounded-ss", "rounded-se", "rounded-ee", "rounded-es", "rounded-tl", "rounded-tr", "rounded-br", "rounded-bl"],
                        "rounded-s": ["rounded-ss", "rounded-es"],
                        "rounded-e": ["rounded-se", "rounded-ee"],
                        "rounded-t": ["rounded-tl", "rounded-tr"],
                        "rounded-r": ["rounded-tr", "rounded-br"],
                        "rounded-b": ["rounded-br", "rounded-bl"],
                        "rounded-l": ["rounded-tl", "rounded-bl"],
                        "border-spacing": ["border-spacing-x", "border-spacing-y"],
                        "border-w": ["border-w-s", "border-w-e", "border-w-t", "border-w-r", "border-w-b", "border-w-l"],
                        "border-w-x": ["border-w-r", "border-w-l"],
                        "border-w-y": ["border-w-t", "border-w-b"],
                        "border-color": ["border-color-t", "border-color-r", "border-color-b", "border-color-l"],
                        "border-color-x": ["border-color-r", "border-color-l"],
                        "border-color-y": ["border-color-t", "border-color-b"],
                        "scroll-m": ["scroll-mx", "scroll-my", "scroll-ms", "scroll-me", "scroll-mt", "scroll-mr", "scroll-mb", "scroll-ml"],
                        "scroll-mx": ["scroll-mr", "scroll-ml"],
                        "scroll-my": ["scroll-mt", "scroll-mb"],
                        "scroll-p": ["scroll-px", "scroll-py", "scroll-ps", "scroll-pe", "scroll-pt", "scroll-pr", "scroll-pb", "scroll-pl"],
                        "scroll-px": ["scroll-pr", "scroll-pl"],
                        "scroll-py": ["scroll-pt", "scroll-pb"],
                        touch: ["touch-x", "touch-y", "touch-pz"],
                        "touch-x": ["touch"],
                        "touch-y": ["touch"],
                        "touch-pz": ["touch"]
                    },
                    conflictingClassGroupModifiers: {
                        "font-size": ["leading"]
                    }
                }
            })
        }
    }
]);